<?php
${'GLOBALS'}['wtbslorqcpr'] = 'translatedStr';
${'GLOBALS'}['ktwdpsi'] = 'translated';
${'GLOBALS'}['jkxgywfpdkdb'] = 'fromLanguage';
${'GLOBALS'}['bjwflxws'] = 'toLanguage';
${'GLOBALS'}['gomphm'] = 'src_text';
${'GLOBALS'}['tadozzusgt'] = 'requestXml';
${'GLOBALS'}['ojdlmcs'] = 'languageCode';
${'GLOBALS'}['xpcgukzsjux'] = 'curlResponse';
${'GLOBALS'}['nfdmujfbyxjb'] = 'postData';
${'GLOBALS'}['ogfekvdx'] = 'authHeader';
${'GLOBALS'}['wskposxa'] = 'curlError';
${'GLOBALS'}['fscqdnnsfo'] = 'curlErrno';
${'GLOBALS'}['kxqurxdmsdo'] = 'strResponse';
${'GLOBALS'}['tkfseulpy'] = 'paramArr';
${'GLOBALS'}['pqsbdxtih'] = 'scopeUrl';
${'GLOBALS'}['vywhopsnyce'] = 'authUrl';
${'GLOBALS'}['rcunrymonf'] = 'language_code';
${'GLOBALS'}['upcyjavco'] = 'fonts';
${'GLOBALS'}['nbiffrpyw'] = 'font_name';
${'GLOBALS'}['evroqmwb'] = 'font_names';
${'GLOBALS'}['pggmnqdhx'] = 'xy';
${'GLOBALS'}['ryzwqtm'] = 'res';
${'GLOBALS'}['lqqhzfwp'] = 's_h';
${'GLOBALS'}['maemwgeftr'] = 'd_w';
${'GLOBALS'}['uhblrmn'] = 'd_h';
${'GLOBALS'}['stcafb'] = 's_w';
${'GLOBALS'}['jtiuwisbb'] = 'x';
${'GLOBALS'}['nspegybbzhy'] = 'y';
${'GLOBALS'}['ufcgccltkyk'] = 'bgcolor';
${'GLOBALS'}['gjceom'] = 'opacity';
${'GLOBALS'}['vlgxiflimo'] = 'src_x';
${'GLOBALS'}['mhvelt'] = 'dst_y';
${'GLOBALS'}['hpgmsh'] = 'dst_x';
${'GLOBALS'}['ykpnkwwjzs'] = 'merge';
${'GLOBALS'}['kofybgyo'] = 'src_y';
${'GLOBALS'}['xbwumvxhbr'] = 'src_im';
${'GLOBALS'}['bzsxlcdq'] = 'cut';
${'GLOBALS'}['cizlkojgrqg'] = 'dst_im';
${'GLOBALS'}['tpmtvhwtog'] = 'pct';
${'GLOBALS'}['zujvjsu'] = 'quality';
${'GLOBALS'}['iumebukui'] = 'mime';
${'GLOBALS'}['wqbsyyvqxj'] = 'im';
${'GLOBALS'}['zpbndpxula'] = 'dst_mime';
${'GLOBALS'}['exvkaztezwd'] = 'h';
${'GLOBALS'}['accfqwi'] = 'color';
${'GLOBALS'}['tgbumdgl'] = 'w';
${'GLOBALS'}['weunlp'] = 'H';
${'GLOBALS'}['jbulfyxdwsv'] = 'coord';
${'GLOBALS'}['uqtkhkp'] = 'min_w';
${'GLOBALS'}['ttqwivi'] = 'blue';
${'GLOBALS'}['nbcfesz'] = 'green';
${'GLOBALS'}['wfqnxx'] = 'dst_xy';
${'GLOBALS'}['axsdhrrpgjdl'] = 'src_mime';
${'GLOBALS'}['bvqvmcec'] = 'src_h';
${'GLOBALS'}['yoqawitxr'] = 'src_data';
${'GLOBALS'}['buzdzgngucjk'] = 'src_w';
${'GLOBALS'}['kplsgqlelg'] = 'dst_h';
${'GLOBALS'}['unybksiyvybm'] = 'dst_w';
${'GLOBALS'}['qdlpimc'] = 'min_h';
${'GLOBALS'}['uhlqooehmdo'] = 'dst_data';
${'GLOBALS'}['dclsxwjwpro'] = 'src_file';
${'GLOBALS'}['nxwrvqwbbcjt'] = 'dst_file';
${'GLOBALS'}['gfsugymxfiws'] = 'im_file';
${'GLOBALS'}['blbgustrkxet'] = 'font';
${'GLOBALS'}['bhnjnlieef'] = 'metadata';
${'GLOBALS'}['kvgmfqll'] = 'position';
${'GLOBALS'}['fkdbkhppqgo'] = 'alpha';
${'GLOBALS'}['wdmwgiwqkly'] = 'dst';
${'GLOBALS'}['jiuivygw'] = 'errCode';
${'GLOBALS'}['tiinjbksqf'] = 'task';
${'GLOBALS'}['rdozpraqrwvn'] = 'tasks';
${'GLOBALS'}['oddfeginnpgd'] = 'info';
${'GLOBALS'}['dyyxbfbuoutj'] = 'values';
${'GLOBALS'}['dglmsgk'] = 'configs';
${'GLOBALS'}['dsmofcly'] = 're';
${'GLOBALS'}['jvetsqvktdp'] = 'configId';
${'GLOBALS'}['jacdvfv'] = 'queryIds';
${'GLOBALS'}['xbvcbgvvuxgh'] = 'ids';
${'GLOBALS'}['oblmkqqd'] = 'recordIds';
${'GLOBALS'}['kbctgp'] = 'postTimeP';
${'GLOBALS'}['pjennnxoui'] = 'currentTime';
${'GLOBALS'}['gqpdwfcvrztc'] = 'postTime';
${'GLOBALS'}['jicogbzbiwb'] = 'post_scheduled';
${'GLOBALS'}['uchzbhgd'] = 'reValue';
${'GLOBALS'}['opnhqik'] = 'taskId';
${'GLOBALS'}['gmafgnpuwb'] = 'postNum';
${'GLOBALS'}['mszcfaebw'] = 'prePostNum';
${'GLOBALS'}['csgffcs'] = 'PregUrl';
${'GLOBALS'}['qpiytssjkn'] = 'articleAtag';
${'GLOBALS'}['bqjoykhfyzs'] = 'logId';
${'GLOBALS'}['tjsljirplek'] = 'print';
${'GLOBALS'}['cgrepoylt'] = 'stauts';
${'GLOBALS'}['okgeugc'] = 't_f_ap_updated_record';
${'GLOBALS'}['buwunjwjgzih'] = 'recordId';
${'GLOBALS'}['foipfcpb'] = 'cat';
${'GLOBALS'}['fklgripkqgp'] = 'post_id';
${'GLOBALS'}['rrjjnkgcnlk'] = 'autoPostInsert';
${'GLOBALS'}['mjwgpembhrc'] = 'fetched_tags';
${'GLOBALS'}['wvovtbd'] = 'tags_to_add';
${'GLOBALS'}['fhfrfikkcq'] = 'post_type';
${'GLOBALS'}['lucbljk'] = 'post_status';
${'GLOBALS'}['qhjsymofjwq'] = 'auto_set';
${'GLOBALS'}['cwicdn'] = 'post_date';
${'GLOBALS'}['qtmcwdplfh'] = 'cats';
${'GLOBALS'}['wlxdodkb'] = 'categorys';
${'GLOBALS'}['nivuhxo'] = 'excerpt';
${'GLOBALS'}['wxrbgrh'] = 't_f_ap_config';
${'GLOBALS'}['ebsyvj'] = 'fLNum';
${'GLOBALS'}['zkqgnxqtjbn'] = 'fLIndex';
${'GLOBALS'}['dqzhsov'] = 'autoPostInserts';
${'GLOBALS'}['dqjntz'] = 'autoPostUpdate';
${'GLOBALS'}['fzuuprcgvo'] = 'arti';
${'GLOBALS'}['vhscjyjels'] = 'f_style';
${'GLOBALS'}['ndyhukkiwnvw'] = 'f_class';
${'GLOBALS'}['pbegstv'] = 'content_selector';
${'GLOBALS'}['iiisinyser'] = 'cmt';
${'GLOBALS'}['btplbnnrfc'] = 'cmts';
${'GLOBALS'}['xjhjexbdrv'] = 'objective';
${'GLOBALS'}['wrwdrlrtb'] = 'content_match_type';
${'GLOBALS'}['qvohvvh'] = 'content_match_types';
${'GLOBALS'}['ixkotmds'] = 'titleIconved';
${'GLOBALS'}['owlianh'] = 'hasUTFhtml';
${'GLOBALS'}['wjtdbtdagjk'] = 'UTFhtml';
${'GLOBALS'}['oczdbco'] = 'd';
${'GLOBALS'}['mkytkje'] = 'find_a';
${'GLOBALS'}['hramgrdkp'] = 'e';
${'GLOBALS'}['stnivroy'] = 'elements';
${'GLOBALS'}['sxfnnbgw'] = 'index';
${'GLOBALS'}['tufcmkxoiiz'] = 'outer';
${'GLOBALS'}['jvmwdhv'] = 'p1';
${'GLOBALS'}['gzwptts'] = 'p0';
${'GLOBALS'}['ifkqipnmlni'] = 'rule';
${'GLOBALS'}['ncpzcn'] = 'hrefUrl';
${'GLOBALS'}['lbdmsjjvihy'] = 'a';
${'GLOBALS'}['prgsifknkw'] = 'imgUrl';
${'GLOBALS'}['slhvlh'] = 'img';
${'GLOBALS'}['kteeqbxttgpq'] = 'html';
${'GLOBALS'}['mjfnbubdyao'] = 'alt';
${'GLOBALS'}['tmxmsc'] = 'Article';
${'GLOBALS'}['mltolhdp'] = 'config';
${'GLOBALS'}['tofnrsngdw'] = 'id';
${'GLOBALS'}['lqbfvfxur'] = 'list_url';
${'GLOBALS'}['oehpkhmmuc'] = 'pages';
${'GLOBALS'}['eeoglpdmht'] = 'listUrls';
${'GLOBALS'}['sidpumqv'] = 'articleAllAtags';
${'GLOBALS'}['cfzbgqwvc'] = 'articleAtags';
${'GLOBALS'}['tbdqylmuivn'] = 'ListHtml';
${'GLOBALS'}['qmuxdjwtre'] = 'useP';
${'GLOBALS'}['rjeocyczzec'] = 'listUrl';
${'GLOBALS'}['fthtud'] = 'ListUrl';
${'GLOBALS'}['xlymesrkn'] = 'urls_temp';
${'GLOBALS'}['ktsrgim'] = 'Purl';
${'GLOBALS'}['rciueof'] = 'urls';
${'GLOBALS'}['tscfyvlrawd'] = 'reverse_sort';
${'GLOBALS'}['pfvuzil'] = 'titles';
${'GLOBALS'}['bxnptyulre'] = 'pos1';
${'GLOBALS'}['xfxdrj'] = 'baseTagHref';
${'GLOBALS'}['lqnpllgvjlx'] = 'r';
${'GLOBALS'}['ihtxgfapo'] = 'getPosts_url';
${'GLOBALS'}['tjwwlmynx'] = 'freeLinkLastTime';
${'GLOBALS'}['koqfnuc'] = 'fLPost';
${'GLOBALS'}['otobeo'] = 'shouldGetPosts';
${'GLOBALS'}['bfuoggwgvs'] = 'fLPosts';
${'GLOBALS'}['miqdvxvnsb'] = 'freeLinkPosts';
${'GLOBALS'}['gyvibsjzgdm'] = 'delAttrStyle';
${'GLOBALS'}['rjfdxikyyv'] = 'delAttrClass';
${'GLOBALS'}['mqcgalm'] = 'delAttrId';
${'GLOBALS'}['elhrurigqc'] = 'delComment';
${'GLOBALS'}['nnzjikjf'] = 'duplicateIds';
${'GLOBALS'}['hxhuehlpy'] = 'similar_percent';
${'GLOBALS'}['imjnntokkwd'] = 'percent';
${'GLOBALS'}['gkvbsonlegip'] = 'j';
${'GLOBALS'}['ajawzq'] = 'checkTitle';
${'GLOBALS'}['jynrkpfgzcb'] = 'num';
${'GLOBALS'}['imovnktfi'] = 'posts';
${'GLOBALS'}['pibqjkhdl'] = 'noiseElement';
${'GLOBALS'}['kqzrxmuqwt'] = 'remove_tag';
${'GLOBALS'}['voomojjtgkra'] = 'start';
${'GLOBALS'}['tfcnpn'] = 'char';
${'GLOBALS'}['midrpvwbqink'] = 'pos_old';
${'GLOBALS'}['yyukbkigodb'] = 'space';
$akfqzjn = 'fLPosts';
${'GLOBALS'}['wmsndcovop'] = 'guard';
${'GLOBALS'}['uytdmpafsae'] = 'begin_tag_pos';
${'GLOBALS'}['plccpkhc'] = 'org_parent';
${'GLOBALS'}['mmohkjudkfo'] = 'parent_lower';
${'GLOBALS'}['quwporli'] = 'tag_lower';
${'GLOBALS'}['xbhrnq'] = 'encoding_list';
${'GLOBALS'}['bwhpjucyqd'] = 'fullvalue';
${'GLOBALS'}['sizqinpu'] = 'el';
${'GLOBALS'}['mwkrvesiiwol'] = 'success';
${'GLOBALS'}['nqhxvuygr'] = 'contentTypeHeader';
${'GLOBALS'}['ukhqmstsw'] = 'charset';
${'GLOBALS'}['wwaudytvks'] = 's';
${'GLOBALS'}['kkgslhpcwwct'] = 'target_charset';
${'GLOBALS'}['wpvsrsyfd'] = 'delAttrStyle';
${'GLOBALS'}['jopifil'] = 'proposed_height';
${'GLOBALS'}['wmdqdnwob'] = 'attributes';
${'GLOBALS'}['ftxoktsw'] = 'height';
${'GLOBALS'}['zlwlackk'] = 'width';
${'GLOBALS'}['gzdhkqwcr'] = 'len';
${'GLOBALS'}['qgphzbxfcp'] = 'bits';
${'GLOBALS'}['yjkclnnjq'] = 'converted_text';
${'GLOBALS'}['wirrrhclq'] = 'targetCharset';
${'GLOBALS'}['evfxrcsldtl'] = 'sourceCharset';
${'GLOBALS'}['gxuvpvs'] = 'no_key';
${'GLOBALS'}['iylpswx'] = 'm';
${'GLOBALS'}['tprfenuscns'] = 'selector_string';
${'GLOBALS'}['vnxhymnwr'] = 'pattern';
${'GLOBALS'}['iinkwinkf'] = 'check';
${'GLOBALS'}['nomwvpfn'] = 'nodeKeyValue';
${'GLOBALS'}['fotqnjvm'] = 'debugObject';
${'GLOBALS'}['zynijfsg'] = 'pass';
${'GLOBALS'}['lpuxeaf'] = 'node';
${'GLOBALS'}['pncwkvhvp'] = 'end';
${'GLOBALS'}['sckutuml'] = 'selector';
${'GLOBALS'}['itgiqrn'] = 'exp';
${'GLOBALS'}['brfhlvhsfs'] = 'found';
${'GLOBALS'}['npmegbqgw'] = 'delComment';
${'GLOBALS'}['ifpupts'] = 'n';
${'GLOBALS'}['boqfcdtlfdqn'] = 'l';
${'GLOBALS'}['qbbfwon'] = 'levle';
${'GLOBALS'}['gldshxvohkl'] = 'c';
${'GLOBALS'}['lnyifwi'] = 'selectors';
${'GLOBALS'}['xhqjiiwiiwgx'] = 'quote';
${'GLOBALS'}['qzxevewqkf'] = 'ret';
${'GLOBALS'}['ewhenajqf'] = 'returnDom';
${'GLOBALS'}['mqquqj'] = 'delAttrId';
${'GLOBALS'}['tcpuoctul'] = 'idx';
${'GLOBALS'}['jgzstkqem'] = 'v2';
${'GLOBALS'}['rvhdyfwt'] = 'string';
${'GLOBALS'}['qrcnrizhlhyz'] = 'show_attr';
${'GLOBALS'}['jdkfqvbnh'] = 'deep';
${'GLOBALS'}['upttvsxr'] = 'lead';
${'GLOBALS'}['oxftvuqwjtr'] = 'dom';
${'GLOBALS'}['recbduhgh'] = 'stripRN';
${'GLOBALS'}['kzzcxehvqc'] = 'contents';
${'GLOBALS'}['gjeqmmv'] = 'use_include_path';
${'GLOBALS'}['kjdlmahobpl'] = 'defaultSpanText';
${'GLOBALS'}['xgslhlqthsr'] = 'defaultBRText';
${'GLOBALS'}['cxefggrdq'] = 'forceTagsClosed';
${'GLOBALS'}['srnzjhhou'] = 'lowercase';
${'GLOBALS'}['vtdocc'] = 'maxredirect';
${'GLOBALS'}['ultqdi'] = 'newurl';
${'GLOBALS'}['jponwvyyl'] = 'rch';
${'GLOBALS'}['flqjref'] = 'mr';
${'GLOBALS'}['ixmliiphljx'] = 'ip';
${'GLOBALS'}['biduxjlipd'] = 'hideIP';
${'GLOBALS'}['pwwmkbuuqh'] = 'userAndPass';
${'GLOBALS'}['jnjrlqgm'] = 'proxy';
${'GLOBALS'}['yviqqwtvrpu'] = 'useProxy';
${'GLOBALS'}['rsgwcunlw'] = 'curlHandle';
${'GLOBALS'}['bpytrkmufvtv'] = 'agent';
${'GLOBALS'}['wbfrlve'] = 'stash';
${'GLOBALS'}['fimfwyd'] = 'status';
${'GLOBALS'}['vbfqlfs'] = 'k';
${'GLOBALS'}['tculsahk'] = 'header_string';
${'GLOBALS'}['ixthbuln'] = 'freeLinkLastTime';
${'GLOBALS'}['jddwlnpgxn'] = 'http_code';
$xjfvyltg = 'delAttrClass';
${'GLOBALS'}['ximxtrbesm'] = 'method';
${'GLOBALS'}['sifojbttww'] = '_headers';
${'GLOBALS'}['nvswoswm'] = 'headers';
${'GLOBALS'}['vjefgcj'] = 'item';
${'GLOBALS'}['iphyvlv'] = 'time';
$tujqctsqnpv = 'delAttrClass';
${'GLOBALS'}['pvdlywl'] = 'type';
${'GLOBALS'}['uyyltoqjq'] = 'list';
${'GLOBALS'}['lbscyktjprb'] = 'file_handle';
${'GLOBALS'}['vecvovf'] = 'auto_mkdir';
${'GLOBALS'}['fmadgywwk'] = 'opts';
${'GLOBALS'}['trrofof'] = 'path';
${'GLOBALS'}['xbvhpehrca'] = 'endpoint';
${'GLOBALS'}['oheisrnz'] = 'timeout';
${'GLOBALS'}['trgiufwu'] = 'bucketname';
${'GLOBALS'}['mbfpkxftx'] = 'previous';
${'GLOBALS'}['xffdwsdp'] = 'message';
${'GLOBALS'}['knvsekhg'] = 'QINIU_SECRET_KEY';
${'GLOBALS'}['vwfywsuw'] = 'QINIU_ACCESS_KEY';
${'GLOBALS'}['bibpwf'] = 'sign';
${'GLOBALS'}['dfxsaumpg'] = 'secretKey';
${'GLOBALS'}['kvsbddplpzu'] = 'markerOut';
${'GLOBALS'}['mdenknnuigl'] = 'items';
${'GLOBALS'}['pqgolbrvk'] = 'marker';
${'GLOBALS'}['tmuayux'] = 'prefix';
${'GLOBALS'}['muqfebrqb'] = 'query';
${'GLOBALS'}['ugbgbxkmnp'] = 'fileBody';
${'GLOBALS'}['jwvrxodmnwj'] = 'fileName';
${'GLOBALS'}['npuomvv'] = 'file';
${'GLOBALS'}['wsoimxsigpe'] = 'files';
${'GLOBALS'}['qiughdhwjl'] = 'name';
$yvkbvtmxj = 'delAttrStyle';
${'GLOBALS'}['kuxbpnycdn'] = 'mimeBoundary';
${'GLOBALS'}['vmvgdy'] = 'contentType';
${'GLOBALS'}['walfrwpc'] = 'u';
${'GLOBALS'}['xiekxev'] = 'incbody';
${'GLOBALS'}['tjnglar'] = 'req';
${'GLOBALS'}['ftmcqnlmjhb'] = 'resp';
${'GLOBALS'}['welkvffrk'] = 'ch';
${'GLOBALS'}['pnnfscvdxiuy'] = 'options';
${'GLOBALS'}['pculdvlbg'] = 'httpHeader';
${'GLOBALS'}['cxtyldnyhwek'] = 'reqId';
${'GLOBALS'}['vvqxewnmy'] = 'header';
${'GLOBALS'}['qxzqwcmieir'] = 'details';
${'GLOBALS'}['xeqldqrfeyg'] = 'val';
${'GLOBALS'}['pjquhttw'] = 'code';
${'GLOBALS'}['hfgbszef'] = 'fi';
${'GLOBALS'}['rjfoougypoye'] = 'result';
${'GLOBALS'}['furluamn'] = 'uploaded';
${'GLOBALS'}['ixsbheks'] = 'blkputRet';
${'GLOBALS'}['ziqrex'] = 'bsize';
${'GLOBALS'}['xtmjcbkgfeb'] = 'fsize';
${'GLOBALS'}['kljyfje'] = 'ctxs';
${'GLOBALS'}['bdpctzue'] = 'prog';
${'GLOBALS'}['wsietbni'] = 'err';
${'GLOBALS'}['dqyhjpatvh'] = 'reader';
${'GLOBALS'}['czqparzl'] = 'delAttrId';
${'GLOBALS'}['ocrlmakdvudp'] = 'client';
${'GLOBALS'}['stwvgoax'] = 'hash';
${'GLOBALS'}['xqdcugsdgv'] = 'localFile';
${'GLOBALS'}['qqodgfvpulog'] = 'QINIU_UP_HOST';
${'GLOBALS'}['frsktnakrzb'] = 'fname';
${'GLOBALS'}['jfptvrsznsu'] = 'fields';
${'GLOBALS'}['ljrwprmp'] = 'entryPairs';
${'GLOBALS'}['irbnhxzlblx'] = 'dest';
${'GLOBALS'}['eedxpjpny'] = 'src';
${'GLOBALS'}['jouyjjdh'] = 'entryPaths';
${'GLOBALS'}['hlkeamnnkwf'] = 'entryPath';
${'GLOBALS'}['slcwtqbd'] = 'ops';
${'GLOBALS'}['cghahbqpo'] = 'params';
${'GLOBALS'}['gewpghokj'] = 'keyDest';
${'GLOBALS'}['lhytzutnyup'] = 'bucketDest';
${'GLOBALS'}['tuwlbcnimju'] = 'bucketSrc';
${'GLOBALS'}['pjncxq'] = 'QINIU_RS_HOST';
${'GLOBALS'}['qqepwu'] = 'self';
${'GLOBALS'}['uoyyftu'] = 'uri';
${'GLOBALS'}['sgjtht'] = 'bucket';
${'GLOBALS'}['wklbtjxgiwm'] = 'b';
${'GLOBALS'}['nyoajbgs'] = 'policy';
${'GLOBALS'}['tdminl'] = 'mac';
${'GLOBALS'}['aqxaaoiwo'] = 'token';
${'GLOBALS'}['vzrexdhtj'] = 'baseUrl';
${'GLOBALS'}['ymmruswvc'] = 'pos';
${'GLOBALS'}['lgnhyfu'] = 'deadline';
${'GLOBALS'}['lrckewoi'] = 'putPolicy';
${'GLOBALS'}['ksdesm'] = 'putExtra';
${'GLOBALS'}['bvklbfdpe'] = 'body';
${'GLOBALS'}['mlnocyehi'] = 'upToken';
${'GLOBALS'}['fgvupcichziw'] = 'str';
${'GLOBALS'}['qohsiilc'] = 'replace';
${'GLOBALS'}['ownccyg'] = 'QINIU_RSF_HOST';
${'GLOBALS'}['gbrxrvp'] = 'f';
${'GLOBALS'}['jewkzeojer'] = 'callback';
${'GLOBALS'}['svbnlplirubp'] = 'allowed_methods';
$hwleqybgwelh = 'delAttrId';
${'GLOBALS'}['bytrfly'] = 'delAttrStyle';
${'GLOBALS'}['wnewosaggmy'] = 'tag';
${'GLOBALS'}['uumvxihni'] = 'domain';
${'GLOBALS'}['htipvwezttdm'] = 'method_name';
${'GLOBALS'}['mlkxjn'] = 'threshold';
${'GLOBALS'}['ewajjnqqpjb'] = 'max_taken_date';
${'GLOBALS'}['rcbzhqs'] = 'recursive';
${'GLOBALS'}['ivxqnuecb'] = 'place_type';
${'GLOBALS'}['qzpiugwdbg'] = 'bbox';
${'GLOBALS'}['ugrvrob'] = 'place_type_id';
${'GLOBALS'}['nexwenwgb'] = 'accuracy';
${'GLOBALS'}['opblftdcsbm'] = 'photoset_ids';
${'GLOBALS'}['wtezwvolkl'] = 'photo_ids';
${'GLOBALS'}['xkhawv'] = 'photoset_id';
${'GLOBALS'}['ydbmnjbteipg'] = 'tickets';
${'GLOBALS'}['zjmtgerupv'] = 'email';
${'GLOBALS'}['yqzxijctd'] = 'person_y';
${'GLOBALS'}['kencvernn'] = 'person_x';
${'GLOBALS'}['bswubjy'] = 'person_h';
${'GLOBALS'}['oervof'] = 'degrees';
${'GLOBALS'}['zlnputjgtb'] = 'note_w';
${'GLOBALS'}['fwelmk'] = 'note_id';
${'GLOBALS'}['sudltmgqxyn'] = 'note_h';
${'GLOBALS'}['odthedksbhs'] = 'proxy';
${'GLOBALS'}['nnqlijevzkl'] = 'note_y';
${'GLOBALS'}['guqvodwf'] = 'note_x';
${'GLOBALS'}['uwrzowybgu'] = 'license_id';
${'GLOBALS'}['wdyklotehm'] = 'context';
${'GLOBALS'}['bcajipwne'] = 'woe_id';
${'GLOBALS'}['knjtsfo'] = 'place_id';
${'GLOBALS'}['crgbmqapamr'] = 'contacts_filter';
${'GLOBALS'}['fxjkbyegdw'] = 'date_lastcomment';
${'GLOBALS'}['slodxw'] = 'comment_text';
${'GLOBALS'}['elyoyuvcoppm'] = 'comment_id';
${'GLOBALS'}['monsfuhphkwb'] = 'hidden';
${'GLOBALS'}['meipdgtpht'] = 'perm_comment';
${'GLOBALS'}['qzhotvgm'] = 'is_family';
${'GLOBALS'}['miipujyspj'] = 'is_public';
${'GLOBALS'}['pxyxecancv'] = 'date_taken_granularity';
${'GLOBALS'}['fyeygrrkaier'] = 'date_taken';
${'GLOBALS'}['uhhuqhcxvmz'] = 'min_date';
${'GLOBALS'}['rchrxixlunz'] = 'media';
${'GLOBALS'}['vxhyocqthma'] = 'max_upload_date';
${'GLOBALS'}['nmqcxchab'] = 'min_upload_date';
${'GLOBALS'}['lwrkflam'] = 'delComment';
${'GLOBALS'}['gjuygohpi'] = 'privacy_filter';
${'GLOBALS'}['gtfzibjcodev'] = 'min_taken_date';
${'GLOBALS'}['hymdvwnoj'] = 'taken_dates';
${'GLOBALS'}['tjclllc'] = 'order_by';
${'GLOBALS'}['gpulfpcxh'] = 'include_self';
${'GLOBALS'}['udxewhm'] = 'single_photo';
$jqhzczv = 'QINIU_SECRET_KEY';
${'GLOBALS'}['hkawtqnihpru'] = 'count';
${'GLOBALS'}['zbgrbnc'] = 'just_friends';
${'GLOBALS'}['rmkmdgfu'] = 'tags';
${'GLOBALS'}['iuivse'] = 'safe_search';
${'GLOBALS'}['vtymnafzj'] = 'usage';
${'GLOBALS'}['qtminf'] = 'predicate';
${'GLOBALS'}['qgnnqgzeijb'] = 'namespace';
${'GLOBALS'}['mxljvgsts'] = 'use_panda';
${'GLOBALS'}['ejfkcbwayj'] = 'date';
${'GLOBALS'}['gnnvjwn'] = 'jump_to';
${'GLOBALS'}['ojuosqw'] = 'num_prev';
${'GLOBALS'}['kueflpmp'] = 'text';
${'GLOBALS'}['whdlzolqgpb'] = 'lang';
${'GLOBALS'}['lwdqkexf'] = 'group_id';
${'GLOBALS'}['ebqvkbxla'] = 'description';
${'GLOBALS'}['pgoydckvise'] = 'gallery_id';
${'GLOBALS'}['rcqhvj'] = 'primary_photo_id';
${'GLOBALS'}['noyljduo'] = 'comment';
${'GLOBALS'}['kacgczftwkc'] = 'max_fave_date';
${'GLOBALS'}['nwlxjjrhmx'] = 'extras';
${'GLOBALS'}['dttnplc'] = 'freeLinkLastTime';
${'GLOBALS'}['sqyenjebph'] = 'min_fave_date';
${'GLOBALS'}['wpugylrxl'] = 'user_id';
${'GLOBALS'}['sedhlo'] = 'filter';
${'GLOBALS'}['bciltw'] = 'collection_id';
${'GLOBALS'}['akmahehho'] = 'blog_password';
${'GLOBALS'}['kwfzblc'] = 'blog_id';
${'GLOBALS'}['ncxpxsoyvj'] = 'timeframe';
${'GLOBALS'}['xapovj'] = 'page';
${'GLOBALS'}['fcernn'] = 'per_page';
${'GLOBALS'}['ehqbmxlrfjdl'] = 'arguments';
${'GLOBALS'}['sdcopkopk'] = 'value';
${'GLOBALS'}['xnjjys'] = 'find';
${'GLOBALS'}['urwunjsn'] = 'photo_id';
${'GLOBALS'}['jghofqo'] = 'is_friend';
${'GLOBALS'}['tkxxpbqrkjm'] = 'match';
${'GLOBALS'}['ineifmbdkt'] = 'line';
${'GLOBALS'}['dscdjohpgr'] = 'rsp';
${'GLOBALS'}['wqtygwsz'] = 'title';
${'GLOBALS'}['vueqvjefi'] = 'lon';
${'GLOBALS'}['foerajlewfo'] = 'lat';
${'GLOBALS'}['kbqsuyo'] = 'photo';
${'GLOBALS'}['jadgxj'] = 'sizes';
${'GLOBALS'}['ymnwmx'] = 'size';
${'GLOBALS'}['jpbfhpenwn'] = 'expArg';
${'GLOBALS'}['xkxdeg'] = 'v';
${'GLOBALS'}['lhgscxoxke'] = 'retour';
${'GLOBALS'}['xviixidnzkg'] = 'adresse';
$lvdxfhuqp = 'QINIU_ACCESS_KEY';
${'GLOBALS'}['etmtvbx'] = 'param';
${'GLOBALS'}['mitgjalgorbl'] = 'reponse';
${'GLOBALS'}['gdsfaxmjoi'] = 'element';
${'GLOBALS'}['cvvybjyu'] = 'arr';
$tceykk = 'shouldGetPosts';
${'GLOBALS'}['pcierhxmg'] = 'api_sig';
${'GLOBALS'}['vdruzhum'] = 'auth_sig';
${'GLOBALS'}['ckyndtgc'] = 'args';
${'GLOBALS'}['ionyxkwpq'] = 'command';
${'GLOBALS'}['wtkpcrlk'] = 'length';
${'GLOBALS'}['mjisclldvfd'] = 'temp';
${'GLOBALS'}['lzpgrpymfcd'] = 'http_status';
${'GLOBALS'}['nplsgcpjw'] = 'chunked';
${'GLOBALS'}['xwnretuddof'] = 'response';
${'GLOBALS'}['nbgrylhqkku'] = 'fp';
${'GLOBALS'}['mohhnimyg'] = 'QINIU_UP_HOST';
${'GLOBALS'}['gjejvzeg'] = 'key';
${'GLOBALS'}['bqepcs'] = 'data';
${'GLOBALS'}['uubbdhfrc'] = 'curl';
${'GLOBALS'}['lzakelec'] = 'matches';
${'GLOBALS'}['isyiow'] = 'secret';
${'GLOBALS'}['fuihqomo'] = 'regEx';
${'GLOBALS'}['iysvwodqrf'] = 'i';
${'GLOBALS'}['owkyoxonfv'] = 'num_1';
${'GLOBALS'}['eblbrhqk'] = 'limit';
${'GLOBALS'}['vnugmpqtyg'] = 'url';
${'GLOBALS'}['dbntjg'] = 'newwindow';
${'GLOBALS'}['ixkxumxg'] = 'nofollow';
${'GLOBALS'}['sfdpxrmdi'] = 'desc';
${'GLOBALS'}['icegygux'] = 'cleankeyword';
${'GLOBALS'}['gqepfgb'] = 'content';
${'GLOBALS'}['tlshebyh'] = 'delAttrStyle';
${'GLOBALS'}['epjhov'] = 'WholeWord';
${'GLOBALS'}['kauuosjn'] = 'ignorecase';
${'GLOBALS'}['ecomcpmtou'] = 'firstonly';
${'GLOBALS'}['xusfbbp'] = 'link';
${'GLOBALS'}['vomfviyslb'] = 'keyword';
${'GLOBALS'}['bsrtvkdevrj'] = 'ignore_pre';
${'GLOBALS'}['cbpynmxj'] = 'autolinks';
${'GLOBALS'}['avlkmncsan'] = 'wp_autopost_root';
function wp_autopost_head()
{
    ${'GLOBALS'}['iwsqjklkv'] = 'wp_autopost_root';
    global $wp_autopost_root;
    echo ('<link rel="stylesheet" type="text/css" href="' . ${${'GLOBALS'}['avlkmncsan']}) . 'css/wp-autopost.css" />';
    echo ('<script type="text/javascript" src="' . ${${'GLOBALS'}['iwsqjklkv']}) . 'js/wp-autopost.js" /></script>';
}
add_action('admin_head', 'wp_autopost_head');
function update_cron_url()
{
    if ($_REQUEST['update_autopost'] == 1) {
        ap_checkupdate(1);
        die;
    }
}
function update_after_page_load()
{
    ap_checkupdate(0);
}
if (get_option('wp_autopost_updateMethod') == 1) {
    add_action('init', 'update_cron_url');
} else {
    add_action('shutdown', 'update_after_page_load');
}
function wp_autopost_link_content_filter($content)
{
    ${'GLOBALS'}['iakerrq'] = 'autolinks';
    ${'GLOBALS'}['sdtgmnvwcu'] = 'content';
    global $wpdb, $t_autolink;
    $fyildjfgkh = 't_autolink';
    ${${'GLOBALS'}['cbpynmxj']} = $wpdb->get_results('SELECT * FROM ' . ${$fyildjfgkh});
    return wp_autopost_link_replace(${${'GLOBALS'}['sdtgmnvwcu']}, ${${'GLOBALS'}['iakerrq']});
}
add_filter('content_save_pre', 'wp_autopost_link_content_filter');
${'GLOBALS'}['wmhrrwypg'] = 'QINIU_RS_HOST';
function wp_autopost_link_replace($content, $autolinks)
{
    ${'GLOBALS'}['ytwghxgop'] = 'wp_autolink_replaced';
    $kqfbevhdssu = 'autolinks';
    ${${'GLOBALS'}['bsrtvkdevrj']} = 1;
    global $wp_autolink_replaced;
    ${'GLOBALS'}['joutesunlav'] = 'autolink';
    ${${'GLOBALS'}['ytwghxgop']} = false;
    foreach (${$kqfbevhdssu} as ${${'GLOBALS'}['joutesunlav']}) {
        ${'GLOBALS'}['ctojrghbxtjb'] = 'desc';
        $whbnpgu = 'nofollow';
        ${'GLOBALS'}['bucwmcqmf'] = 'wp_autolink_replaced';
        ${'GLOBALS'}['otkkwqjegb'] = 'newwindow';
        ${'GLOBALS'}['wpwbtpp'] = 'limit';
        $nxkpowtukop = 'url';
        ${'GLOBALS'}['dntzctsfje'] = 'case';
        ${${'GLOBALS'}['vomfviyslb']} = $autolink->keyword;
        ${'GLOBALS'}['zddnhdv'] = 'ex_word';
        list(${${'GLOBALS'}['xusfbbp']}, ${${'GLOBALS'}['ctojrghbxtjb']}, ${$whbnpgu}, ${${'GLOBALS'}['otkkwqjegb']}, ${${'GLOBALS'}['ecomcpmtou']}, ${${'GLOBALS'}['kauuosjn']}, ${${'GLOBALS'}['epjhov']}) = explode('|', $autolink->details);
        ${'GLOBALS'}['zpvkefi'] = 'cleankeyword';
        $xhtbusqgits = 'keyword';
        $fsjjldmm = 'content';
        $wersvkilfrch = 'url';
        if (${${'GLOBALS'}['kauuosjn']} == 1) {
            if (stripos(${${'GLOBALS'}['gqepfgb']}, ${${'GLOBALS'}['vomfviyslb']}) === false) {
                continue;
            }
        } else {
            if (strpos(${${'GLOBALS'}['gqepfgb']}, ${${'GLOBALS'}['vomfviyslb']}) === false) {
                continue;
            }
        }
        ${'GLOBALS'}['bnopnlpoy'] = 'desc';
        ${'GLOBALS'}['lxnxxjesjtq'] = 'desc';
        ${'GLOBALS'}['kpdobvpdwgfg'] = 'case';
        ${${'GLOBALS'}['bucwmcqmf']} = true;
        $wvosctgbbj = 'desc';
        $yqitrclou = 'ex_word';
        ${${'GLOBALS'}['icegygux']} = stripslashes(${$xhtbusqgits});
        ${'GLOBALS'}['bcidcpq'] = 'url';
        if (!${$wvosctgbbj}) {
            $lbndwtesbso = 'cleankeyword';
            ${${'GLOBALS'}['sfdpxrmdi']} = ${$lbndwtesbso};
        }
        ${'GLOBALS'}['emfbsbgvr'] = 'cleankeyword';
        ${${'GLOBALS'}['bnopnlpoy']} = addcslashes(${${'GLOBALS'}['lxnxxjesjtq']}, '$');
        ${${'GLOBALS'}['bcidcpq']} = "<a href=\"{$link}\" title=\"{$desc}\"";
        if (${${'GLOBALS'}['ixkxumxg']}) {
            ${$wersvkilfrch} .= ' rel="nofollow"';
        }
        if (${${'GLOBALS'}['dbntjg']}) {
            ${${'GLOBALS'}['vnugmpqtyg']} .= ' target="_blank"';
        }
        $qpwnngvzit = 'regEx';
        $geyilhllfi = 'ignore_pre';
        ${${'GLOBALS'}['vnugmpqtyg']} .= ('>' . addcslashes(${${'GLOBALS'}['emfbsbgvr']}, '$')) . '</a>';
        if (${${'GLOBALS'}['ecomcpmtou']}) {
            ${${'GLOBALS'}['eblbrhqk']} = 1;
        } else {
            ${${'GLOBALS'}['wpwbtpp']} = -1;
        }
        ${'GLOBALS'}['tlktepm'] = 'ex_word';
        $slrnehgveni = 'content';
        ${'GLOBALS'}['qgtvbbjt'] = 'limit';
        $bcrvjhvnbb = 'content';
        if (${${'GLOBALS'}['kauuosjn']}) {
            ${${'GLOBALS'}['dntzctsfje']} = 'i';
        } else {
            ${${'GLOBALS'}['kpdobvpdwgfg']} = '';
        }
        ${${'GLOBALS'}['zddnhdv']} = preg_quote(${${'GLOBALS'}['zpvkefi']}, '\'');
        if (${${'GLOBALS'}['bsrtvkdevrj']}) {
            ${'GLOBALS'}['fzqrgvls'] = 'ignore_pre';
            ${'GLOBALS'}['yvsibq'] = 'content';
            if (${${'GLOBALS'}['owkyoxonfv']} = preg_match_all('/<pre.*?>.*?<\\/pre>/is', ${${'GLOBALS'}['yvsibq']}, ${${'GLOBALS'}['fzqrgvls']})) {
                for (${${'GLOBALS'}['iysvwodqrf']} = 1; ${${'GLOBALS'}['iysvwodqrf']} <= ${${'GLOBALS'}['owkyoxonfv']}; ${${'GLOBALS'}['iysvwodqrf']}++) {
                    ${${'GLOBALS'}['gqepfgb']} = preg_replace('/<pre.*?>.*?<\\/pre>/is', "%ignore_pre_{$i}%", ${${'GLOBALS'}['gqepfgb']}, 1);
                }
            }
        }
        ${'GLOBALS'}['usytejrdvg'] = 'content';
        ${${'GLOBALS'}['gqepfgb']} = preg_replace(('|(<img)(.*?)(' . ${${'GLOBALS'}['tlktepm']}) . ')(.*?)(>)|U', '$1$2%&&&&&%$4$5', ${${'GLOBALS'}['usytejrdvg']});
        ${${'GLOBALS'}['icegygux']} = preg_quote(${${'GLOBALS'}['icegygux']}, '\'');
        if (${${'GLOBALS'}['epjhov']} == 1) {
            ${'GLOBALS'}['hhxwybboekw'] = 'case';
            ${'GLOBALS'}['ivodgvi'] = 'cleankeyword';
            ${${'GLOBALS'}['fuihqomo']} = (('\'(?!((<.*?)|(<a.*?)))(\\b' . ${${'GLOBALS'}['ivodgvi']}) . '\\b)(?!(([^<>]*?)>)|([^>]*?</a>))\'s') . ${${'GLOBALS'}['hhxwybboekw']};
        } else {
            $jwntqilmkh = 'case';
            ${'GLOBALS'}['lgojxapblaqt'] = 'cleankeyword';
            $dlgtbedb = 'regEx';
            ${$dlgtbedb} = (('\'(?!((<.*?)|(<a.*?)))(' . ${${'GLOBALS'}['lgojxapblaqt']}) . ')(?!(([^<>]*?)>)|([^>]*?</a>))\'s') . ${$jwntqilmkh};
        }
        ${${'GLOBALS'}['gqepfgb']} = preg_replace(${$qpwnngvzit}, ${$nxkpowtukop}, ${$fsjjldmm}, ${${'GLOBALS'}['qgtvbbjt']});
        ${$slrnehgveni} = str_replace('%&&&&&%', stripslashes(${$yqitrclou}), ${$bcrvjhvnbb});
        if (${$geyilhllfi}) {
            $usfhixrmv = 'num_1';
            ${'GLOBALS'}['cwguxmrvcy'] = 'i';
            for (${${'GLOBALS'}['iysvwodqrf']} = 1; ${${'GLOBALS'}['cwguxmrvcy']} <= ${$usfhixrmv}; ${${'GLOBALS'}['iysvwodqrf']}++) {
                ${'GLOBALS'}['vphyys'] = 'content';
                ${'GLOBALS'}['wwrtoohvgy'] = 'ignore_pre';
                ${'GLOBALS'}['nvibuloeg'] = 'content';
                ${${'GLOBALS'}['nvibuloeg']} = str_replace("%ignore_pre_{$i}%", ${${'GLOBALS'}['wwrtoohvgy']}[0][${${'GLOBALS'}['iysvwodqrf']} - 1], ${${'GLOBALS'}['vphyys']});
            }
        }
    }
    return ${${'GLOBALS'}['gqepfgb']};
}
function autoPostLinkPost($object, $autolinks)
{
    ${'GLOBALS'}['dlqxmx'] = 'wp_autolink_replaced';
    ${${'GLOBALS'}['gqepfgb']} = wp_autopost_link_replace($object->post_content, ${${'GLOBALS'}['cbpynmxj']});
    global $wp_autolink_replaced, $wpdb;
    if (${${'GLOBALS'}['dlqxmx']}) {
        ${'GLOBALS'}['bbusdlqm'] = 'content';
        $wpdb->query($wpdb->prepare("UPDATE {$wpdb->posts} SET post_content = %s WHERE ID = %d ", ${${'GLOBALS'}['bbusdlqm']}, $object->ID));
    }
}
class autopostFlickr
{
    public $api_key;
    public $secret;
    public $rest_endpoint = 'http://api.flickr.com/services/rest/';
    public $upload_endpoint = 'http://api.flickr.com/services/upload/';
    public $replace_endpoint = 'http://api.flickr.com/services/replace/';
    public $oauthrequest_endpoint = 'http://www.flickr.com/services/oauth/request_token/';
    public $oauthauthorize_endpoint = 'http://www.flickr.com/services/oauth/authorize/';
    public $oauthaccesstoken_endpoint = 'http://www.flickr.com/services/oauth/access_token/';
    public $req;
    public $response;
    public $parsed_response;
    public $last_request = null;
    public $die_on_error;
    public $error_code;
    public $error_msg;
    public $oauth_token;
    public $oauth_secret;
    public $php_version;
    public $custom_post = null;
    public function autopostFlickr($api_key, $secret = NULL, $die_on_error = false)
    {
        $shzrvcdhd = 'api_key';
        $this->api_key = ${$shzrvcdhd};
        $this->secret = ${${'GLOBALS'}['isyiow']};
        ${'GLOBALS'}['zkhylic'] = 'die_on_error';
        $this->die_on_error = ${${'GLOBALS'}['zkhylic']};
        $this->service = 'flickr';
        $this->php_version = explode('-', phpversion());
        $this->php_version = explode('.', $this->php_version[0]);
    }
    public function setCustomPost($function)
    {
        ${'GLOBALS'}['sgngbs'] = 'function';
        $this->custom_post = ${${'GLOBALS'}['sgngbs']};
    }
    public function post($data, $url = '')
    {
        ${'GLOBALS'}['ugozdhgqyn'] = 'url';
        if (${${'GLOBALS'}['ugozdhgqyn']} == '') {
            ${${'GLOBALS'}['vnugmpqtyg']} = $this->rest_endpoint;
        }
        if (!preg_match('|http://(.*?)(/.*)|', ${${'GLOBALS'}['vnugmpqtyg']}, ${${'GLOBALS'}['lzakelec']})) {
            die('There was some problem figuring out your endpoint');
        }
        if (function_exists('curl_init')) {
            $wbrnfampfyr = 'curl';
            ${'GLOBALS'}['babwcfwqtgh'] = 'curl';
            ${$wbrnfampfyr} = curl_init(${${'GLOBALS'}['vnugmpqtyg']});
            ${'GLOBALS'}['reuqvxsom'] = 'curl';
            curl_setopt(${${'GLOBALS'}['babwcfwqtgh']}, CURLOPT_POST, true);
            curl_setopt(${${'GLOBALS'}['uubbdhfrc']}, CURLOPT_POSTFIELDS, ${${'GLOBALS'}['bqepcs']});
            curl_setopt(${${'GLOBALS'}['reuqvxsom']}, CURLOPT_RETURNTRANSFER, true);
            ${'GLOBALS'}['sbwudsy'] = 'curl';
            ${'GLOBALS'}['gstpsnytkkvo'] = 'response';
            ${${'GLOBALS'}['gstpsnytkkvo']} = curl_exec(${${'GLOBALS'}['sbwudsy']});
            curl_close(${${'GLOBALS'}['uubbdhfrc']});
        } else {
            $ygdwtsetc = 'value';
            $qbrcosycgiov = 'matches';
            ${'GLOBALS'}['autriiefvt'] = 'response';
            ${'GLOBALS'}['kzdvtf'] = 'data';
            $ctnxmbpaksik = 'response';
            ${'GLOBALS'}['rfgszgbf'] = 'data';
            $sqyahuvip = 'response';
            $ypieigs = 'fp';
            $yernmncrhxe = 'fp';
            foreach (${${'GLOBALS'}['kzdvtf']} as ${${'GLOBALS'}['gjejvzeg']} => ${$ygdwtsetc}) {
                $xlepsqwwapq = 'key';
                ${'GLOBALS'}['jjicckeqpo'] = 'value';
                ${${'GLOBALS'}['bqepcs']}[${${'GLOBALS'}['gjejvzeg']}] = (${$xlepsqwwapq} . '=') . urlencode(${${'GLOBALS'}['jjicckeqpo']});
            }
            ${'GLOBALS'}['rzhybiu'] = 'data';
            ${${'GLOBALS'}['rfgszgbf']} = implode('&', ${${'GLOBALS'}['rzhybiu']});
            $xwswsjcbi = 'data';
            ${${'GLOBALS'}['nbgrylhqkku']} = @pfsockopen(${${'GLOBALS'}['lzakelec']}[1], 80);
            ${'GLOBALS'}['tqrkpue'] = 'response';
            if (!${${'GLOBALS'}['nbgrylhqkku']}) {
                die('Could not connect to the web service');
            }
            $gfcvqrwupi = 'matches';
            fputs(${${'GLOBALS'}['nbgrylhqkku']}, ('POST ' . ${$qbrcosycgiov}[2]) . ' HTTP/1.1
');
            fputs(${$yernmncrhxe}, ('Host: ' . ${$gfcvqrwupi}[1]) . '
');
            fputs(${${'GLOBALS'}['nbgrylhqkku']}, 'Content-type: application/x-www-form-urlencoded
');
            fputs(${${'GLOBALS'}['nbgrylhqkku']}, ('Content-length: ' . strlen(${$xwswsjcbi})) . '
');
            fputs(${${'GLOBALS'}['nbgrylhqkku']}, 'Connection: close

');
            fputs(${$ypieigs}, ${${'GLOBALS'}['bqepcs']} . '

');
            ${$sqyahuvip} = '';
            while (!feof(${${'GLOBALS'}['nbgrylhqkku']})) {
                ${${'GLOBALS'}['xwnretuddof']} .= fgets(${${'GLOBALS'}['nbgrylhqkku']}, 1024);
            }
            fclose(${${'GLOBALS'}['nbgrylhqkku']});
            ${${'GLOBALS'}['nplsgcpjw']} = false;
            ${${'GLOBALS'}['lzpgrpymfcd']} = trim(substr(${${'GLOBALS'}['tqrkpue']}, 0, strpos(${${'GLOBALS'}['xwnretuddof']}, '
')));
            if (${${'GLOBALS'}['lzpgrpymfcd']} != 'HTTP/1.1 200 OK') {
                die(('The web service endpoint returned a "' . ${${'GLOBALS'}['lzpgrpymfcd']}) . '" response');
            }
            if (strpos(${$ctnxmbpaksik}, 'Transfer-Encoding: chunked') !== false) {
                ${'GLOBALS'}['xudzrdrxkq'] = 'response';
                $reffrnbiob = 'response';
                ${${'GLOBALS'}['mjisclldvfd']} = trim(strstr(${${'GLOBALS'}['xudzrdrxkq']}, '

'));
                ${$reffrnbiob} = '';
                ${'GLOBALS'}['ctewxbq'] = 'temp';
                ${'GLOBALS'}['jgshgb'] = 'length';
                ${'GLOBALS'}['tgusxlb'] = 'temp';
                ${${'GLOBALS'}['wtkpcrlk']} = trim(substr(${${'GLOBALS'}['mjisclldvfd']}, 0, strpos(${${'GLOBALS'}['mjisclldvfd']}, '
')));
                while (trim(${${'GLOBALS'}['ctewxbq']}) != '0' && (${${'GLOBALS'}['jgshgb']} = trim(substr(${${'GLOBALS'}['mjisclldvfd']}, 0, strpos(${${'GLOBALS'}['tgusxlb']}, '
')))) != '0') {
                    $hwjzqjs = 'length';
                    ${'GLOBALS'}['imhxiwsgouqw'] = 'length';
                    $nckspujei = 'temp';
                    ${${'GLOBALS'}['xwnretuddof']} .= trim(substr(${${'GLOBALS'}['mjisclldvfd']}, strlen(${${'GLOBALS'}['wtkpcrlk']}) + 2, hexdec(${$hwjzqjs})));
                    ${$nckspujei} = trim(substr(${${'GLOBALS'}['mjisclldvfd']}, (strlen(${${'GLOBALS'}['wtkpcrlk']}) + 2) + hexdec(${${'GLOBALS'}['imhxiwsgouqw']})));
                }
            } elseif (strpos(${${'GLOBALS'}['autriiefvt']}, 'HTTP/1.1 200 OK') !== false) {
                $dbyihhkqsi = 'response';
                ${$dbyihhkqsi} = trim(strstr(${${'GLOBALS'}['xwnretuddof']}, '

'));
            }
        }
        return ${${'GLOBALS'}['xwnretuddof']};
    }
    public function request($command, $args = array())
    {
        ${'GLOBALS'}['ilwistwrw'] = 'command';
        $dhcbyiusef = 'auth_sig';
        if (substr(${${'GLOBALS'}['ilwistwrw']}, 0, 7) != 'flickr.') {
            ${'GLOBALS'}['xmrsyb'] = 'command';
            ${${'GLOBALS'}['ionyxkwpq']} = 'flickr.' . ${${'GLOBALS'}['xmrsyb']};
        }
        ${'GLOBALS'}['ppmblyew'] = 'command';
        ${${'GLOBALS'}['ckyndtgc']} = array_merge(array('method' => ${${'GLOBALS'}['ppmblyew']}, 'format' => 'php_serial', 'api_key' => $this->api_key), ${${'GLOBALS'}['ckyndtgc']});
        ksort(${${'GLOBALS'}['ckyndtgc']});
        ${$dhcbyiusef} = '';
        $hfwsdhdwcbwd = 'args';
        ${'GLOBALS'}['jjpkiulhtmct'] = 'args';
        $this->last_request = ${${'GLOBALS'}['ckyndtgc']};
        foreach (${$hfwsdhdwcbwd} as ${${'GLOBALS'}['gjejvzeg']} => ${${'GLOBALS'}['bqepcs']}) {
            ${'GLOBALS'}['xsebrknsy'] = 'data';
            ${'GLOBALS'}['ihfvweljtil'] = 'key';
            $gwvtaoyxsv = 'auth_sig';
            if (is_null(${${'GLOBALS'}['bqepcs']})) {
                $pfstumvvkf = 'key';
                $vzzazdynveym = 'args';
                unset(${$vzzazdynveym}[${$pfstumvvkf}]);
                continue;
            }
            ${$gwvtaoyxsv} .= ${${'GLOBALS'}['ihfvweljtil']} . ${${'GLOBALS'}['xsebrknsy']};
        }
        if (!empty($this->secret)) {
            ${'GLOBALS'}['zgcrxnh'] = 'api_sig';
            ${'GLOBALS'}['dxrzvqlbs'] = 'args';
            ${${'GLOBALS'}['zgcrxnh']} = md5($this->secret . ${${'GLOBALS'}['vdruzhum']});
            ${${'GLOBALS'}['dxrzvqlbs']}['api_sig'] = ${${'GLOBALS'}['pcierhxmg']};
        }
        ${'GLOBALS'}['xgltkdl'] = 'args';
        if (!(${${'GLOBALS'}['ckyndtgc']} = $this->getArgOauth($this->rest_endpoint, ${${'GLOBALS'}['jjpkiulhtmct']}))) {
            return false;
        }
        $this->response = $this->post(${${'GLOBALS'}['xgltkdl']});
        $this->parsed_response = $this->clean_text_nodes(unserialize($this->response));
        if ($this->parsed_response['stat'] == 'fail') {
            if ($this->die_on_error) {
                die("The Flickr API returned the following error: #{$this->parsed_response['code']} - {$this->parsed_response['message']}");
            } else {
                $this->error_code = $this->parsed_response['code'];
                $this->error_msg = $this->parsed_response['message'];
                $this->parsed_response = false;
            }
        } else {
            $this->error_code = false;
            $this->error_msg = false;
        }
        return $this->response;
    }
    public function clean_text_nodes($arr)
    {
        $rmothhevj = 'arr';
        ${'GLOBALS'}['eeesnoyxxpyo'] = 'arr';
        ${'GLOBALS'}['jvekluturle'] = 'arr';
        if (!is_array(${${'GLOBALS'}['eeesnoyxxpyo']})) {
            $nycijxg = 'arr';
            return ${$nycijxg};
        } elseif (count(${${'GLOBALS'}['cvvybjyu']}) == 0) {
            ${'GLOBALS'}['gifwsmlw'] = 'arr';
            return ${${'GLOBALS'}['gifwsmlw']};
        } elseif (count(${${'GLOBALS'}['jvekluturle']}) == 1 && array_key_exists('_content', ${$rmothhevj})) {
            return ${${'GLOBALS'}['cvvybjyu']}['_content'];
        } else {
            ${'GLOBALS'}['nxumixdj'] = 'key';
            foreach (${${'GLOBALS'}['cvvybjyu']} as ${${'GLOBALS'}['nxumixdj']} => ${${'GLOBALS'}['gdsfaxmjoi']}) {
                ${'GLOBALS'}['ioeisdn'] = 'arr';
                ${'GLOBALS'}['nybactf'] = 'element';
                ${${'GLOBALS'}['ioeisdn']}[${${'GLOBALS'}['gjejvzeg']}] = $this->clean_text_nodes(${${'GLOBALS'}['nybactf']});
            }
            return ${${'GLOBALS'}['cvvybjyu']};
        }
    }
    public function getArgOauth($url, $data)
    {
        if (!empty($this->oauth_token) && !empty($this->oauth_secret)) {
            ${'GLOBALS'}['vuslvedjssvr'] = 'data';
            $xnzudeqfdn = 'data';
            ${'GLOBALS'}['rkrenvneojw'] = 'data';
            ${${'GLOBALS'}['bqepcs']}['oauth_consumer_key'] = $this->api_key;
            $eaegcvguif = 'url';
            ${'GLOBALS'}['vlmqmuwgg'] = 'data';
            $eahlpjvphvf = 'data';
            ${$xnzudeqfdn}['oauth_timestamp'] = time();
            ${${'GLOBALS'}['vuslvedjssvr']}['oauth_nonce'] = md5(uniqid(rand(), true));
            ${$eahlpjvphvf}['oauth_signature_method'] = 'HMAC-SHA1';
            ${${'GLOBALS'}['rkrenvneojw']}['oauth_version'] = '1.0';
            ${${'GLOBALS'}['vlmqmuwgg']}['oauth_token'] = $this->oauth_token;
            if (!(${${'GLOBALS'}['bqepcs']}['oauth_signature'] = $this->getOauthSignature(${$eaegcvguif}, ${${'GLOBALS'}['bqepcs']}))) {
                return false;
            }
        }
        return ${${'GLOBALS'}['bqepcs']};
    }
    public function requestOauthToken()
    {
        if (session_id() == '') {
            session_start();
        }
        if (((!isset($_SESSION['oauth_tokentmp']) || !isset($_SESSION['oauth_secrettmp'])) || $_SESSION['oauth_tokentmp'] == '') || $_SESSION['oauth_secrettmp'] == '') {
            $ecsrpcc = 'callback';
            $pwadgiihw = 'callback';
            ${$pwadgiihw} = ('http://' . $_SERVER['HTTP_HOST']) . $_SERVER['REQUEST_URI'];
            $this->getRequestToken(${$ecsrpcc});
            return false;
        } else {
            return $this->getAccessToken();
        }
    }
    public function getRequestToken($callback, $perms)
    {
        ${'GLOBALS'}['pdmmovw'] = 'callback';
        ${'GLOBALS'}['uswsbcbpqnc'] = 'data';
        ${'GLOBALS'}['idylnjtfw'] = 'data';
        ${'GLOBALS'}['tynzxgolgtr'] = 'perms';
        if (session_id() == '') {
            session_start();
        }
        ${'GLOBALS'}['tvytnx'] = 'reponse';
        ${${'GLOBALS'}['uswsbcbpqnc']} = array('oauth_consumer_key' => $this->api_key, 'oauth_timestamp' => time(), 'oauth_nonce' => md5(uniqid(rand(), true)), 'oauth_signature_method' => 'HMAC-SHA1', 'oauth_version' => '1.0', 'oauth_callback' => ${${'GLOBALS'}['pdmmovw']});
        if (!(${${'GLOBALS'}['bqepcs']}['oauth_signature'] = $this->getOauthSignature($this->oauthrequest_endpoint, ${${'GLOBALS'}['idylnjtfw']}))) {
            return false;
        }
        ${${'GLOBALS'}['tvytnx']} = $this->oauthResponse($this->post(${${'GLOBALS'}['bqepcs']}, $this->oauthrequest_endpoint));
        ${'GLOBALS'}['bbmmuvjxu'] = 'reponse';
        ${'GLOBALS'}['pwwnyniw'] = 'reponse';
        if (!isset(${${'GLOBALS'}['pwwnyniw']}['oauth_callback_confirmed']) || ${${'GLOBALS'}['mitgjalgorbl']}['oauth_callback_confirmed'] != 'true') {
            $ddvikklevi = 'reponse';
            $this->error_code = 'Oauth';
            $this->error_msg = ${$ddvikklevi};
            return false;
        }
        $_SESSION['oauth_tokentmp'] = ${${'GLOBALS'}['mitgjalgorbl']}['oauth_token'];
        $_SESSION['oauth_secrettmp'] = ${${'GLOBALS'}['bbmmuvjxu']}['oauth_token_secret'];
        header((((('location: ' . $this->oauthauthorize_endpoint) . '?oauth_token=') . ${${'GLOBALS'}['mitgjalgorbl']}['oauth_token']) . '&perms=') . ${${'GLOBALS'}['tynzxgolgtr']});
        $this->error_code = '';
        $this->error_msg = '';
        return true;
    }
    public function getAccessToken()
    {
        if (session_id() == '') {
            session_start();
        }
        $this->oauth_token = $_SESSION['oauth_tokentmp'];
        $this->oauth_secret = $_SESSION['oauth_secrettmp'];
        unset($_SESSION['oauth_tokentmp']);
        $zunemelw = 'reponse';
        unset($_SESSION['oauth_secrettmp']);
        $tocghrthux = 'data';
        ${'GLOBALS'}['eimmfbufkc'] = 'data';
        if (!isset($_GET['oauth_verifier']) || $_GET['oauth_verifier'] == '') {
            $this->error_code = 'Oauth';
            $this->error_msg = 'oauth_verifier is undefined.';
            return false;
        }
        ${${'GLOBALS'}['eimmfbufkc']} = array('oauth_consumer_key' => $this->api_key, 'oauth_timestamp' => time(), 'oauth_nonce' => md5(uniqid(rand(), true)), 'oauth_signature_method' => 'HMAC-SHA1', 'oauth_version' => '1.0', 'oauth_token' => $this->oauth_token, 'oauth_verifier' => $_GET['oauth_verifier']);
        $irwchrmaxsl = 'data';
        if (!(${$tocghrthux}['oauth_signature'] = $this->getOauthSignature($this->oauthaccesstoken_endpoint, ${${'GLOBALS'}['bqepcs']}))) {
            return false;
        }
        ${$zunemelw} = $this->oauthResponse($this->post(${$irwchrmaxsl}, $this->oauthaccesstoken_endpoint));
        if (isset(${${'GLOBALS'}['mitgjalgorbl']}['oauth_problem']) && ${${'GLOBALS'}['mitgjalgorbl']}['oauth_problem'] != '') {
            ${'GLOBALS'}['nypbsmbops'] = 'reponse';
            $this->error_code = 'Oauth';
            $this->error_msg = ${${'GLOBALS'}['nypbsmbops']};
            return false;
        }
        $this->oauth_token = ${${'GLOBALS'}['mitgjalgorbl']}['oauth_token'];
        $this->oauth_secret = ${${'GLOBALS'}['mitgjalgorbl']}['oauth_token_secret'];
        $this->error_code = '';
        $this->error_msg = '';
        return true;
    }
    public function getOauthSignature($url, $data)
    {
        $unmrdmvpztp = 'url';
        $acigkpwpd = 'value';
        $ehmptkab = 'key';
        ${'GLOBALS'}['nkwsqitsleg'] = 'adresse';
        if ($this->secret == '') {
            $this->error_code = 'Oauth';
            $this->error_msg = 'API Secret is undefined.';
            return false;
        }
        $nwjhtysv = 'adresse';
        ${'GLOBALS'}['vtilqcbqb'] = 'value';
        ksort(${${'GLOBALS'}['bqepcs']});
        ${'GLOBALS'}['uasjoyhevk'] = 'data';
        ${${'GLOBALS'}['nkwsqitsleg']} = ('POST&' . rawurlencode(${$unmrdmvpztp})) . '&';
        ${${'GLOBALS'}['etmtvbx']} = '';
        ${'GLOBALS'}['dfvigjibv'] = 'param';
        foreach (${${'GLOBALS'}['uasjoyhevk']} as ${$ehmptkab} => ${$acigkpwpd}) {
            ${${'GLOBALS'}['etmtvbx']} .= ((${${'GLOBALS'}['gjejvzeg']} . '=') . rawurlencode(${${'GLOBALS'}['vtilqcbqb']})) . '&';
        }
        ${${'GLOBALS'}['etmtvbx']} = substr(${${'GLOBALS'}['dfvigjibv']}, 0, -1);
        ${$nwjhtysv} .= rawurlencode(${${'GLOBALS'}['etmtvbx']});
        return base64_encode(hash_hmac('sha1', ${${'GLOBALS'}['xviixidnzkg']}, ($this->secret . '&') . $this->oauth_secret, true));
    }
    public function oauthResponse($response)
    {
        $pybdrurjn = 'response';
        $qnhadxssktf = 'expResponse';
        ${$qnhadxssktf} = explode('&', ${$pybdrurjn});
        $glxyxuvogwsu = 'expResponse';
        ${${'GLOBALS'}['lhgscxoxke']} = array();
        foreach (${$glxyxuvogwsu} as ${${'GLOBALS'}['xkxdeg']}) {
            $gagwynzphx = 'v';
            ${'GLOBALS'}['gfaowpgtk'] = 'retour';
            $uevhjelr = 'expArg';
            $ygduocfd = 'expArg';
            ${$uevhjelr} = explode('=', ${$gagwynzphx});
            ${${'GLOBALS'}['gfaowpgtk']}[${${'GLOBALS'}['jpbfhpenwn']}[0]] = ${$ygduocfd}[1];
        }
        return ${${'GLOBALS'}['lhgscxoxke']};
    }
    public function setOauthToken($token, $secret)
    {
        ${'GLOBALS'}['cdnfuik'] = 'token';
        $ahqmkdykdut = 'secret';
        $this->oauth_token = ${${'GLOBALS'}['cdnfuik']};
        $this->oauth_secret = ${$ahqmkdykdut};
    }
    public function getOauthToken()
    {
        return $this->oauth_token;
    }
    public function getOauthSecretToken()
    {
        return $this->oauth_secret;
    }
    public function setProxy($server, $port)
    {
        ${'GLOBALS'}['bonwdk'] = 'port';
        ${'GLOBALS'}['exqxgn'] = 'server';
        $this->req->setProxy(${${'GLOBALS'}['exqxgn']}, ${${'GLOBALS'}['bonwdk']});
    }
    public function getErrorCode()
    {
        return $this->error_code;
    }
    public function getErrorMsg()
    {
        return $this->error_msg;
    }
    public function buildPhotoURL($photo, $size = 'Medium')
    {
        ${'GLOBALS'}['ogsoulei'] = 'size';
        $nyxpwntpi = 'sizes';
        ${$nyxpwntpi} = array('square' => '_s', 'thumbnail' => '_t', 'small' => '_m', 'medium' => '', 'medium_640' => '_z', 'large' => '_b', 'original' => '_o');
        ${${'GLOBALS'}['ogsoulei']} = strtolower(${${'GLOBALS'}['ymnwmx']});
        if (!array_key_exists(${${'GLOBALS'}['ymnwmx']}, ${${'GLOBALS'}['jadgxj']})) {
            ${'GLOBALS'}['acmzoiesj'] = 'size';
            ${${'GLOBALS'}['acmzoiesj']} = 'medium';
        }
        if (${${'GLOBALS'}['ymnwmx']} == 'original') {
            $fertbb = 'photo';
            ${'GLOBALS'}['dqfuenpywr'] = 'photo';
            ${'GLOBALS'}['mopjbxb'] = 'url';
            ${${'GLOBALS'}['mopjbxb']} = ((((((((('http://farm' . ${${'GLOBALS'}['kbqsuyo']}['farm']) . '.static.flickr.com/') . ${$fertbb}['server']) . '/') . ${${'GLOBALS'}['kbqsuyo']}['id']) . '_') . ${${'GLOBALS'}['kbqsuyo']}['originalsecret']) . '_o') . '.') . ${${'GLOBALS'}['dqfuenpywr']}['originalformat'];
        } else {
            $qmtftmqsgp = 'photo';
            ${'GLOBALS'}['qrzagcjce'] = 'sizes';
            ${${'GLOBALS'}['vnugmpqtyg']} = (((((((('http://farm' . ${${'GLOBALS'}['kbqsuyo']}['farm']) . '.static.flickr.com/') . ${${'GLOBALS'}['kbqsuyo']}['server']) . '/') . ${$qmtftmqsgp}['id']) . '_') . ${${'GLOBALS'}['kbqsuyo']}['secret']) . ${${'GLOBALS'}['qrzagcjce']}[${${'GLOBALS'}['ymnwmx']}]) . '.jpg';
        }
        return ${${'GLOBALS'}['vnugmpqtyg']};
    }
    public function getFriendlyGeodata($lat, $lon)
    {
        return unserialize(file_get_contents((('http://phpflickr.com/geodata/?format=php&lat=' . ${${'GLOBALS'}['foerajlewfo']}) . '&lon=') . ${${'GLOBALS'}['vueqvjefi']}));
    }
    public function sync_upload($photo, $title = null, $description = null, $tags = null, $is_public = null, $is_friend = null, $is_family = null)
    {
        if (function_exists('curl_init')) {
            $wxpnpqgfnx = 'description';
            ${'GLOBALS'}['grnwkumq'] = 'is_public';
            ${'GLOBALS'}['soxfofy'] = 'tags';
            ${'GLOBALS'}['gtudqrimcbl'] = 'args';
            ${'GLOBALS'}['yfbykwpol'] = 'is_family';
            ${'GLOBALS'}['rwgntsqrbp'] = 'is_friend';
            ${'GLOBALS'}['ggicdfn'] = 'curl';
            $hsmbleq = 'auth_sig';
            $yqcnudq = 'response';
            ${'GLOBALS'}['dvimguwmk'] = 'key';
            ${${'GLOBALS'}['ckyndtgc']} = array('api_key' => $this->api_key, 'title' => ${${'GLOBALS'}['wqtygwsz']}, 'description' => ${$wxpnpqgfnx}, 'tags' => ${${'GLOBALS'}['soxfofy']}, 'is_public' => ${${'GLOBALS'}['grnwkumq']}, 'is_friend' => ${${'GLOBALS'}['rwgntsqrbp']}, 'is_family' => ${${'GLOBALS'}['yfbykwpol']});
            ${'GLOBALS'}['rmaeijseslt'] = 'args';
            $jheafetmc = 'data';
            ksort(${${'GLOBALS'}['rmaeijseslt']});
            ${$hsmbleq} = '';
            foreach (${${'GLOBALS'}['ckyndtgc']} as ${${'GLOBALS'}['dvimguwmk']} => ${$jheafetmc}) {
                ${'GLOBALS'}['hazazopv'] = 'data';
                if (is_null(${${'GLOBALS'}['hazazopv']})) {
                    unset(${${'GLOBALS'}['ckyndtgc']}[${${'GLOBALS'}['gjejvzeg']}]);
                } else {
                    ${'GLOBALS'}['vxdmdbbfdp'] = 'auth_sig';
                    ${'GLOBALS'}['vjuzxxt'] = 'data';
                    ${${'GLOBALS'}['vxdmdbbfdp']} .= ${${'GLOBALS'}['gjejvzeg']} . ${${'GLOBALS'}['vjuzxxt']};
                }
            }
            ${'GLOBALS'}['enitjrgfes'] = 'args';
            if (!empty($this->secret)) {
                $njiksnkgv = 'api_sig';
                ${$njiksnkgv} = md5($this->secret . ${${'GLOBALS'}['vdruzhum']});
                ${${'GLOBALS'}['ckyndtgc']}['api_sig'] = ${${'GLOBALS'}['pcierhxmg']};
            }
            $swliybsmbkt = 'curl';
            $cktvvcsktpw = 'args';
            ${'GLOBALS'}['vchxcmhks'] = 'args';
            $ubloypwnbt = 'photo';
            ${'GLOBALS'}['lsrsekkg'] = 'line';
            ${'GLOBALS'}['ivglfqdxyht'] = 'curl';
            ${${'GLOBALS'}['gtudqrimcbl']} = $this->getArgOauth($this->upload_endpoint, ${$cktvvcsktpw});
            ${${'GLOBALS'}['kbqsuyo']} = realpath(${${'GLOBALS'}['kbqsuyo']});
            ${${'GLOBALS'}['enitjrgfes']}['photo'] = '@' . ${$ubloypwnbt};
            ${${'GLOBALS'}['ivglfqdxyht']} = curl_init($this->upload_endpoint);
            curl_setopt(${${'GLOBALS'}['uubbdhfrc']}, CURLOPT_POST, true);
            curl_setopt(${$swliybsmbkt}, CURLOPT_POSTFIELDS, ${${'GLOBALS'}['vchxcmhks']});
            curl_setopt(${${'GLOBALS'}['uubbdhfrc']}, CURLOPT_RETURNTRANSFER, true);
            ${$yqcnudq} = curl_exec(${${'GLOBALS'}['uubbdhfrc']});
            $this->response = ${${'GLOBALS'}['xwnretuddof']};
            curl_close(${${'GLOBALS'}['ggicdfn']});
            ${${'GLOBALS'}['dscdjohpgr']} = explode('
', ${${'GLOBALS'}['xwnretuddof']});
            foreach (${${'GLOBALS'}['dscdjohpgr']} as ${${'GLOBALS'}['lsrsekkg']}) {
                if (preg_match('|<err code="([0-9]+)" msg="(.*)"|', ${${'GLOBALS'}['ineifmbdkt']}, ${${'GLOBALS'}['tkxxpbqrkjm']})) {
                    if ($this->die_on_error) {
                        die("The Flickr API returned the following error: #{$match[1]} - {$match[2]}");
                    } else {
                        $this->error_code = ${${'GLOBALS'}['tkxxpbqrkjm']}[1];
                        $this->error_msg = ${${'GLOBALS'}['tkxxpbqrkjm']}[2];
                        $this->parsed_response = false;
                        return false;
                    }
                } elseif (preg_match('|<photoid>(.*)</photoid>|', ${${'GLOBALS'}['ineifmbdkt']}, ${${'GLOBALS'}['tkxxpbqrkjm']})) {
                    $this->error_code = false;
                    $this->error_msg = false;
                    ${'GLOBALS'}['snmode'] = 'match';
                    return ${${'GLOBALS'}['snmode']}[1];
                }
            }
        } else {
            die('Sorry, your server must support CURL in order to upload files');
        }
    }
    public function async_upload($photo, $title = null, $description = null, $tags = null, $is_public = null, $is_friend = null, $is_family = null)
    {
        if (function_exists('curl_init')) {
            $udepvboihxk = 'curl';
            ${'GLOBALS'}['jblgoxzfm'] = 'response';
            ${'GLOBALS'}['yczdly'] = 'args';
            $swinoglempay = 'curl';
            $hbnywwmnggb = 'title';
            ${'GLOBALS'}['qgfuievazh'] = 'rsp';
            ${'GLOBALS'}['lejxnj'] = 'description';
            $fkvllpnwcca = 'curl';
            $laopgocun = 'args';
            $ceaktjbpo = 'args';
            $qugfpyqfgud = 'is_family';
            ${'GLOBALS'}['vsurtnoq'] = 'key';
            ${'GLOBALS'}['iejiqbpgp'] = 'is_public';
            $eebxwoc = 'photo';
            $lccjwkyqqrr = 'tags';
            ${'GLOBALS'}['dtnhclpd'] = 'args';
            ${'GLOBALS'}['tpgdiy'] = 'line';
            ${'GLOBALS'}['ghrpggu'] = 'curl';
            ${${'GLOBALS'}['ckyndtgc']} = array('async' => 1, 'api_key' => $this->api_key, 'title' => ${$hbnywwmnggb}, 'description' => ${${'GLOBALS'}['lejxnj']}, 'tags' => ${$lccjwkyqqrr}, 'is_public' => ${${'GLOBALS'}['iejiqbpgp']}, 'is_friend' => ${${'GLOBALS'}['jghofqo']}, 'is_family' => ${$qugfpyqfgud});
            ksort(${$ceaktjbpo});
            ${${'GLOBALS'}['vdruzhum']} = '';
            foreach (${${'GLOBALS'}['yczdly']} as ${${'GLOBALS'}['vsurtnoq']} => ${${'GLOBALS'}['bqepcs']}) {
                $iluobovjlh = 'data';
                if (is_null(${$iluobovjlh})) {
                    $ovnurh = 'key';
                    unset(${${'GLOBALS'}['ckyndtgc']}[${$ovnurh}]);
                } else {
                    $mqvhjznnsg = 'auth_sig';
                    ${'GLOBALS'}['wbbkgigu'] = 'key';
                    ${$mqvhjznnsg} .= ${${'GLOBALS'}['wbbkgigu']} . ${${'GLOBALS'}['bqepcs']};
                }
            }
            if (!empty($this->secret)) {
                ${'GLOBALS'}['ddxkiocybx'] = 'api_sig';
                $gsrvmajmdjly = 'auth_sig';
                ${${'GLOBALS'}['ddxkiocybx']} = md5($this->secret . ${$gsrvmajmdjly});
                ${${'GLOBALS'}['ckyndtgc']}['api_sig'] = ${${'GLOBALS'}['pcierhxmg']};
            }
            $nmpxkid = 'args';
            $lwhzbqm = 'photo';
            $xszxopgm = 'response';
            ${$nmpxkid} = $this->getArgOauth($this->upload_endpoint, ${${'GLOBALS'}['dtnhclpd']});
            ${$lwhzbqm} = realpath(${${'GLOBALS'}['kbqsuyo']});
            ${$laopgocun}['photo'] = '@' . ${$eebxwoc};
            ${$swinoglempay} = curl_init($this->upload_endpoint);
            curl_setopt(${${'GLOBALS'}['ghrpggu']}, CURLOPT_POST, true);
            curl_setopt(${${'GLOBALS'}['uubbdhfrc']}, CURLOPT_POSTFIELDS, ${${'GLOBALS'}['ckyndtgc']});
            curl_setopt(${$fkvllpnwcca}, CURLOPT_RETURNTRANSFER, true);
            ${${'GLOBALS'}['jblgoxzfm']} = curl_exec(${$udepvboihxk});
            $this->response = ${$xszxopgm};
            curl_close(${${'GLOBALS'}['uubbdhfrc']});
            ${${'GLOBALS'}['qgfuievazh']} = explode('
', ${${'GLOBALS'}['xwnretuddof']});
            foreach (${${'GLOBALS'}['dscdjohpgr']} as ${${'GLOBALS'}['tpgdiy']}) {
                ${'GLOBALS'}['ulpbwnkwgc'] = 'line';
                ${'GLOBALS'}['depzdkjg'] = 'line';
                if (preg_match('|<err code="([0-9]+)" msg="(.*)"|', ${${'GLOBALS'}['ulpbwnkwgc']}, ${${'GLOBALS'}['tkxxpbqrkjm']})) {
                    if ($this->die_on_error) {
                        die("The Flickr API returned the following error: #{$match[1]} - {$match[2]}");
                    } else {
                        $this->error_code = ${${'GLOBALS'}['tkxxpbqrkjm']}[1];
                        $this->error_msg = ${${'GLOBALS'}['tkxxpbqrkjm']}[2];
                        $this->parsed_response = false;
                        return false;
                    }
                } elseif (preg_match('|<ticketid>(.*)</|', ${${'GLOBALS'}['depzdkjg']}, ${${'GLOBALS'}['tkxxpbqrkjm']})) {
                    $this->error_code = false;
                    $this->error_msg = false;
                    return ${${'GLOBALS'}['tkxxpbqrkjm']}[1];
                }
            }
        } else {
            die('Sorry, your server must support CURL in order to upload files');
        }
    }
    public function replace($photo, $photo_id, $async = null)
    {
        if (function_exists('curl_init')) {
            ${'GLOBALS'}['mgcwjkm'] = 'args';
            ${'GLOBALS'}['dclkgxkr'] = 'async';
            ${${'GLOBALS'}['mgcwjkm']} = array('api_key' => $this->api_key, 'photo_id' => ${${'GLOBALS'}['urwunjsn']}, 'async' => ${${'GLOBALS'}['dclkgxkr']});
            ${'GLOBALS'}['duzofu'] = 'auth_sig';
            $bdjnzmmtva = 'response';
            ${'GLOBALS'}['siyochdbt'] = 'curl';
            ${'GLOBALS'}['ycrjxtv'] = 'args';
            $enphlpemrvh = 'curl';
            ksort(${${'GLOBALS'}['ckyndtgc']});
            ${${'GLOBALS'}['duzofu']} = '';
            $heyozcnryt = 'photo';
            foreach (${${'GLOBALS'}['ycrjxtv']} as ${${'GLOBALS'}['gjejvzeg']} => ${${'GLOBALS'}['bqepcs']}) {
                ${'GLOBALS'}['iikmohohg'] = 'data';
                if (is_null(${${'GLOBALS'}['iikmohohg']})) {
                    $xekcvvzu = 'args';
                    unset(${$xekcvvzu}[${${'GLOBALS'}['gjejvzeg']}]);
                } else {
                    $xonjnvz = 'auth_sig';
                    ${$xonjnvz} .= ${${'GLOBALS'}['gjejvzeg']} . ${${'GLOBALS'}['bqepcs']};
                }
            }
            ${'GLOBALS'}['ttyohpm'] = 'args';
            ${'GLOBALS'}['wplwkwrgwj'] = 'find';
            ${'GLOBALS'}['mpfnwxl'] = 'find';
            if (!empty($this->secret)) {
                $lelexggstu = 'api_sig';
                ${'GLOBALS'}['yhnxtrehoplo'] = 'api_sig';
                ${$lelexggstu} = md5($this->secret . ${${'GLOBALS'}['vdruzhum']});
                ${${'GLOBALS'}['ckyndtgc']}['api_sig'] = ${${'GLOBALS'}['yhnxtrehoplo']};
            }
            ${$heyozcnryt} = realpath(${${'GLOBALS'}['kbqsuyo']});
            $dwbrucwq = 'response';
            ${${'GLOBALS'}['ckyndtgc']}['photo'] = '@' . ${${'GLOBALS'}['kbqsuyo']};
            ${${'GLOBALS'}['ckyndtgc']} = $this->getArgOauth($this->replace_endpoint, ${${'GLOBALS'}['ckyndtgc']});
            $wvehnns = 'async';
            ${${'GLOBALS'}['uubbdhfrc']} = curl_init($this->replace_endpoint);
            ${'GLOBALS'}['mlahvoheldd'] = 'curl';
            curl_setopt(${${'GLOBALS'}['uubbdhfrc']}, CURLOPT_POST, true);
            curl_setopt(${$enphlpemrvh}, CURLOPT_POSTFIELDS, ${${'GLOBALS'}['ttyohpm']});
            $ddogrzpalpsi = 'curl';
            curl_setopt(${${'GLOBALS'}['siyochdbt']}, CURLOPT_RETURNTRANSFER, true);
            ${$bdjnzmmtva} = curl_exec(${${'GLOBALS'}['mlahvoheldd']});
            $this->response = ${$dwbrucwq};
            curl_close(${$ddogrzpalpsi});
            if (${$wvehnns} == 1) {
                ${${'GLOBALS'}['wplwkwrgwj']} = 'ticketid';
            } else {
                ${${'GLOBALS'}['mpfnwxl']} = 'photoid';
            }
            ${'GLOBALS'}['dbcgqcmp'] = 'line';
            ${${'GLOBALS'}['dscdjohpgr']} = explode('
', ${${'GLOBALS'}['xwnretuddof']});
            foreach (${${'GLOBALS'}['dscdjohpgr']} as ${${'GLOBALS'}['dbcgqcmp']}) {
                $jlqnubvpn = 'match';
                $hcxgujeoj = 'line';
                if (preg_match('|<err code="([0-9]+)" msg="(.*)"|', ${$hcxgujeoj}, ${$jlqnubvpn})) {
                    if ($this->die_on_error) {
                        die("The Flickr API returned the following error: #{$match[1]} - {$match[2]}");
                    } else {
                        ${'GLOBALS'}['pzcvxtnmzd'] = 'match';
                        $this->error_code = ${${'GLOBALS'}['pzcvxtnmzd']}[1];
                        $this->error_msg = ${${'GLOBALS'}['tkxxpbqrkjm']}[2];
                        $this->parsed_response = false;
                        return false;
                    }
                } elseif (preg_match(('|<' . ${${'GLOBALS'}['xnjjys']}) . '>(.*)</|', ${${'GLOBALS'}['ineifmbdkt']}, ${${'GLOBALS'}['tkxxpbqrkjm']})) {
                    $this->error_code = false;
                    $this->error_msg = false;
                    return ${${'GLOBALS'}['tkxxpbqrkjm']}[1];
                }
            }
        } else {
            die('Sorry, your server must support CURL in order to upload files');
        }
    }
    public function call($method, $arguments)
    {
        $tiphzgkpanx = 'method';
        $lrnjcmcac = 'key';
        $kbwndfbygg = 'arguments';
        foreach (${$kbwndfbygg} as ${$lrnjcmcac} => ${${'GLOBALS'}['sdcopkopk']}) {
            ${'GLOBALS'}['lmzgjfnll'] = 'value';
            if (is_null(${${'GLOBALS'}['lmzgjfnll']})) {
                unset(${${'GLOBALS'}['ehqbmxlrfjdl']}[${${'GLOBALS'}['gjejvzeg']}]);
            }
        }
        $this->request(${$tiphzgkpanx}, ${${'GLOBALS'}['ehqbmxlrfjdl']});
        return $this->parsed_response ? $this->parsed_response : false;
    }
    public function activity_userComments($per_page = NULL, $page = NULL)
    {
        $this->request('flickr.activity.userComments', array('per_page' => ${${'GLOBALS'}['fcernn']}, 'page' => ${${'GLOBALS'}['xapovj']}));
        return $this->parsed_response ? $this->parsed_response['items']['item'] : false;
    }
    public function activity_userPhotos($timeframe = NULL, $per_page = NULL, $page = NULL)
    {
        ${'GLOBALS'}['yuhswfxkd'] = 'page';
        $this->request('flickr.activity.userPhotos', array('timeframe' => ${${'GLOBALS'}['ncxpxsoyvj']}, 'per_page' => ${${'GLOBALS'}['fcernn']}, 'page' => ${${'GLOBALS'}['yuhswfxkd']}));
        return $this->parsed_response ? $this->parsed_response['items']['item'] : false;
    }
    public function blogs_getList($service = NULL)
    {
        ${'GLOBALS'}['suqfogwglfyv'] = 'service';
        ${${'GLOBALS'}['dscdjohpgr']} = $this->call('flickr.blogs.getList', array('service' => ${${'GLOBALS'}['suqfogwglfyv']}));
        return ${${'GLOBALS'}['dscdjohpgr']}['blogs']['blog'];
    }
    public function blogs_getServices()
    {
        return $this->call('flickr.blogs.getServices', array());
    }
    public function blogs_postPhoto($blog_id = NULL, $photo_id, $title, $description, $blog_password = NULL, $service = NULL)
    {
        ${'GLOBALS'}['vbkbtkkvew'] = 'service';
        ${'GLOBALS'}['vuvpmxxjbbol'] = 'description';
        return $this->call('flickr.blogs.postPhoto', array('blog_id' => ${${'GLOBALS'}['kwfzblc']}, 'photo_id' => ${${'GLOBALS'}['urwunjsn']}, 'title' => ${${'GLOBALS'}['wqtygwsz']}, 'description' => ${${'GLOBALS'}['vuvpmxxjbbol']}, 'blog_password' => ${${'GLOBALS'}['akmahehho']}, 'service' => ${${'GLOBALS'}['vbkbtkkvew']}));
    }
    public function collections_getInfo($collection_id)
    {
        return $this->call('flickr.collections.getInfo', array('collection_id' => ${${'GLOBALS'}['bciltw']}));
    }
    public function collections_getTree($collection_id = NULL, $user_id = NULL)
    {
        $pfeoqfsv = 'collection_id';
        $rnkmmmmdwq = 'user_id';
        return $this->call('flickr.collections.getTree', array('collection_id' => ${$pfeoqfsv}, 'user_id' => ${$rnkmmmmdwq}));
    }
    public function commons_getInstitutions()
    {
        return $this->call('flickr.commons.getInstitutions', array());
    }
    public function contacts_getList($filter = NULL, $page = NULL, $per_page = NULL)
    {
        ${'GLOBALS'}['bvgvxxajvnp'] = 'per_page';
        $this->request('flickr.contacts.getList', array('filter' => ${${'GLOBALS'}['sedhlo']}, 'page' => ${${'GLOBALS'}['xapovj']}, 'per_page' => ${${'GLOBALS'}['bvgvxxajvnp']}));
        return $this->parsed_response ? $this->parsed_response['contacts'] : false;
    }
    public function contacts_getPublicList($user_id, $page = NULL, $per_page = NULL)
    {
        $egwymvwej = 'user_id';
        ${'GLOBALS'}['xzmelgrocz'] = 'per_page';
        $this->request('flickr.contacts.getPublicList', array('user_id' => ${$egwymvwej}, 'page' => ${${'GLOBALS'}['xapovj']}, 'per_page' => ${${'GLOBALS'}['xzmelgrocz']}));
        return $this->parsed_response ? $this->parsed_response['contacts'] : false;
    }
    public function contacts_getListRecentlyUploaded($date_lastupload = NULL, $filter = NULL)
    {
        ${'GLOBALS'}['mnhgpglw'] = 'date_lastupload';
        ${'GLOBALS'}['hvujpfncyd'] = 'filter';
        return $this->call('flickr.contacts.getListRecentlyUploaded', array('date_lastupload' => ${${'GLOBALS'}['mnhgpglw']}, 'filter' => ${${'GLOBALS'}['hvujpfncyd']}));
    }
    public function favorites_add($photo_id)
    {
        $this->request('flickr.favorites.add', array('photo_id' => ${${'GLOBALS'}['urwunjsn']}), TRUE);
        return $this->parsed_response ? true : false;
    }
    public function favorites_getList($user_id = NULL, $jump_to = NULL, $min_fave_date = NULL, $max_fave_date = NULL, $extras = NULL, $per_page = NULL, $page = NULL)
    {
        $qxxskouufbef = 'jump_to';
        ${'GLOBALS'}['wfbdwggx'] = 'max_fave_date';
        return $this->call('flickr.favorites.getList', array('user_id' => ${${'GLOBALS'}['wpugylrxl']}, 'jump_to' => ${$qxxskouufbef}, 'min_fave_date' => ${${'GLOBALS'}['sqyenjebph']}, 'max_fave_date' => ${${'GLOBALS'}['wfbdwggx']}, 'extras' => ${${'GLOBALS'}['nwlxjjrhmx']}, 'per_page' => ${${'GLOBALS'}['fcernn']}, 'page' => ${${'GLOBALS'}['xapovj']}));
    }
    public function favorites_getPublicList($user_id, $jump_to = NULL, $min_fave_date = NULL, $max_fave_date = NULL, $extras = NULL, $per_page = NULL, $page = NULL)
    {
        ${'GLOBALS'}['qecfwddiwc'] = 'user_id';
        ${'GLOBALS'}['jpvwbevq'] = 'page';
        $twewosi = 'per_page';
        ${'GLOBALS'}['aqydrgydu'] = 'jump_to';
        return $this->call('flickr.favorites.getPublicList', array('user_id' => ${${'GLOBALS'}['qecfwddiwc']}, 'jump_to' => ${${'GLOBALS'}['aqydrgydu']}, 'min_fave_date' => ${${'GLOBALS'}['sqyenjebph']}, 'max_fave_date' => ${${'GLOBALS'}['kacgczftwkc']}, 'extras' => ${${'GLOBALS'}['nwlxjjrhmx']}, 'per_page' => ${$twewosi}, 'page' => ${${'GLOBALS'}['jpvwbevq']}));
    }
    public function favorites_remove($photo_id, $user_id = NULL)
    {
        $chvunleqls = 'photo_id';
        $this->request('flickr.favorites.remove', array('photo_id' => ${$chvunleqls}, 'user_id' => ${${'GLOBALS'}['wpugylrxl']}), TRUE);
        return $this->parsed_response ? true : false;
    }
    public function galleries_addPhoto($gallery_id, $photo_id, $comment = NULL)
    {
        ${'GLOBALS'}['nykbtdiig'] = 'photo_id';
        ${'GLOBALS'}['qybcbt'] = 'gallery_id';
        return $this->call('flickr.galleries.addPhoto', array('gallery_id' => ${${'GLOBALS'}['qybcbt']}, 'photo_id' => ${${'GLOBALS'}['nykbtdiig']}, 'comment' => ${${'GLOBALS'}['noyljduo']}));
    }
    public function galleries_create($title, $description, $primary_photo_id = NULL)
    {
        ${'GLOBALS'}['fqdnvfo'] = 'title';
        $arxqwmbsrefd = 'description';
        return $this->call('flickr.galleries.create', array('title' => ${${'GLOBALS'}['fqdnvfo']}, 'description' => ${$arxqwmbsrefd}, 'primary_photo_id' => ${${'GLOBALS'}['rcqhvj']}));
    }
    public function galleries_editMeta($gallery_id, $title, $description = NULL)
    {
        $kyqbyflae = 'title';
        return $this->call('flickr.galleries.editMeta', array('gallery_id' => ${${'GLOBALS'}['pgoydckvise']}, 'title' => ${$kyqbyflae}, 'description' => ${${'GLOBALS'}['ebqvkbxla']}));
    }
    public function galleries_editPhoto($gallery_id, $photo_id, $comment)
    {
        $pvphplctyrf = 'photo_id';
        ${'GLOBALS'}['lzbymweo'] = 'gallery_id';
        return $this->call('flickr.galleries.editPhoto', array('gallery_id' => ${${'GLOBALS'}['lzbymweo']}, 'photo_id' => ${$pvphplctyrf}, 'comment' => ${${'GLOBALS'}['noyljduo']}));
    }
    public function galleries_editPhotos($gallery_id, $primary_photo_id, $photo_ids)
    {
        ${'GLOBALS'}['iimrhyypgcwr'] = 'photo_ids';
        $vwdnnokwzl = 'gallery_id';
        return $this->call('flickr.galleries.editPhotos', array('gallery_id' => ${$vwdnnokwzl}, 'primary_photo_id' => ${${'GLOBALS'}['rcqhvj']}, 'photo_ids' => ${${'GLOBALS'}['iimrhyypgcwr']}));
    }
    public function galleries_getInfo($gallery_id)
    {
        return $this->call('flickr.galleries.getInfo', array('gallery_id' => ${${'GLOBALS'}['pgoydckvise']}));
    }
    public function galleries_getList($user_id, $per_page = NULL, $page = NULL)
    {
        ${'GLOBALS'}['mxxfmwwrf'] = 'user_id';
        return $this->call('flickr.galleries.getList', array('user_id' => ${${'GLOBALS'}['mxxfmwwrf']}, 'per_page' => ${${'GLOBALS'}['fcernn']}, 'page' => ${${'GLOBALS'}['xapovj']}));
    }
    public function galleries_getListForPhoto($photo_id, $per_page = NULL, $page = NULL)
    {
        ${'GLOBALS'}['vdthwxwaonoq'] = 'photo_id';
        ${'GLOBALS'}['gfpzrig'] = 'page';
        return $this->call('flickr.galleries.getListForPhoto', array('photo_id' => ${${'GLOBALS'}['vdthwxwaonoq']}, 'per_page' => ${${'GLOBALS'}['fcernn']}, 'page' => ${${'GLOBALS'}['gfpzrig']}));
    }
    public function galleries_getPhotos($gallery_id, $extras = NULL, $per_page = NULL, $page = NULL)
    {
        $tmuzcolmtdv = 'per_page';
        ${'GLOBALS'}['mbonbromzd'] = 'gallery_id';
        return $this->call('flickr.galleries.getPhotos', array('gallery_id' => ${${'GLOBALS'}['mbonbromzd']}, 'extras' => ${${'GLOBALS'}['nwlxjjrhmx']}, 'per_page' => ${$tmuzcolmtdv}, 'page' => ${${'GLOBALS'}['xapovj']}));
    }
    public function groups_browse($cat_id = NULL)
    {
        ${'GLOBALS'}['pnrnsjj'] = 'cat_id';
        $this->request('flickr.groups.browse', array('cat_id' => ${${'GLOBALS'}['pnrnsjj']}));
        return $this->parsed_response ? $this->parsed_response['category'] : false;
    }
    public function groups_getInfo($group_id, $lang = NULL)
    {
        return $this->call('flickr.groups.getInfo', array('group_id' => ${${'GLOBALS'}['lwdqkexf']}, 'lang' => ${${'GLOBALS'}['whdlzolqgpb']}));
    }
    public function groups_search($text, $per_page = NULL, $page = NULL)
    {
        ${'GLOBALS'}['houpjodpreb'] = 'page';
        $this->request('flickr.groups.search', array('text' => ${${'GLOBALS'}['kueflpmp']}, 'per_page' => ${${'GLOBALS'}['fcernn']}, 'page' => ${${'GLOBALS'}['houpjodpreb']}));
        return $this->parsed_response ? $this->parsed_response['groups'] : false;
    }
    public function groups_members_getList($group_id, $membertypes = NULL, $per_page = NULL, $page = NULL)
    {
        ${'GLOBALS'}['mgvbng'] = 'per_page';
        $lplpux = 'membertypes';
        $nuusfdm = 'group_id';
        return $this->call('flickr.groups.members.getList', array('group_id' => ${$nuusfdm}, 'membertypes' => ${$lplpux}, 'per_page' => ${${'GLOBALS'}['mgvbng']}, 'page' => ${${'GLOBALS'}['xapovj']}));
    }
    public function groups_pools_add($photo_id, $group_id)
    {
        $this->request('flickr.groups.pools.add', array('photo_id' => ${${'GLOBALS'}['urwunjsn']}, 'group_id' => ${${'GLOBALS'}['lwdqkexf']}), TRUE);
        return $this->parsed_response ? true : false;
    }
    public function groups_pools_getContext($photo_id, $group_id, $num_prev = NULL, $num_next = NULL)
    {
        $fowwueni = 'num_next';
        return $this->call('flickr.groups.pools.getContext', array('photo_id' => ${${'GLOBALS'}['urwunjsn']}, 'group_id' => ${${'GLOBALS'}['lwdqkexf']}, 'num_prev' => ${${'GLOBALS'}['ojuosqw']}, 'num_next' => ${$fowwueni}));
    }
    public function groups_pools_getGroups($page = NULL, $per_page = NULL)
    {
        $this->request('flickr.groups.pools.getGroups', array('page' => ${${'GLOBALS'}['xapovj']}, 'per_page' => ${${'GLOBALS'}['fcernn']}));
        return $this->parsed_response ? $this->parsed_response['groups'] : false;
    }
    public function groups_pools_getPhotos($group_id, $tags = NULL, $user_id = NULL, $jump_to = NULL, $extras = NULL, $per_page = NULL, $page = NULL)
    {
        ${'GLOBALS'}['hmjtvhifqyr'] = 'extras';
        $ofieewtrkhm = 'group_id';
        $zhmjsfmeb = 'tags';
        ${'GLOBALS'}['hmfbnrxdp'] = 'extras';
        if (is_array(${${'GLOBALS'}['hmjtvhifqyr']})) {
            ${'GLOBALS'}['bbipwikjwx'] = 'extras';
            ${${'GLOBALS'}['bbipwikjwx']} = implode(',', ${${'GLOBALS'}['nwlxjjrhmx']});
        }
        return $this->call('flickr.groups.pools.getPhotos', array('group_id' => ${$ofieewtrkhm}, 'tags' => ${$zhmjsfmeb}, 'user_id' => ${${'GLOBALS'}['wpugylrxl']}, 'jump_to' => ${${'GLOBALS'}['gnnvjwn']}, 'extras' => ${${'GLOBALS'}['hmfbnrxdp']}, 'per_page' => ${${'GLOBALS'}['fcernn']}, 'page' => ${${'GLOBALS'}['xapovj']}));
    }
    public function groups_pools_remove($photo_id, $group_id)
    {
        ${'GLOBALS'}['darsjpkik'] = 'group_id';
        $bwzfnwumqr = 'photo_id';
        $this->request('flickr.groups.pools.remove', array('photo_id' => ${$bwzfnwumqr}, 'group_id' => ${${'GLOBALS'}['darsjpkik']}), TRUE);
        return $this->parsed_response ? true : false;
    }
    public function interestingness_getList($date = NULL, $use_panda = NULL, $extras = NULL, $per_page = NULL, $page = NULL)
    {
        if (is_array(${${'GLOBALS'}['nwlxjjrhmx']})) {
            ${${'GLOBALS'}['nwlxjjrhmx']} = implode(',', ${${'GLOBALS'}['nwlxjjrhmx']});
        }
        return $this->call('flickr.interestingness.getList', array('date' => ${${'GLOBALS'}['ejfkcbwayj']}, 'use_panda' => ${${'GLOBALS'}['mxljvgsts']}, 'extras' => ${${'GLOBALS'}['nwlxjjrhmx']}, '</p>' => ${${'GLOBALS'}['fcernn']}, 'page' => ${${'GLOBALS'}['xapovj']}));
    }
    public function machinetags_getNamespaces($predicate = NULL, $per_page = NULL, $page = NULL)
    {
        ${'GLOBALS'}['aspilgm'] = 'predicate';
        return $this->call('flickr.machinetags.getNamespaces', array('predicate' => ${${'GLOBALS'}['aspilgm']}, 'per_page' => ${${'GLOBALS'}['fcernn']}, 'page' => ${${'GLOBALS'}['xapovj']}));
    }
    public function machinetags_getPairs($namespace = NULL, $predicate = NULL, $per_page = NULL, $page = NULL)
    {
        ${'GLOBALS'}['siodzgty'] = 'page';
        ${'GLOBALS'}['ytbqxlyps'] = 'predicate';
        ${'GLOBALS'}['cjclzglfxbm'] = 'namespace';
        return $this->call('flickr.machinetags.getPairs', array('namespace' => ${${'GLOBALS'}['cjclzglfxbm']}, 'predicate' => ${${'GLOBALS'}['ytbqxlyps']}, 'per_page' => ${${'GLOBALS'}['fcernn']}, 'page' => ${${'GLOBALS'}['siodzgty']}));
    }
    public function machinetags_getPredicates($namespace = NULL, $per_page = NULL, $page = NULL)
    {
        return $this->call('flickr.machinetags.getPredicates', array('namespace' => ${${'GLOBALS'}['qgnnqgzeijb']}, 'per_page' => ${${'GLOBALS'}['fcernn']}, 'page' => ${${'GLOBALS'}['xapovj']}));
    }
    public function machinetags_getRecentValues($namespace = NULL, $predicate = NULL, $added_since = NULL)
    {
        $iestgyq = 'added_since';
        return $this->call('flickr.machinetags.getRecentValues', array('namespace' => ${${'GLOBALS'}['qgnnqgzeijb']}, 'predicate' => ${${'GLOBALS'}['qtminf']}, 'added_since' => ${$iestgyq}));
    }
    public function machinetags_getValues($namespace, $predicate, $per_page = NULL, $page = NULL, $usage = NULL)
    {
        ${'GLOBALS'}['mwfmiw'] = 'namespace';
        ${'GLOBALS'}['zcvqnmcblj'] = 'per_page';
        return $this->call('flickr.machinetags.getValues', array('namespace' => ${${'GLOBALS'}['mwfmiw']}, 'predicate' => ${${'GLOBALS'}['qtminf']}, 'per_page' => ${${'GLOBALS'}['zcvqnmcblj']}, 'page' => ${${'GLOBALS'}['xapovj']}, 'usage' => ${${'GLOBALS'}['vtymnafzj']}));
    }
    public function panda_getList()
    {
        return $this->call('flickr.panda.getList', array());
    }
    public function panda_getPhotos($panda_name, $extras = NULL, $per_page = NULL, $page = NULL)
    {
        ${'GLOBALS'}['ntjdjsnj'] = 'extras';
        $lqypnvcdkbpp = 'panda_name';
        return $this->call('flickr.panda.getPhotos', array('panda_name' => ${$lqypnvcdkbpp}, 'extras' => ${${'GLOBALS'}['ntjdjsnj']}, 'per_page' => ${${'GLOBALS'}['fcernn']}, 'page' => ${${'GLOBALS'}['xapovj']}));
    }
    public function people_findByEmail($find_email)
    {
        ${'GLOBALS'}['lxpbomlcxyh'] = 'find_email';
        $this->request('flickr.people.findByEmail', array('find_email' => ${${'GLOBALS'}['lxpbomlcxyh']}));
        return $this->parsed_response ? $this->parsed_response['user'] : false;
    }
    public function people_findByUsername($username)
    {
        $dnbyplsx = 'username';
        $this->request('flickr.people.findByUsername', array('username' => ${$dnbyplsx}));
        return $this->parsed_response ? $this->parsed_response['user'] : false;
    }
    public function people_getInfo($user_id)
    {
        $this->request('flickr.people.getInfo', array('user_id' => ${${'GLOBALS'}['wpugylrxl']}));
        return $this->parsed_response ? $this->parsed_response['person'] : false;
    }
    public function people_getPhotos($user_id, $args = array())
    {
        $hyxpjkl = 'user_id';
        ${'GLOBALS'}['jlpiecsjua'] = 'args';
        return $this->call('flickr.people.getPhotos', array_merge(array('user_id' => ${$hyxpjkl}), ${${'GLOBALS'}['jlpiecsjua']}));
    }
    public function people_getPhotosOf($user_id, $extras = NULL, $per_page = NULL, $page = NULL)
    {
        $gbrurthiyi = 'extras';
        $nipbgzcv = 'per_page';
        return $this->call('flickr.people.getPhotosOf', array('user_id' => ${${'GLOBALS'}['wpugylrxl']}, 'extras' => ${$gbrurthiyi}, 'per_page' => ${$nipbgzcv}, 'page' => ${${'GLOBALS'}['xapovj']}));
    }
    public function people_getPublicGroups($user_id)
    {
        $this->request('flickr.people.getPublicGroups', array('user_id' => ${${'GLOBALS'}['wpugylrxl']}));
        return $this->parsed_response ? $this->parsed_response['groups']['group'] : false;
    }
    public function people_getPublicPhotos($user_id, $safe_search = NULL, $extras = NULL, $per_page = NULL, $page = NULL)
    {
        return $this->call('flickr.people.getPublicPhotos', array('user_id' => ${${'GLOBALS'}['wpugylrxl']}, 'safe_search' => ${${'GLOBALS'}['iuivse']}, 'extras' => ${${'GLOBALS'}['nwlxjjrhmx']}, 'per_page' => ${${'GLOBALS'}['fcernn']}, 'page' => ${${'GLOBALS'}['xapovj']}));
    }
    public function people_getUploadStatus()
    {
        $this->request('flickr.people.getUploadStatus');
        return $this->parsed_response ? $this->parsed_response['user'] : false;
    }
    public function photos_addTags($photo_id, $tags)
    {
        $umrppvhr = 'photo_id';
        $this->request('flickr.photos.addTags', array('photo_id' => ${$umrppvhr}, 'tags' => ${${'GLOBALS'}['rmkmdgfu']}), TRUE);
        return $this->parsed_response ? true : false;
    }
    public function photos_delete($photo_id)
    {
        $this->request('flickr.photos.delete', array('photo_id' => ${${'GLOBALS'}['urwunjsn']}), TRUE);
        return $this->parsed_response ? true : false;
    }
    public function photos_getAllContexts($photo_id)
    {
        $this->request('flickr.photos.getAllContexts', array('photo_id' => ${${'GLOBALS'}['urwunjsn']}));
        return $this->parsed_response ? $this->parsed_response : false;
    }
    public function photos_getContactsPhotos($count = NULL, $just_friends = NULL, $single_photo = NULL, $include_self = NULL, $extras = NULL)
    {
        $yrchkssv = 'single_photo';
        $yshrshkrgou = 'include_self';
        $gbuwnkihy = 'count';
        $this->request('flickr.photos.getContactsPhotos', array('count' => ${$gbuwnkihy}, 'just_friends' => ${${'GLOBALS'}['zbgrbnc']}, 'single_photo' => ${$yrchkssv}, 'include_self' => ${$yshrshkrgou}, 'extras' => ${${'GLOBALS'}['nwlxjjrhmx']}));
        return $this->parsed_response ? $this->parsed_response['photos']['photo'] : false;
    }
    public function photos_getContactsPublicPhotos($user_id, $count = NULL, $just_friends = NULL, $single_photo = NULL, $include_self = NULL, $extras = NULL)
    {
        ${'GLOBALS'}['lrngdphdkag'] = 'just_friends';
        $kpiymzhdhqj = 'user_id';
        $this->request('flickr.photos.getContactsPublicPhotos', array('user_id' => ${$kpiymzhdhqj}, 'count' => ${${'GLOBALS'}['hkawtqnihpru']}, 'just_friends' => ${${'GLOBALS'}['lrngdphdkag']}, 'single_photo' => ${${'GLOBALS'}['udxewhm']}, 'include_self' => ${${'GLOBALS'}['gpulfpcxh']}, 'extras' => ${${'GLOBALS'}['nwlxjjrhmx']}));
        return $this->parsed_response ? $this->parsed_response['photos']['photo'] : false;
    }
    public function photos_getContext($photo_id, $num_prev = NULL, $num_next = NULL, $extras = NULL, $order_by = NULL)
    {
        ${'GLOBALS'}['xqnyutm'] = 'num_prev';
        ${'GLOBALS'}['xfrcuytv'] = 'num_next';
        ${'GLOBALS'}['bzqteqc'] = 'extras';
        return $this->call('flickr.photos.getContext', array('photo_id' => ${${'GLOBALS'}['urwunjsn']}, 'num_prev' => ${${'GLOBALS'}['xqnyutm']}, 'num_next' => ${${'GLOBALS'}['xfrcuytv']}, 'extras' => ${${'GLOBALS'}['bzqteqc']}, 'order_by' => ${${'GLOBALS'}['tjclllc']}));
    }
    public function photos_getCounts($dates = NULL, $taken_dates = NULL)
    {
        $ueowdldpe = 'dates';
        $this->request('flickr.photos.getCounts', array('dates' => ${$ueowdldpe}, 'taken_dates' => ${${'GLOBALS'}['hymdvwnoj']}));
        return $this->parsed_response ? $this->parsed_response['photocounts']['photocount'] : false;
    }
    public function photos_getExif($photo_id, $secret = NULL)
    {
        ${'GLOBALS'}['lzudunqvfx'] = 'secret';
        $this->request('flickr.photos.getExif', array('photo_id' => ${${'GLOBALS'}['urwunjsn']}, 'secret' => ${${'GLOBALS'}['lzudunqvfx']}));
        return $this->parsed_response ? $this->parsed_response['photo'] : false;
    }
    public function photos_getFavorites($photo_id, $page = NULL, $per_page = NULL)
    {
        $rfrghdabz = 'per_page';
        $ystqtgujwiop = 'page';
        $this->request('flickr.photos.getFavorites', array('photo_id' => ${${'GLOBALS'}['urwunjsn']}, 'page' => ${$ystqtgujwiop}, 'per_page' => ${$rfrghdabz}));
        return $this->parsed_response ? $this->parsed_response['photo'] : false;
    }
    public function photos_getInfo($photo_id, $secret = NULL)
    {
        $gralir = 'photo_id';
        $kdqpgdrk = 'secret';
        return $this->call('flickr.photos.getInfo', array('photo_id' => ${$gralir}, 'secret' => ${$kdqpgdrk}));
    }
    public function photos_getNotInSet($max_upload_date = NULL, $min_taken_date = NULL, $max_taken_date = NULL, $privacy_filter = NULL, $media = NULL, $min_upload_date = NULL, $extras = NULL, $per_page = NULL, $page = NULL)
    {
        $stborxjzwgtx = 'media';
        ${'GLOBALS'}['imcjpthyh'] = 'max_upload_date';
        ${'GLOBALS'}['kltentwwm'] = 'max_taken_date';
        $vytqnfy = 'per_page';
        return $this->call('flickr.photos.getNotInSet', array('max_upload_date' => ${${'GLOBALS'}['imcjpthyh']}, 'min_taken_date' => ${${'GLOBALS'}['gtfzibjcodev']}, 'max_taken_date' => ${${'GLOBALS'}['kltentwwm']}, 'privacy_filter' => ${${'GLOBALS'}['gjuygohpi']}, 'media' => ${$stborxjzwgtx}, 'min_upload_date' => ${${'GLOBALS'}['nmqcxchab']}, 'extras' => ${${'GLOBALS'}['nwlxjjrhmx']}, 'per_page' => ${$vytqnfy}, 'page' => ${${'GLOBALS'}['xapovj']}));
    }
    public function photos_getPerms($photo_id)
    {
        $this->request('flickr.photos.getPerms', array('photo_id' => ${${'GLOBALS'}['urwunjsn']}));
        return $this->parsed_response ? $this->parsed_response['perms'] : false;
    }
    public function photos_getRecent($jump_to = NULL, $extras = NULL, $per_page = NULL, $page = NULL)
    {
        $gzmsmiqitb = 'extras';
        $vyproxmmpmh = 'per_page';
        ${'GLOBALS'}['kriglspbg'] = 'jump_to';
        ${'GLOBALS'}['fpnqrzrcva'] = 'extras';
        if (is_array(${$gzmsmiqitb})) {
            $jleoqseivyqm = 'extras';
            ${$jleoqseivyqm} = implode(',', ${${'GLOBALS'}['nwlxjjrhmx']});
        }
        return $this->call('flickr.photos.getRecent', array('jump_to' => ${${'GLOBALS'}['kriglspbg']}, 'extras' => ${${'GLOBALS'}['fpnqrzrcva']}, 'per_page' => ${$vyproxmmpmh}, 'page' => ${${'GLOBALS'}['xapovj']}));
    }
    public function photos_getSizes($photo_id)
    {
        $this->request('flickr.photos.getSizes', array('photo_id' => ${${'GLOBALS'}['urwunjsn']}));
        return $this->parsed_response ? $this->parsed_response['sizes']['size'] : false;
    }
    public function photos_getUntagged($min_upload_date = NULL, $max_upload_date = NULL, $min_taken_date = NULL, $max_taken_date = NULL, $privacy_filter = NULL, $media = NULL, $extras = NULL, $per_page = NULL, $page = NULL)
    {
        ${'GLOBALS'}['mroevcwuzsm'] = 'min_upload_date';
        ${'GLOBALS'}['xrvcyul'] = 'privacy_filter';
        ${'GLOBALS'}['ehfyknmqug'] = 'extras';
        $anoqkmdjcor = 'max_taken_date';
        return $this->call('flickr.photos.getUntagged', array('min_upload_date' => ${${'GLOBALS'}['mroevcwuzsm']}, 'max_upload_date' => ${${'GLOBALS'}['vxhyocqthma']}, 'min_taken_date' => ${${'GLOBALS'}['gtfzibjcodev']}, 'max_taken_date' => ${$anoqkmdjcor}, 'privacy_filter' => ${${'GLOBALS'}['xrvcyul']}, 'media' => ${${'GLOBALS'}['rchrxixlunz']}, 'extras' => ${${'GLOBALS'}['ehfyknmqug']}, 'per_page' => ${${'GLOBALS'}['fcernn']}, 'page' => ${${'GLOBALS'}['xapovj']}));
    }
    public function photos_getWithGeoData($args = array())
    {
        $this->request('flickr.photos.getWithGeoData', ${${'GLOBALS'}['ckyndtgc']});
        return $this->parsed_response ? $this->parsed_response['photos'] : false;
    }
    public function photos_getWithoutGeoData($args = array())
    {
        $hqcmicnyyo = 'args';
        $this->request('flickr.photos.getWithoutGeoData', ${$hqcmicnyyo});
        return $this->parsed_response ? $this->parsed_response['photos'] : false;
    }
    public function photos_recentlyUpdated($min_date, $extras = NULL, $per_page = NULL, $page = NULL)
    {
        $tzmpkfbzr = 'extras';
        $fqumikzmi = 'page';
        ${'GLOBALS'}['wmyxwg'] = 'per_page';
        return $this->call('flickr.photos.recentlyUpdated', array('min_date' => ${${'GLOBALS'}['uhhuqhcxvmz']}, 'extras' => ${$tzmpkfbzr}, 'per_page' => ${${'GLOBALS'}['wmyxwg']}, 'page' => ${$fqumikzmi}));
    }
    public function photos_removeTag($tag_id)
    {
        ${'GLOBALS'}['uboofcduz'] = 'tag_id';
        $this->request('flickr.photos.removeTag', array('tag_id' => ${${'GLOBALS'}['uboofcduz']}), TRUE);
        return $this->parsed_response ? true : false;
    }
    public function photos_search($args = array())
    {
        $this->request('flickr.photos.search', ${${'GLOBALS'}['ckyndtgc']});
        return $this->parsed_response ? $this->parsed_response['photos'] : false;
    }
    public function photos_setContentType($photo_id, $content_type)
    {
        ${'GLOBALS'}['qnzoxosj'] = 'content_type';
        return $this->call('flickr.photos.setContentType', array('photo_id' => ${${'GLOBALS'}['urwunjsn']}, 'content_type' => ${${'GLOBALS'}['qnzoxosj']}));
    }
    public function photos_setDates($photo_id, $date_posted = NULL, $date_taken = NULL, $date_taken_granularity = NULL)
    {
        ${'GLOBALS'}['nesyoa'] = 'date_posted';
        $this->request('flickr.photos.setDates', array('photo_id' => ${${'GLOBALS'}['urwunjsn']}, 'date_posted' => ${${'GLOBALS'}['nesyoa']}, 'date_taken' => ${${'GLOBALS'}['fyeygrrkaier']}, 'date_taken_granularity' => ${${'GLOBALS'}['pxyxecancv']}), TRUE);
        return $this->parsed_response ? true : false;
    }
    public function photos_setMeta($photo_id, $title, $description)
    {
        ${'GLOBALS'}['grmacugsc'] = 'description';
        $izoszggghuz = 'title';
        $this->request('flickr.photos.setMeta', array('photo_id' => ${${'GLOBALS'}['urwunjsn']}, 'title' => ${$izoszggghuz}, 'description' => ${${'GLOBALS'}['grmacugsc']}), TRUE);
        return $this->parsed_response ? true : false;
    }
    public function photos_setPerms($photo_id, $is_public, $is_friend, $is_family, $perm_comment, $perm_addmeta)
    {
        ${'GLOBALS'}['dcfvloe'] = 'perm_addmeta';
        $this->request('flickr.photos.setPerms', array('photo_id' => ${${'GLOBALS'}['urwunjsn']}, 'is_public' => ${${'GLOBALS'}['miipujyspj']}, 'is_friend' => ${${'GLOBALS'}['jghofqo']}, 'is_family' => ${${'GLOBALS'}['qzhotvgm']}, 'perm_comment' => ${${'GLOBALS'}['meipdgtpht']}, 'perm_addmeta' => ${${'GLOBALS'}['dcfvloe']}), TRUE);
        return $this->parsed_response ? true : false;
    }
    public function photos_setSafetyLevel($photo_id, $safety_level = NULL, $hidden = NULL)
    {
        ${'GLOBALS'}['mfcjjila'] = 'safety_level';
        return $this->call('flickr.photos.setSafetyLevel', array('photo_id' => ${${'GLOBALS'}['urwunjsn']}, 'safety_level' => ${${'GLOBALS'}['mfcjjila']}, 'hidden' => ${${'GLOBALS'}['monsfuhphkwb']}));
    }
    public function photos_setTags($photo_id, $tags)
    {
        $mssnju = 'tags';
        ${'GLOBALS'}['jdfcjnuuvoh'] = 'photo_id';
        $this->request('flickr.photos.setTags', array('photo_id' => ${${'GLOBALS'}['jdfcjnuuvoh']}, 'tags' => ${$mssnju}), TRUE);
        return $this->parsed_response ? true : false;
    }
    public function photos_comments_addComment($photo_id, $comment_text)
    {
        $roxubqogdbt = 'comment_text';
        $this->request('flickr.photos.comments.addComment', array('photo_id' => ${${'GLOBALS'}['urwunjsn']}, 'comment_text' => ${$roxubqogdbt}), TRUE);
        return $this->parsed_response ? $this->parsed_response['comment'] : false;
    }
    public function photos_comments_deleteComment($comment_id)
    {
        $this->request('flickr.photos.comments.deleteComment', array('comment_id' => ${${'GLOBALS'}['elyoyuvcoppm']}), TRUE);
        return $this->parsed_response ? true : false;
    }
    public function photos_comments_editComment($comment_id, $comment_text)
    {
        $boninvcygfy = 'comment_id';
        $this->request('flickr.photos.comments.editComment', array('comment_id' => ${$boninvcygfy}, 'comment_text' => ${${'GLOBALS'}['slodxw']}), TRUE);
        return $this->parsed_response ? true : false;
    }
    public function photos_comments_getList($photo_id, $min_comment_date = NULL, $max_comment_date = NULL, $page = NULL, $per_page = NULL, $include_faves = NULL)
    {
        $rjcsuxwf = 'per_page';
        $ojfrsiupayb = 'max_comment_date';
        ${'GLOBALS'}['uzitpkhco'] = 'min_comment_date';
        $gexwyckvccq = 'include_faves';
        $mukpfajbs = 'photo_id';
        return $this->call('flickr.photos.comments.getList', array('photo_id' => ${$mukpfajbs}, 'min_comment_date' => ${${'GLOBALS'}['uzitpkhco']}, 'max_comment_date' => ${$ojfrsiupayb}, 'page' => ${${'GLOBALS'}['xapovj']}, 'per_page' => ${$rjcsuxwf}, 'include_faves' => ${$gexwyckvccq}));
    }
    public function photos_comments_getRecentForContacts($date_lastcomment = NULL, $contacts_filter = NULL, $extras = NULL, $per_page = NULL, $page = NULL)
    {
        ${'GLOBALS'}['cmqpnhjcvmh'] = 'extras';
        $dkdkouz = 'page';
        return $this->call('flickr.photos.comments.getRecentForContacts', array('date_lastcomment' => ${${'GLOBALS'}['fxjkbyegdw']}, 'contacts_filter' => ${${'GLOBALS'}['crgbmqapamr']}, 'extras' => ${${'GLOBALS'}['cmqpnhjcvmh']}, 'per_page' => ${${'GLOBALS'}['fcernn']}, 'page' => ${$dkdkouz}));
    }
    public function photos_geo_batchCorrectLocation($lat, $lon, $accuracy, $place_id = NULL, $woe_id = NULL)
    {
        ${'GLOBALS'}['suwjcmmbpvz'] = 'accuracy';
        $ybvirgxye = 'lon';
        return $this->call('flickr.photos.geo.batchCorrectLocation', array('lat' => ${${'GLOBALS'}['foerajlewfo']}, 'lon' => ${$ybvirgxye}, 'accuracy' => ${${'GLOBALS'}['suwjcmmbpvz']}, 'place_id' => ${${'GLOBALS'}['knjtsfo']}, 'woe_id' => ${${'GLOBALS'}['bcajipwne']}));
    }
    public function photos_geo_correctLocation($photo_id, $place_id = NULL, $woe_id = NULL)
    {
        $vjmejxfouqod = 'woe_id';
        ${'GLOBALS'}['mjttrmbrex'] = 'photo_id';
        return $this->call('flickr.photos.geo.correctLocation', array('photo_id' => ${${'GLOBALS'}['mjttrmbrex']}, 'place_id' => ${${'GLOBALS'}['knjtsfo']}, 'woe_id' => ${$vjmejxfouqod}));
    }
    public function photos_geo_getLocation($photo_id)
    {
        ${'GLOBALS'}['cxmbzpwxpm'] = 'photo_id';
        $this->request('flickr.photos.geo.getLocation', array('photo_id' => ${${'GLOBALS'}['cxmbzpwxpm']}));
        return $this->parsed_response ? $this->parsed_response['photo'] : false;
    }
    public function photos_geo_getPerms($photo_id)
    {
        $this->request('flickr.photos.geo.getPerms', array('photo_id' => ${${'GLOBALS'}['urwunjsn']}));
        return $this->parsed_response ? $this->parsed_response['perms'] : false;
    }
    public function photos_geo_photosForLocation($lat, $lon, $accuracy = NULL, $extras = NULL, $per_page = NULL, $page = NULL)
    {
        $jgcejofnk = 'lat';
        ${'GLOBALS'}['qtknwac'] = 'page';
        ${'GLOBALS'}['emjsqlllt'] = 'accuracy';
        return $this->call('flickr.photos.geo.photosForLocation', array('lat' => ${$jgcejofnk}, 'lon' => ${${'GLOBALS'}['vueqvjefi']}, 'accuracy' => ${${'GLOBALS'}['emjsqlllt']}, 'extras' => ${${'GLOBALS'}['nwlxjjrhmx']}, 'per_page' => ${${'GLOBALS'}['fcernn']}, 'page' => ${${'GLOBALS'}['qtknwac']}));
    }
    public function photos_geo_removeLocation($photo_id)
    {
        $sshfybvoc = 'photo_id';
        $this->request('flickr.photos.geo.removeLocation', array('photo_id' => ${$sshfybvoc}), TRUE);
        return $this->parsed_response ? true : false;
    }
    public function photos_geo_setContext($photo_id, $context)
    {
        ${'GLOBALS'}['evulborqbgt'] = 'photo_id';
        return $this->call('flickr.photos.geo.setContext', array('photo_id' => ${${'GLOBALS'}['evulborqbgt']}, 'context' => ${${'GLOBALS'}['wdyklotehm']}));
    }
    public function photos_geo_setLocation($photo_id, $lat, $lon, $accuracy = NULL, $context = NULL, $bookmark_id = NULL)
    {
        ${'GLOBALS'}['kdfcsgtq'] = 'bookmark_id';
        ${'GLOBALS'}['iljuggkna'] = 'accuracy';
        return $this->call('flickr.photos.geo.setLocation', array('photo_id' => ${${'GLOBALS'}['urwunjsn']}, 'lat' => ${${'GLOBALS'}['foerajlewfo']}, 'lon' => ${${'GLOBALS'}['vueqvjefi']}, 'accuracy' => ${${'GLOBALS'}['iljuggkna']}, 'context' => ${${'GLOBALS'}['wdyklotehm']}, 'bookmark_id' => ${${'GLOBALS'}['kdfcsgtq']}));
    }
    public function photos_geo_setPerms($is_public, $is_contact, $is_friend, $is_family, $photo_id)
    {
        $kycsuudckd = 'is_contact';
        $tmxvwflsv = 'photo_id';
        return $this->call('flickr.photos.geo.setPerms', array('is_public' => ${${'GLOBALS'}['miipujyspj']}, 'is_contact' => ${$kycsuudckd}, 'is_friend' => ${${'GLOBALS'}['jghofqo']}, 'is_family' => ${${'GLOBALS'}['qzhotvgm']}, 'photo_id' => ${$tmxvwflsv}));
    }
    public function photos_licenses_getInfo()
    {
        $this->request('flickr.photos.licenses.getInfo');
        return $this->parsed_response ? $this->parsed_response['licenses']['license'] : false;
    }
    public function photos_licenses_setLicense($photo_id, $license_id)
    {
        $this->request('flickr.photos.licenses.setLicense', array('photo_id' => ${${'GLOBALS'}['urwunjsn']}, 'license_id' => ${${'GLOBALS'}['uwrzowybgu']}), TRUE);
        return $this->parsed_response ? true : false;
    }
    public function photos_notes_add($photo_id, $note_x, $note_y, $note_w, $note_h, $note_text)
    {
        $bimpynlyqdo = 'note_text';
        ${'GLOBALS'}['xympmygntpux'] = 'photo_id';
        ${'GLOBALS'}['nthqcwkja'] = 'note_w';
        $this->request('flickr.photos.notes.add', array('photo_id' => ${${'GLOBALS'}['xympmygntpux']}, 'note_x' => ${${'GLOBALS'}['guqvodwf']}, 'note_y' => ${${'GLOBALS'}['nnqlijevzkl']}, 'note_w' => ${${'GLOBALS'}['nthqcwkja']}, 'note_h' => ${${'GLOBALS'}['sudltmgqxyn']}, 'note_text' => ${$bimpynlyqdo}), TRUE);
        return $this->parsed_response ? $this->parsed_response['note'] : false;
    }
    public function photos_notes_delete($note_id)
    {
        $this->request('flickr.photos.notes.delete', array('note_id' => ${${'GLOBALS'}['fwelmk']}), TRUE);
        return $this->parsed_response ? true : false;
    }
    public function photos_notes_edit($note_id, $note_x, $note_y, $note_w, $note_h, $note_text)
    {
        $bybbhjorirpe = 'note_h';
        $wppjksff = 'note_text';
        $this->request('flickr.photos.notes.edit', array('note_id' => ${${'GLOBALS'}['fwelmk']}, 'note_x' => ${${'GLOBALS'}['guqvodwf']}, 'note_y' => ${${'GLOBALS'}['nnqlijevzkl']}, 'note_w' => ${${'GLOBALS'}['zlnputjgtb']}, 'note_h' => ${$bybbhjorirpe}, 'note_text' => ${$wppjksff}), TRUE);
        return $this->parsed_response ? true : false;
    }
    public function photos_transform_rotate($photo_id, $degrees)
    {
        $gybjkomhef = 'photo_id';
        $this->request('flickr.photos.transform.rotate', array('photo_id' => ${$gybjkomhef}, 'degrees' => ${${'GLOBALS'}['oervof']}), TRUE);
        return $this->parsed_response ? true : false;
    }
    public function photos_people_add($photo_id, $user_id, $person_x = NULL, $person_y = NULL, $person_w = NULL, $person_h = NULL)
    {
        $urvcxjryhf = 'person_w';
        ${'GLOBALS'}['hwojtcft'] = 'person_y';
        $bsryimeacjq = 'person_x';
        return $this->call('flickr.photos.people.add', array('photo_id' => ${${'GLOBALS'}['urwunjsn']}, 'user_id' => ${${'GLOBALS'}['wpugylrxl']}, 'person_x' => ${$bsryimeacjq}, 'person_y' => ${${'GLOBALS'}['hwojtcft']}, 'person_w' => ${$urvcxjryhf}, 'person_h' => ${${'GLOBALS'}['bswubjy']}));
    }
    public function photos_people_delete($photo_id, $user_id, $email = NULL)
    {
        $frulumeni = 'email';
        return $this->call('flickr.photos.people.delete', array('photo_id' => ${${'GLOBALS'}['urwunjsn']}, 'user_id' => ${${'GLOBALS'}['wpugylrxl']}, 'email' => ${$frulumeni}));
    }
    public function photos_people_deleteCoords($photo_id, $user_id)
    {
        return $this->call('flickr.photos.people.deleteCoords', array('photo_id' => ${${'GLOBALS'}['urwunjsn']}, 'user_id' => ${${'GLOBALS'}['wpugylrxl']}));
    }
    public function photos_people_editCoords($photo_id, $user_id, $person_x, $person_y, $person_w, $person_h, $email = NULL)
    {
        ${'GLOBALS'}['jridchulc'] = 'person_h';
        ${'GLOBALS'}['zvqrnjdkx'] = 'person_w';
        return $this->call('flickr.photos.people.editCoords', array('photo_id' => ${${'GLOBALS'}['urwunjsn']}, 'user_id' => ${${'GLOBALS'}['wpugylrxl']}, 'person_x' => ${${'GLOBALS'}['kencvernn']}, 'person_y' => ${${'GLOBALS'}['yqzxijctd']}, 'person_w' => ${${'GLOBALS'}['zvqrnjdkx']}, 'person_h' => ${${'GLOBALS'}['jridchulc']}, 'email' => ${${'GLOBALS'}['zjmtgerupv']}));
    }
    public function photos_people_getList($photo_id)
    {
        return $this->call('flickr.photos.people.getList', array('photo_id' => ${${'GLOBALS'}['urwunjsn']}));
    }
    public function photos_upload_checkTickets($tickets)
    {
        ${'GLOBALS'}['adkewvvnn'] = 'tickets';
        if (is_array(${${'GLOBALS'}['ydbmnjbteipg']})) {
            ${'GLOBALS'}['hpwaehnfi'] = 'tickets';
            ${${'GLOBALS'}['hpwaehnfi']} = implode(',', ${${'GLOBALS'}['ydbmnjbteipg']});
        }
        $this->request('flickr.photos.upload.checkTickets', array('tickets' => ${${'GLOBALS'}['adkewvvnn']}), TRUE);
        return $this->parsed_response ? $this->parsed_response['uploader']['ticket'] : false;
    }
    public function photosets_addPhoto($photoset_id, $photo_id)
    {
        $this->request('flickr.photosets.addPhoto', array('photoset_id' => ${${'GLOBALS'}['xkhawv']}, 'photo_id' => ${${'GLOBALS'}['urwunjsn']}), TRUE);
        return $this->parsed_response ? true : false;
    }
    public function photosets_create($title, $description, $primary_photo_id)
    {
        ${'GLOBALS'}['sowgisjpi'] = 'primary_photo_id';
        ${'GLOBALS'}['kvgremplxhna'] = 'title';
        $this->request('flickr.photosets.create', array('title' => ${${'GLOBALS'}['kvgremplxhna']}, 'primary_photo_id' => ${${'GLOBALS'}['sowgisjpi']}, 'description' => ${${'GLOBALS'}['ebqvkbxla']}), TRUE);
        return $this->parsed_response ? $this->parsed_response['photoset'] : false;
    }
    public function photosets_delete($photoset_id)
    {
        $this->request('flickr.photosets.delete', array('photoset_id' => ${${'GLOBALS'}['xkhawv']}), TRUE);
        return $this->parsed_response ? true : false;
    }
    public function photosets_editMeta($photoset_id, $title, $description = NULL)
    {
        ${'GLOBALS'}['ngrwvx'] = 'title';
        ${'GLOBALS'}['etodlukbp'] = 'description';
        $this->request('flickr.photosets.editMeta', array('photoset_id' => ${${'GLOBALS'}['xkhawv']}, 'title' => ${${'GLOBALS'}['ngrwvx']}, 'description' => ${${'GLOBALS'}['etodlukbp']}), TRUE);
        return $this->parsed_response ? true : false;
    }
    public function photosets_editPhotos($photoset_id, $primary_photo_id, $photo_ids)
    {
        $fxvgbtknpji = 'photoset_id';
        $igbrdrw = 'primary_photo_id';
        $this->request('flickr.photosets.editPhotos', array('photoset_id' => ${$fxvgbtknpji}, 'primary_photo_id' => ${$igbrdrw}, 'photo_ids' => ${${'GLOBALS'}['wtezwvolkl']}), TRUE);
        return $this->parsed_response ? true : false;
    }
    public function photosets_getContext($photo_id, $photoset_id, $num_prev = NULL, $num_next = NULL)
    {
        $healkgy = 'photo_id';
        ${'GLOBALS'}['ubmlukcdk'] = 'photoset_id';
        $enkdoyqbydbe = 'num_prev';
        $ybrtmhy = 'num_next';
        return $this->call('flickr.photosets.getContext', array('photo_id' => ${$healkgy}, 'photoset_id' => ${${'GLOBALS'}['ubmlukcdk']}, 'num_prev' => ${$enkdoyqbydbe}, 'num_next' => ${$ybrtmhy}));
    }
    public function photosets_getInfo($photoset_id)
    {
        $bgavjvmndq = 'photoset_id';
        $this->request('flickr.photosets.getInfo', array('photoset_id' => ${$bgavjvmndq}));
        return $this->parsed_response ? $this->parsed_response['photoset'] : false;
    }
    public function photosets_getList($user_id = NULL)
    {
        $wleuthpz = 'user_id';
        $this->request('flickr.photosets.getList', array('user_id' => ${$wleuthpz}));
        return $this->parsed_response ? $this->parsed_response['photosets'] : false;
    }
    public function photosets_getPhotos($photoset_id, $extras = NULL, $privacy_filter = NULL, $per_page = NULL, $page = NULL, $media = NULL)
    {
        $urevbojw = 'extras';
        ${'GLOBALS'}['zbokeiti'] = 'privacy_filter';
        ${'GLOBALS'}['fnrwactejwnu'] = 'photoset_id';
        ${'GLOBALS'}['tvvfykczjg'] = 'media';
        ${'GLOBALS'}['xqglsdqsui'] = 'per_page';
        return $this->call('flickr.photosets.getPhotos', array('photoset_id' => ${${'GLOBALS'}['fnrwactejwnu']}, 'extras' => ${$urevbojw}, 'privacy_filter' => ${${'GLOBALS'}['zbokeiti']}, 'per_page' => ${${'GLOBALS'}['xqglsdqsui']}, 'page' => ${${'GLOBALS'}['xapovj']}, 'media' => ${${'GLOBALS'}['tvvfykczjg']}));
    }
    public function photosets_orderSets($photoset_ids)
    {
        ${'GLOBALS'}['gfemjndnsnx'] = 'photoset_ids';
        if (is_array(${${'GLOBALS'}['gfemjndnsnx']})) {
            $hkxqyjbhei = 'photoset_ids';
            ${'GLOBALS'}['lcnknpfhjg'] = 'photoset_ids';
            ${$hkxqyjbhei} = implode(',', ${${'GLOBALS'}['lcnknpfhjg']});
        }
        $this->request('flickr.photosets.orderSets', array('photoset_ids' => ${${'GLOBALS'}['opblftdcsbm']}), TRUE);
        return $this->parsed_response ? true : false;
    }
    public function photosets_removePhoto($photoset_id, $photo_id)
    {
        $hsxczyfcbwej = 'photo_id';
        $this->request('flickr.photosets.removePhoto', array('photoset_id' => ${${'GLOBALS'}['xkhawv']}, 'photo_id' => ${$hsxczyfcbwej}), TRUE);
        return $this->parsed_response ? true : false;
    }
    public function photosets_removePhotos($photoset_id, $photo_ids)
    {
        return $this->call('flickr.photosets.removePhotos', array('photoset_id' => ${${'GLOBALS'}['xkhawv']}, 'photo_ids' => ${${'GLOBALS'}['wtezwvolkl']}));
    }
    public function photosets_reorderPhotos($photoset_id, $photo_ids)
    {
        return $this->call('flickr.photosets.reorderPhotos', array('photoset_id' => ${${'GLOBALS'}['xkhawv']}, 'photo_ids' => ${${'GLOBALS'}['wtezwvolkl']}));
    }
    public function photosets_setPrimaryPhoto($photoset_id, $photo_id)
    {
        return $this->call('flickr.photosets.setPrimaryPhoto', array('photoset_id' => ${${'GLOBALS'}['xkhawv']}, 'photo_id' => ${${'GLOBALS'}['urwunjsn']}));
    }
    public function photosets_comments_addComment($photoset_id, $comment_text)
    {
        $this->request('flickr.photosets.comments.addComment', array('photoset_id' => ${${'GLOBALS'}['xkhawv']}, 'comment_text' => ${${'GLOBALS'}['slodxw']}), TRUE);
        return $this->parsed_response ? $this->parsed_response['comment'] : false;
    }
    public function photosets_comments_deleteComment($comment_id)
    {
        $lklczjb = 'comment_id';
        $this->request('flickr.photosets.comments.deleteComment', array('comment_id' => ${$lklczjb}), TRUE);
        return $this->parsed_response ? true : false;
    }
    public function photosets_comments_editComment($comment_id, $comment_text)
    {
        $this->request('flickr.photosets.comments.editComment', array('comment_id' => ${${'GLOBALS'}['elyoyuvcoppm']}, 'comment_text' => ${${'GLOBALS'}['slodxw']}), TRUE);
        return $this->parsed_response ? true : false;
    }
    public function photosets_comments_getList($photoset_id)
    {
        ${'GLOBALS'}['gscnhm'] = 'photoset_id';
        $this->request('flickr.photosets.comments.getList', array('photoset_id' => ${${'GLOBALS'}['gscnhm']}));
        return $this->parsed_response ? $this->parsed_response['comments'] : false;
    }
    public function places_find($query)
    {
        ${'GLOBALS'}['igmqdut'] = 'query';
        return $this->call('flickr.places.find', array('query' => ${${'GLOBALS'}['igmqdut']}));
    }
    public function places_findByLatLon($lat, $lon, $accuracy = NULL)
    {
        ${'GLOBALS'}['gfimxuqr'] = 'lon';
        return $this->call('flickr.places.findByLatLon', array('lat' => ${${'GLOBALS'}['foerajlewfo']}, 'lon' => ${${'GLOBALS'}['gfimxuqr']}, 'accuracy' => ${${'GLOBALS'}['nexwenwgb']}));
    }
    public function places_getChildrenWithPhotosPublic($place_id = NULL, $woe_id = NULL)
    {
        return $this->call('flickr.places.getChildrenWithPhotosPublic', array('place_id' => ${${'GLOBALS'}['knjtsfo']}, 'woe_id' => ${${'GLOBALS'}['bcajipwne']}));
    }
    public function places_getInfo($place_id = NULL, $woe_id = NULL)
    {
        ${'GLOBALS'}['wqunlwidmsbf'] = 'place_id';
        return $this->call('flickr.places.getInfo', array('place_id' => ${${'GLOBALS'}['wqunlwidmsbf']}, 'woe_id' => ${${'GLOBALS'}['bcajipwne']}));
    }
    public function places_getInfoByUrl($url)
    {
        return $this->call('flickr.places.getInfoByUrl', array('url' => ${${'GLOBALS'}['vnugmpqtyg']}));
    }
    public function places_getPlaceTypes()
    {
        return $this->call('flickr.places.getPlaceTypes', array());
    }
    public function places_getShapeHistory($place_id = NULL, $woe_id = NULL)
    {
        return $this->call('flickr.places.getShapeHistory', array('place_id' => ${${'GLOBALS'}['knjtsfo']}, 'woe_id' => ${${'GLOBALS'}['bcajipwne']}));
    }
    public function places_getTopPlacesList($place_type_id, $date = NULL, $woe_id = NULL, $place_id = NULL)
    {
        ${'GLOBALS'}['plbunhupe'] = 'place_id';
        return $this->call('flickr.places.getTopPlacesList', array('place_type_id' => ${${'GLOBALS'}['ugrvrob']}, 'date' => ${${'GLOBALS'}['ejfkcbwayj']}, 'woe_id' => ${${'GLOBALS'}['bcajipwne']}, 'place_id' => ${${'GLOBALS'}['plbunhupe']}));
    }
    public function places_placesForBoundingBox($bbox, $place_type = NULL, $place_type_id = NULL, $recursive = NULL)
    {
        ${'GLOBALS'}['jkscsfwsen'] = 'place_type_id';
        return $this->call('flickr.places.placesForBoundingBox', array('bbox' => ${${'GLOBALS'}['qzpiugwdbg']}, 'place_type' => ${${'GLOBALS'}['ivxqnuecb']}, 'place_type_id' => ${${'GLOBALS'}['jkscsfwsen']}, 'recursive' => ${${'GLOBALS'}['rcbzhqs']}));
    }
    public function places_placesForContacts($place_type = NULL, $place_type_id = NULL, $woe_id = NULL, $place_id = NULL, $threshold = NULL, $contacts = NULL, $min_upload_date = NULL, $max_upload_date = NULL, $min_taken_date = NULL, $max_taken_date = NULL)
    {
        $cdvilqpqn = 'place_id';
        ${'GLOBALS'}['qrmmniifuyt'] = 'threshold';
        ${'GLOBALS'}['nsbjfc'] = 'min_taken_date';
        $bechiepdy = 'max_upload_date';
        ${'GLOBALS'}['fluwudtq'] = 'contacts';
        return $this->call('flickr.places.placesForContacts', array('place_type' => ${${'GLOBALS'}['ivxqnuecb']}, 'place_type_id' => ${${'GLOBALS'}['ugrvrob']}, 'woe_id' => ${${'GLOBALS'}['bcajipwne']}, 'place_id' => ${$cdvilqpqn}, 'threshold' => ${${'GLOBALS'}['qrmmniifuyt']}, 'contacts' => ${${'GLOBALS'}['fluwudtq']}, 'min_upload_date' => ${${'GLOBALS'}['nmqcxchab']}, 'max_upload_date' => ${$bechiepdy}, 'min_taken_date' => ${${'GLOBALS'}['nsbjfc']}, 'max_taken_date' => ${${'GLOBALS'}['ewajjnqqpjb']}));
    }
    public function places_placesForTags($place_type_id, $woe_id = NULL, $place_id = NULL, $threshold = NULL, $tags = NULL, $tag_mode = NULL, $machine_tags = NULL, $machine_tag_mode = NULL, $min_upload_date = NULL, $max_upload_date = NULL, $min_taken_date = NULL, $max_taken_date = NULL)
    {
        ${'GLOBALS'}['lysbbqfbu'] = 'place_type_id';
        $yyeyiqg = 'min_taken_date';
        ${'GLOBALS'}['ycbsnumrtwn'] = 'tag_mode';
        $larynrkpdvnn = 'machine_tag_mode';
        $xwbleouo = 'machine_tags';
        ${'GLOBALS'}['lsbwtwxbrad'] = 'place_id';
        return $this->call('flickr.places.placesForTags', array('place_type_id' => ${${'GLOBALS'}['lysbbqfbu']}, 'woe_id' => ${${'GLOBALS'}['bcajipwne']}, 'place_id' => ${${'GLOBALS'}['lsbwtwxbrad']}, 'threshold' => ${${'GLOBALS'}['mlkxjn']}, 'tags' => ${${'GLOBALS'}['rmkmdgfu']}, 'tag_mode' => ${${'GLOBALS'}['ycbsnumrtwn']}, 'machine_tags' => ${$xwbleouo}, 'machine_tag_mode' => ${$larynrkpdvnn}, 'min_upload_date' => ${${'GLOBALS'}['nmqcxchab']}, 'max_upload_date' => ${${'GLOBALS'}['vxhyocqthma']}, 'min_taken_date' => ${$yyeyiqg}, 'max_taken_date' => ${${'GLOBALS'}['ewajjnqqpjb']}));
    }
    public function places_placesForUser($place_type_id = NULL, $place_type = NULL, $woe_id = NULL, $place_id = NULL, $threshold = NULL, $min_upload_date = NULL, $max_upload_date = NULL, $min_taken_date = NULL, $max_taken_date = NULL)
    {
        $mtqelsdqo = 'min_upload_date';
        ${'GLOBALS'}['pcurafaujm'] = 'woe_id';
        ${'GLOBALS'}['dttrdbxjm'] = 'place_type_id';
        $tttqkbxhrl = 'max_taken_date';
        $cthpnao = 'min_taken_date';
        $jgcrffn = 'max_upload_date';
        return $this->call('flickr.places.placesForUser', array('place_type_id' => ${${'GLOBALS'}['dttrdbxjm']}, 'place_type' => ${${'GLOBALS'}['ivxqnuecb']}, 'woe_id' => ${${'GLOBALS'}['pcurafaujm']}, 'place_id' => ${${'GLOBALS'}['knjtsfo']}, 'threshold' => ${${'GLOBALS'}['mlkxjn']}, 'min_upload_date' => ${$mtqelsdqo}, 'max_upload_date' => ${$jgcrffn}, 'min_taken_date' => ${$cthpnao}, 'max_taken_date' => ${$tttqkbxhrl}));
    }
    public function places_resolvePlaceId($place_id)
    {
        $chjadufm = 'rsp';
        ${${'GLOBALS'}['dscdjohpgr']} = $this->call('flickr.places.resolvePlaceId', array('place_id' => ${${'GLOBALS'}['knjtsfo']}));
        return ${$chjadufm} ? ${${'GLOBALS'}['dscdjohpgr']}['location'] : ${${'GLOBALS'}['dscdjohpgr']};
    }
    public function places_resolvePlaceURL($url)
    {
        ${'GLOBALS'}['gjbihhdyxxs'] = 'rsp';
        $ewfmwvnyqfih = 'url';
        ${'GLOBALS'}['finpism'] = 'rsp';
        ${${'GLOBALS'}['finpism']} = $this->call('flickr.places.resolvePlaceURL', array('url' => ${$ewfmwvnyqfih}));
        ${'GLOBALS'}['pnnxclimyxw'] = 'rsp';
        return ${${'GLOBALS'}['pnnxclimyxw']} ? ${${'GLOBALS'}['gjbihhdyxxs']}['location'] : ${${'GLOBALS'}['dscdjohpgr']};
    }
    public function places_tagsForPlace($woe_id = NULL, $place_id = NULL, $min_upload_date = NULL, $max_upload_date = NULL, $min_taken_date = NULL, $max_taken_date = NULL)
    {
        ${'GLOBALS'}['seqaeowfoue'] = 'woe_id';
        $pkbqgxmmsy = 'place_id';
        return $this->call('flickr.places.tagsForPlace', array('woe_id' => ${${'GLOBALS'}['seqaeowfoue']}, 'place_id' => ${$pkbqgxmmsy}, 'min_upload_date' => ${${'GLOBALS'}['nmqcxchab']}, 'max_upload_date' => ${${'GLOBALS'}['vxhyocqthma']}, 'min_taken_date' => ${${'GLOBALS'}['gtfzibjcodev']}, 'max_taken_date' => ${${'GLOBALS'}['ewajjnqqpjb']}));
    }
    public function prefs_getContentType()
    {
        ${'GLOBALS'}['btsgpndjh'] = 'rsp';
        ${${'GLOBALS'}['btsgpndjh']} = $this->call('flickr.prefs.getContentType', array());
        ${'GLOBALS'}['sgunhos'] = 'rsp';
        return ${${'GLOBALS'}['dscdjohpgr']} ? ${${'GLOBALS'}['dscdjohpgr']}['person'] : ${${'GLOBALS'}['sgunhos']};
    }
    public function prefs_getGeoPerms()
    {
        return $this->call('flickr.prefs.getGeoPerms', array());
    }
    public function prefs_getHidden()
    {
        ${'GLOBALS'}['ckqpoktkiej'] = 'rsp';
        ${'GLOBALS'}['bvjkftxozf'] = 'rsp';
        ${'GLOBALS'}['sniivgzokt'] = 'rsp';
        ${'GLOBALS'}['dizxtsh'] = 'rsp';
        ${${'GLOBALS'}['ckqpoktkiej']} = $this->call('flickr.prefs.getHidden', array());
        return ${${'GLOBALS'}['sniivgzokt']} ? ${${'GLOBALS'}['dizxtsh']}['person'] : ${${'GLOBALS'}['bvjkftxozf']};
    }
    public function prefs_getPrivacy()
    {
        ${${'GLOBALS'}['dscdjohpgr']} = $this->call('flickr.prefs.getPrivacy', array());
        return ${${'GLOBALS'}['dscdjohpgr']} ? ${${'GLOBALS'}['dscdjohpgr']}['person'] : ${${'GLOBALS'}['dscdjohpgr']};
    }
    public function prefs_getSafetyLevel()
    {
        ${'GLOBALS'}['thmpztnqrsm'] = 'rsp';
        ${'GLOBALS'}['vntphwqpkbe'] = 'rsp';
        ${'GLOBALS'}['cdyvxhzqm'] = 'rsp';
        ${${'GLOBALS'}['cdyvxhzqm']} = $this->call('flickr.prefs.getSafetyLevel', array());
        return ${${'GLOBALS'}['thmpztnqrsm']} ? ${${'GLOBALS'}['vntphwqpkbe']}['person'] : ${${'GLOBALS'}['dscdjohpgr']};
    }
    public function reflection_getMethodInfo($method_name)
    {
        $this->request('flickr.reflection.getMethodInfo', array('method_name' => ${${'GLOBALS'}['htipvwezttdm']}));
        return $this->parsed_response ? $this->parsed_response : false;
    }
    public function reflection_getMethods()
    {
        $this->request('flickr.reflection.getMethods');
        return $this->parsed_response ? $this->parsed_response['methods']['method'] : false;
    }
    public function stats_getCollectionDomains($date, $collection_id = NULL, $per_page = NULL, $page = NULL)
    {
        $uvjevlr = 'per_page';
        return $this->call('flickr.stats.getCollectionDomains', array('date' => ${${'GLOBALS'}['ejfkcbwayj']}, 'collection_id' => ${${'GLOBALS'}['bciltw']}, 'per_page' => ${$uvjevlr}, 'page' => ${${'GLOBALS'}['xapovj']}));
    }
    public function stats_getCollectionReferrers($date, $domain, $collection_id = NULL, $per_page = NULL, $page = NULL)
    {
        ${'GLOBALS'}['wurwslei'] = 'date';
        ${'GLOBALS'}['mlnxxplfv'] = 'domain';
        $ftmeiycsnt = 'page';
        ${'GLOBALS'}['ioksznl'] = 'per_page';
        return $this->call('flickr.stats.getCollectionReferrers', array('date' => ${${'GLOBALS'}['wurwslei']}, 'domain' => ${${'GLOBALS'}['mlnxxplfv']}, 'collection_id' => ${${'GLOBALS'}['bciltw']}, 'per_page' => ${${'GLOBALS'}['ioksznl']}, 'page' => ${$ftmeiycsnt}));
    }
    public function stats_getCollectionStats($date, $collection_id)
    {
        $yiryjmejd = 'collection_id';
        ${'GLOBALS'}['hgwqonpy'] = 'date';
        return $this->call('flickr.stats.getCollectionStats', array('date' => ${${'GLOBALS'}['hgwqonpy']}, 'collection_id' => ${$yiryjmejd}));
    }
    public function stats_getCSVFiles()
    {
        return $this->call('flickr.stats.getCSVFiles', array());
    }
    public function stats_getPhotoDomains($date, $photo_id = NULL, $per_page = NULL, $page = NULL)
    {
        $zxzefufvab = 'photo_id';
        ${'GLOBALS'}['qgkrnpynn'] = 'per_page';
        ${'GLOBALS'}['btpsnudp'] = 'date';
        return $this->call('flickr.stats.getPhotoDomains', array('date' => ${${'GLOBALS'}['btpsnudp']}, 'photo_id' => ${$zxzefufvab}, 'per_page' => ${${'GLOBALS'}['qgkrnpynn']}, 'page' => ${${'GLOBALS'}['xapovj']}));
    }
    public function stats_getPhotoReferrers($date, $domain, $photo_id = NULL, $per_page = NULL, $page = NULL)
    {
        ${'GLOBALS'}['wxqfygpymxm'] = 'per_page';
        ${'GLOBALS'}['enuheohcs'] = 'page';
        return $this->call('flickr.stats.getPhotoReferrers', array('date' => ${${'GLOBALS'}['ejfkcbwayj']}, 'domain' => ${${'GLOBALS'}['uumvxihni']}, 'photo_id' => ${${'GLOBALS'}['urwunjsn']}, 'per_page' => ${${'GLOBALS'}['wxqfygpymxm']}, 'page' => ${${'GLOBALS'}['enuheohcs']}));
    }
    public function stats_getPhotosetDomains($date, $photoset_id = NULL, $per_page = NULL, $page = NULL)
    {
        ${'GLOBALS'}['nwjdvpy'] = 'page';
        ${'GLOBALS'}['hovpwtovjr'] = 'per_page';
        return $this->call('flickr.stats.getPhotosetDomains', array('date' => ${${'GLOBALS'}['ejfkcbwayj']}, 'photoset_id' => ${${'GLOBALS'}['xkhawv']}, 'per_page' => ${${'GLOBALS'}['hovpwtovjr']}, 'page' => ${${'GLOBALS'}['nwjdvpy']}));
    }
    public function stats_getPhotosetReferrers($date, $domain, $photoset_id = NULL, $per_page = NULL, $page = NULL)
    {
        $wczrecf = 'per_page';
        return $this->call('flickr.stats.getPhotosetReferrers', array('date' => ${${'GLOBALS'}['ejfkcbwayj']}, 'domain' => ${${'GLOBALS'}['uumvxihni']}, 'photoset_id' => ${${'GLOBALS'}['xkhawv']}, 'per_page' => ${$wczrecf}, 'page' => ${${'GLOBALS'}['xapovj']}));
    }
    public function stats_getPhotosetStats($date, $photoset_id)
    {
        $spilfhiuow = 'photoset_id';
        $jeikxjmpxf = 'date';
        return $this->call('flickr.stats.getPhotosetStats', array('date' => ${$jeikxjmpxf}, 'photoset_id' => ${$spilfhiuow}));
    }
    public function stats_getPhotoStats($date, $photo_id)
    {
        return $this->call('flickr.stats.getPhotoStats', array('date' => ${${'GLOBALS'}['ejfkcbwayj']}, 'photo_id' => ${${'GLOBALS'}['urwunjsn']}));
    }
    public function stats_getPhotostreamDomains($date, $per_page = NULL, $page = NULL)
    {
        ${'GLOBALS'}['hjxjst'] = 'per_page';
        $dmpwowqrir = 'date';
        return $this->call('flickr.stats.getPhotostreamDomains', array('date' => ${$dmpwowqrir}, 'per_page' => ${${'GLOBALS'}['hjxjst']}, 'page' => ${${'GLOBALS'}['xapovj']}));
    }
    public function stats_getPhotostreamReferrers($date, $domain, $per_page = NULL, $page = NULL)
    {
        ${'GLOBALS'}['yknqesv'] = 'per_page';
        ${'GLOBALS'}['ynjnuhkh'] = 'page';
        return $this->call('flickr.stats.getPhotostreamReferrers', array('date' => ${${'GLOBALS'}['ejfkcbwayj']}, 'domain' => ${${'GLOBALS'}['uumvxihni']}, 'per_page' => ${${'GLOBALS'}['yknqesv']}, 'page' => ${${'GLOBALS'}['ynjnuhkh']}));
    }
    public function stats_getPhotostreamStats($date)
    {
        return $this->call('flickr.stats.getPhotostreamStats', array('date' => ${${'GLOBALS'}['ejfkcbwayj']}));
    }
    public function stats_getPopularPhotos($date = NULL, $sort = NULL, $per_page = NULL, $page = NULL)
    {
        $drswogqlxj = 'sort';
        $elzffn = 'per_page';
        $vekvceipyp = 'date';
        return $this->call('flickr.stats.getPopularPhotos', array('date' => ${$vekvceipyp}, 'sort' => ${$drswogqlxj}, 'per_page' => ${$elzffn}, 'page' => ${${'GLOBALS'}['xapovj']}));
    }
    public function stats_getTotalViews($date = NULL)
    {
        $rhxyiclf = 'date';
        return $this->call('flickr.stats.getTotalViews', array('date' => ${$rhxyiclf}));
    }
    public function tags_getClusterPhotos($tag, $cluster_id)
    {
        ${'GLOBALS'}['fzgqfzvmuj'] = 'cluster_id';
        return $this->call('flickr.tags.getClusterPhotos', array('tag' => ${${'GLOBALS'}['wnewosaggmy']}, 'cluster_id' => ${${'GLOBALS'}['fzgqfzvmuj']}));
    }
    public function tags_getClusters($tag)
    {
        return $this->call('flickr.tags.getClusters', array('tag' => ${${'GLOBALS'}['wnewosaggmy']}));
    }
    public function tags_getHotList($period = NULL, $count = NULL)
    {
        ${'GLOBALS'}['mkiyydbfyk'] = 'period';
        $this->request('flickr.tags.getHotList', array('period' => ${${'GLOBALS'}['mkiyydbfyk']}, 'count' => ${${'GLOBALS'}['hkawtqnihpru']}));
        return $this->parsed_response ? $this->parsed_response['hottags'] : false;
    }
    public function tags_getListPhoto($photo_id)
    {
        ${'GLOBALS'}['mlylftkr'] = 'photo_id';
        $this->request('flickr.tags.getListPhoto', array('photo_id' => ${${'GLOBALS'}['mlylftkr']}));
        return $this->parsed_response ? $this->parsed_response['photo']['tags']['tag'] : false;
    }
    public function tags_getListUser($user_id = NULL)
    {
        $this->request('flickr.tags.getListUser', array('user_id' => ${${'GLOBALS'}['wpugylrxl']}));
        return $this->parsed_response ? $this->parsed_response['who']['tags']['tag'] : false;
    }
    public function tags_getListUserPopular($user_id = NULL, $count = NULL)
    {
        ${'GLOBALS'}['bvaormst'] = 'user_id';
        $this->request('flickr.tags.getListUserPopular', array('user_id' => ${${'GLOBALS'}['bvaormst']}, 'count' => ${${'GLOBALS'}['hkawtqnihpru']}));
        return $this->parsed_response ? $this->parsed_response['who']['tags']['tag'] : false;
    }
    public function tags_getListUserRaw($tag = NULL)
    {
        $rciyax = 'tag';
        return $this->call('flickr.tags.getListUserRaw', array('tag' => ${$rciyax}));
    }
    public function tags_getRelated($tag)
    {
        $this->request('flickr.tags.getRelated', array('tag' => ${${'GLOBALS'}['wnewosaggmy']}));
        return $this->parsed_response ? $this->parsed_response['tags'] : false;
    }
    public function test_echo($args = array())
    {
        $this->request('flickr.test.echo', ${${'GLOBALS'}['ckyndtgc']});
        return $this->parsed_response ? $this->parsed_response : false;
    }
    public function test_login()
    {
        $this->request('flickr.test.login');
        return $this->parsed_response ? $this->parsed_response['user'] : false;
    }
    public function urls_getGroup($group_id)
    {
        ${'GLOBALS'}['hfvmxgbsacd'] = 'group_id';
        $this->request('flickr.urls.getGroup', array('group_id' => ${${'GLOBALS'}['hfvmxgbsacd']}));
        return $this->parsed_response ? $this->parsed_response['group']['url'] : false;
    }
    public function urls_getUserPhotos($user_id = NULL)
    {
        $this->request('flickr.urls.getUserPhotos', array('user_id' => ${${'GLOBALS'}['wpugylrxl']}));
        return $this->parsed_response ? $this->parsed_response['user']['url'] : false;
    }
    public function urls_getUserProfile($user_id = NULL)
    {
        $this->request('flickr.urls.getUserProfile', array('user_id' => ${${'GLOBALS'}['wpugylrxl']}));
        return $this->parsed_response ? $this->parsed_response['user']['url'] : false;
    }
    public function urls_lookupGallery($url)
    {
        return $this->call('flickr.urls.lookupGallery', array('url' => ${${'GLOBALS'}['vnugmpqtyg']}));
    }
    public function urls_lookupGroup($url)
    {
        ${'GLOBALS'}['bbsmpovl'] = 'url';
        $this->request('flickr.urls.lookupGroup', array('url' => ${${'GLOBALS'}['bbsmpovl']}));
        return $this->parsed_response ? $this->parsed_response['group'] : false;
    }
    public function urls_lookupUser($url)
    {
        $wvrkdrj = 'url';
        $this->request('flickr.urls.lookupUser', array('url' => ${$wvrkdrj}));
        return $this->parsed_response ? $this->parsed_response['user'] : false;
    }
}
class phpFlickr_pager
{
    public $phpFlickr, $per_page, $method, $args, $results, $global_phpFlickr;
    public $total = null, $page = 0, $pages = null, $photos, $_extra = null;
    public function phpFlickr_pager($phpFlickr, $method = null, $args = null, $per_page = 30)
    {
        ${'GLOBALS'}['yeehfrsonf'] = 'method';
        $this->per_page = ${${'GLOBALS'}['fcernn']};
        ${'GLOBALS'}['xxsbvxczuxp'] = 'phpFlickr';
        $this->method = ${${'GLOBALS'}['yeehfrsonf']};
        $pxovovsdfymr = 'args';
        $this->args = ${$pxovovsdfymr};
        $this->set_phpFlickr(${${'GLOBALS'}['xxsbvxczuxp']});
    }
    public function set_phpFlickr($phpFlickr)
    {
        ${'GLOBALS'}['ronxfwox'] = 'phpFlickr';
        if (is_a(${${'GLOBALS'}['ronxfwox']}, 'phpFlickr')) {
            ${'GLOBALS'}['eybxrdpred'] = 'phpFlickr';
            $this->phpFlickr = ${${'GLOBALS'}['eybxrdpred']};
            $this->args['per_page'] = (int) $this->per_page;
        }
    }
    public function __sleep()
    {
        return array('method', 'args', 'per_page', 'page', '_extra');
    }
    public function load($page)
    {
        ${${'GLOBALS'}['svbnlplirubp']} = array('flickr.photos.search' => 'photos', 'flickr.photosets.getPhotos' => 'photoset');
        if (!in_array($this->method, array_keys(${${'GLOBALS'}['svbnlplirubp']}))) {
            return false;
        }
        ${'GLOBALS'}['etbhphqy'] = 'page';
        $this->args['page'] = ${${'GLOBALS'}['etbhphqy']};
        $this->results = $this->phpFlickr->call($this->method, $this->args);
        if ($this->results) {
            $this->results = $this->results[${${'GLOBALS'}['svbnlplirubp']}[$this->method]];
            $this->photos = $this->results['photo'];
            $this->total = $this->results['total'];
            $this->pages = $this->results['pages'];
            return true;
        } else {
            return false;
        }
    }
    public function get($page = null)
    {
        ${'GLOBALS'}['xqmbqkubmj'] = 'page';
        if (is_null(${${'GLOBALS'}['xqmbqkubmj']})) {
            ${${'GLOBALS'}['xapovj']} = $this->page;
        } else {
            $this->page = ${${'GLOBALS'}['xapovj']};
        }
        if ($this->load(${${'GLOBALS'}['xapovj']})) {
            return $this->photos;
        }
        $this->total = 0;
        $this->pages = 0;
        return array();
    }
    public function next()
    {
        $this->page++;
        if ($this->load($this->page)) {
            return $this->photos;
        }
        $this->total = 0;
        $this->pages = 0;
        return array();
    }
}
${'GLOBALS'}['hwsobxc'] = 'delAttrClass';
function wp_autopost_flickr_request_token()
{
    if ($_GET['wp_autopost_flickr_request_token'] == 'true') {
        ${'GLOBALS'}['qciwpswhxq'] = 'Flickr';
        $oohcpailelu = 'Flickr';
        ${${'GLOBALS'}['jewkzeojer']} = admin_url() . 'admin.php?page=wp-autopost/wp-autopost-flickr.php';
        ${${'GLOBALS'}['qciwpswhxq']} = get_option('wp-autopost-flickr-options');
        ${'GLOBALS'}['cgnujhekk'] = 'Flickr';
        ${${'GLOBALS'}['gbrxrvp']} = new autopostFlickr(${${'GLOBALS'}['cgnujhekk']}['api_key'], ${$oohcpailelu}['api_secret']);
        $f->getRequestToken(${${'GLOBALS'}['jewkzeojer']}, 'delete');
        echo $f->getErrorCode() . '<br/>';
        print_r($f->getErrorMsg());
        die;
    }
}
add_action('admin_init', 'wp_autopost_flickr_request_token');
${${'GLOBALS'}['mohhnimyg']} = 'http://up.qiniu.com';
${${'GLOBALS'}['wmhrrwypg']} = 'http://rs.qbox.me';
${${'GLOBALS'}['ownccyg']} = 'http://rsf.qbox.me';
${$lvdxfhuqp} = '<Please apply your access key>';
${$jqhzczv} = '<Dont send your secret key to anyone>';
function Qiniu_Encode($str)
{
    ${'GLOBALS'}['ajhkqh'] = 'find';
    $qwuxiqh = 'find';
    ${$qwuxiqh} = array('+', '/');
    ${${'GLOBALS'}['qohsiilc']} = array('-', '_');
    return str_replace(${${'GLOBALS'}['ajhkqh']}, ${${'GLOBALS'}['qohsiilc']}, base64_encode(${${'GLOBALS'}['fgvupcichziw']}));
}
function Qiniu_RS_Put($self, $bucket, $key, $body, $putExtra)
{
    ${'GLOBALS'}['tmrtshye'] = 'upToken';
    ${'GLOBALS'}['wofmgqjzv'] = 'key';
    ${'GLOBALS'}['jupytgwv'] = 'putPolicy';
    $yjpipgit = 'putExtra';
    ${${'GLOBALS'}['jupytgwv']} = new Qiniu_RS_PutPolicy("{$bucket}:{$key}");
    ${${'GLOBALS'}['mlnocyehi']} = $putPolicy->Token($self->Mac);
    return Qiniu_Put(${${'GLOBALS'}['tmrtshye']}, ${${'GLOBALS'}['wofmgqjzv']}, ${${'GLOBALS'}['bvklbfdpe']}, ${$yjpipgit});
}
function Qiniu_RS_PutFile($self, $bucket, $key, $localFile, $putExtra)
{
    $srtxzepcbjv = 'localFile';
    ${'GLOBALS'}['aomjuvvj'] = 'putPolicy';
    ${${'GLOBALS'}['aomjuvvj']} = new Qiniu_RS_PutPolicy("{$bucket}:{$key}");
    ${${'GLOBALS'}['mlnocyehi']} = $putPolicy->Token($self->Mac);
    return Qiniu_PutFile(${${'GLOBALS'}['mlnocyehi']}, ${${'GLOBALS'}['gjejvzeg']}, ${$srtxzepcbjv}, ${${'GLOBALS'}['ksdesm']});
}
function Qiniu_RS_Rput($self, $bucket, $key, $body, $fsize, $putExtra)
{
    ${${'GLOBALS'}['lrckewoi']} = new Qiniu_RS_PutPolicy("{$bucket}:{$key}");
    ${${'GLOBALS'}['mlnocyehi']} = $putPolicy->Token($self->Mac);
    ${'GLOBALS'}['muwdiuqqlb'] = 'key';
    ${'GLOBALS'}['qxpgxwufppo'] = 'body';
    if (${${'GLOBALS'}['ksdesm']} == null) {
        ${'GLOBALS'}['ndwmlcpjjr'] = 'bucket';
        ${${'GLOBALS'}['ksdesm']} = new Qiniu_Rio_PutExtra(${${'GLOBALS'}['ndwmlcpjjr']});
    } else {
        ${'GLOBALS'}['objdndwhkdf'] = 'bucket';
        $putExtra->Bucket = ${${'GLOBALS'}['objdndwhkdf']};
    }
    $wpvgvejfed = 'fsize';
    ${'GLOBALS'}['geguehk'] = 'putExtra';
    ${'GLOBALS'}['fjwhefuwmju'] = 'upToken';
    return Qiniu_Rio_Put(${${'GLOBALS'}['fjwhefuwmju']}, ${${'GLOBALS'}['muwdiuqqlb']}, ${${'GLOBALS'}['qxpgxwufppo']}, ${$wpvgvejfed}, ${${'GLOBALS'}['geguehk']});
}
function Qiniu_RS_RputFile($self, $bucket, $key, $localFile, $putExtra)
{
    ${'GLOBALS'}['prnvrntcbjt'] = 'putPolicy';
    $yxfhzrvvb = 'putExtra';
    $ohwxtqpwmgc = 'upToken';
    ${${'GLOBALS'}['prnvrntcbjt']} = new Qiniu_RS_PutPolicy("{$bucket}:{$key}");
    ${'GLOBALS'}['wusqeh'] = 'putExtra';
    $ljjyfftqxi = 'localFile';
    ${$ohwxtqpwmgc} = $putPolicy->Token($self->Mac);
    ${'GLOBALS'}['eijctdpkogv'] = 'key';
    if (${$yxfhzrvvb} == null) {
        ${'GLOBALS'}['phcicv'] = 'bucket';
        ${${'GLOBALS'}['ksdesm']} = new Qiniu_Rio_PutExtra(${${'GLOBALS'}['phcicv']});
    } else {
        $nayevdpxai = 'bucket';
        $putExtra->Bucket = ${$nayevdpxai};
    }
    return Qiniu_Rio_PutFile(${${'GLOBALS'}['mlnocyehi']}, ${${'GLOBALS'}['eijctdpkogv']}, ${$ljjyfftqxi}, ${${'GLOBALS'}['wusqeh']});
}
class Qiniu_RS_GetPolicy
{
    public $Expires;
    public function MakeRequest($baseUrl, $mac)
    {
        ${'GLOBALS'}['sskouce'] = 'baseUrl';
        ${'GLOBALS'}['dooydsnlbz'] = 'deadline';
        ${${'GLOBALS'}['lgnhyfu']} = $this->Expires;
        ${'GLOBALS'}['tmbjbdrafz'] = 'pos';
        if (${${'GLOBALS'}['dooydsnlbz']} == 0) {
            $vlkgysskwz = 'deadline';
            ${$vlkgysskwz} = 3600;
        }
        $qoreci = 'baseUrl';
        ${${'GLOBALS'}['lgnhyfu']} += time();
        ${${'GLOBALS'}['ymmruswvc']} = strpos(${$qoreci}, '?');
        if (${${'GLOBALS'}['tmbjbdrafz']} !== false) {
            ${'GLOBALS'}['hrgakeq'] = 'baseUrl';
            ${${'GLOBALS'}['hrgakeq']} .= '&e=';
        } else {
            ${${'GLOBALS'}['vzrexdhtj']} .= '?e=';
        }
        ${${'GLOBALS'}['sskouce']} .= ${${'GLOBALS'}['lgnhyfu']};
        ${${'GLOBALS'}['aqxaaoiwo']} = Qiniu_Sign(${${'GLOBALS'}['tdminl']}, ${${'GLOBALS'}['vzrexdhtj']});
        return "{$baseUrl}&token={$token}";
    }
}
function Qiniu_RS_MakeBaseUrl($domain, $key)
{
    return "http://{$domain}/{$key}";
}
class Qiniu_RS_PutPolicy
{
    public $Scope;
    public $CallbackUrl;
    public $CallbackBody;
    public $ReturnUrl;
    public $ReturnBody;
    public $AsyncOps;
    public $EndUser;
    public $Expires;
    public function __construct($scope)
    {
        $nvrmdkzbxh = 'scope';
        $this->Scope = ${$nvrmdkzbxh};
    }
    public function Token($mac)
    {
        ${'GLOBALS'}['eivbwcurksc'] = 'deadline';
        $bzpadqqb = 'b';
        $rapkiic = 'deadline';
        ${${'GLOBALS'}['eivbwcurksc']} = $this->Expires;
        ${'GLOBALS'}['ghmxypkeqk'] = 'deadline';
        $blnmly = 'policy';
        if (${${'GLOBALS'}['lgnhyfu']} == 0) {
            ${'GLOBALS'}['opijlpelqkof'] = 'deadline';
            ${${'GLOBALS'}['opijlpelqkof']} = 3600;
        }
        ${${'GLOBALS'}['ghmxypkeqk']} += time();
        ${$blnmly} = array('scope' => $this->Scope, 'deadline' => ${$rapkiic});
        if (!empty($this->CallbackUrl)) {
            ${${'GLOBALS'}['nyoajbgs']}['callbackUrl'] = $this->CallbackUrl;
        }
        if (!empty($this->CallbackBody)) {
            $kgqectqbpw = 'policy';
            ${$kgqectqbpw}['callbackBody'] = $this->CallbackBody;
        }
        if (!empty($this->ReturnUrl)) {
            ${${'GLOBALS'}['nyoajbgs']}['returnUrl'] = $this->ReturnUrl;
        }
        if (!empty($this->ReturnBody)) {
            ${'GLOBALS'}['uwebreb'] = 'policy';
            ${${'GLOBALS'}['uwebreb']}['returnBody'] = $this->ReturnBody;
        }
        if (!empty($this->AsyncOps)) {
            ${${'GLOBALS'}['nyoajbgs']}['asyncOps'] = $this->AsyncOps;
        }
        if (!empty($this->EndUser)) {
            ${'GLOBALS'}['otxjsprs'] = 'policy';
            ${${'GLOBALS'}['otxjsprs']}['endUser'] = $this->EndUser;
        }
        ${${'GLOBALS'}['wklbtjxgiwm']} = json_encode(${${'GLOBALS'}['nyoajbgs']});
        return Qiniu_SignWithData(${${'GLOBALS'}['tdminl']}, ${$bzpadqqb});
    }
}
class Qiniu_RS_EntryPath
{
    public $bucket;
    public $key;
    public function __construct($bucket, $key)
    {
        $xokcejwegmn = 'key';
        $this->bucket = ${${'GLOBALS'}['sgjtht']};
        $this->key = ${$xokcejwegmn};
    }
}
class Qiniu_RS_EntryPathPair
{
    public $src;
    public $dest;
    public function __construct($src, $dest)
    {
        ${'GLOBALS'}['oimsmmi'] = 'dest';
        ${'GLOBALS'}['haskgyg'] = 'src';
        $this->src = ${${'GLOBALS'}['haskgyg']};
        $this->dest = ${${'GLOBALS'}['oimsmmi']};
    }
}
function Qiniu_RS_URIStat($bucket, $key)
{
    return '/stat/' . Qiniu_Encode("{$bucket}:{$key}");
}
function Qiniu_RS_URIDelete($bucket, $key)
{
    return '/delete/' . Qiniu_Encode("{$bucket}:{$key}");
}
function Qiniu_RS_URICopy($bucketSrc, $keySrc, $bucketDest, $keyDest)
{
    return (('/copy/' . Qiniu_Encode("{$bucketSrc}:{$keySrc}")) . '/') . Qiniu_Encode("{$bucketDest}:{$keyDest}");
}
function Qiniu_RS_URIMove($bucketSrc, $keySrc, $bucketDest, $keyDest)
{
    return (('/move/' . Qiniu_Encode("{$bucketSrc}:{$keySrc}")) . '/') . Qiniu_Encode("{$bucketDest}:{$keyDest}");
}
function Qiniu_RS_Stat($self, $bucket, $key)
{
    ${'GLOBALS'}['enfxiflbrl'] = 'bucket';
    $rnrljyvhrsb = 'uri';
    global $QINIU_RS_HOST;
    ${${'GLOBALS'}['uoyyftu']} = Qiniu_RS_URIStat(${${'GLOBALS'}['enfxiflbrl']}, ${${'GLOBALS'}['gjejvzeg']});
    return Qiniu_Client_Call(${${'GLOBALS'}['qqepwu']}, ${${'GLOBALS'}['pjncxq']} . ${$rnrljyvhrsb});
}
function Qiniu_RS_Delete($self, $bucket, $key)
{
    ${'GLOBALS'}['spcrxrz'] = 'QINIU_RS_HOST';
    ${'GLOBALS'}['rbgdqlooi'] = 'bucket';
    $rmwirmmd = 'key';
    $npvwyljlwdq = 'uri';
    global $QINIU_RS_HOST;
    ${$npvwyljlwdq} = Qiniu_RS_URIDelete(${${'GLOBALS'}['rbgdqlooi']}, ${$rmwirmmd});
    return Qiniu_Client_CallNoRet(${${'GLOBALS'}['qqepwu']}, ${${'GLOBALS'}['spcrxrz']} . ${${'GLOBALS'}['uoyyftu']});
}
function Qiniu_RS_Move($self, $bucketSrc, $keySrc, $bucketDest, $keyDest)
{
    $etrankxgm = 'uri';
    ${'GLOBALS'}['yyittisb'] = 'keySrc';
    global $QINIU_RS_HOST;
    ${'GLOBALS'}['drvdqaprew'] = 'QINIU_RS_HOST';
    ${${'GLOBALS'}['uoyyftu']} = Qiniu_RS_URIMove(${${'GLOBALS'}['tuwlbcnimju']}, ${${'GLOBALS'}['yyittisb']}, ${${'GLOBALS'}['lhytzutnyup']}, ${${'GLOBALS'}['gewpghokj']});
    return Qiniu_Client_CallNoRet(${${'GLOBALS'}['qqepwu']}, ${${'GLOBALS'}['drvdqaprew']} . ${$etrankxgm});
}
function Qiniu_RS_Copy($self, $bucketSrc, $keySrc, $bucketDest, $keyDest)
{
    ${'GLOBALS'}['nxfavex'] = 'self';
    ${'GLOBALS'}['jiqidnhin'] = 'uri';
    $uwjiceuscf = 'bucketSrc';
    ${'GLOBALS'}['qtzvqxshbwd'] = 'keySrc';
    ${'GLOBALS'}['prlwrf'] = 'keyDest';
    global $QINIU_RS_HOST;
    ${${'GLOBALS'}['uoyyftu']} = Qiniu_RS_URICopy(${$uwjiceuscf}, ${${'GLOBALS'}['qtzvqxshbwd']}, ${${'GLOBALS'}['lhytzutnyup']}, ${${'GLOBALS'}['prlwrf']});
    return Qiniu_Client_CallNoRet(${${'GLOBALS'}['nxfavex']}, ${${'GLOBALS'}['pjncxq']} . ${${'GLOBALS'}['jiqidnhin']});
}
function Qiniu_RS_Batch($self, $ops)
{
    $pnbkssck = 'url';
    global $QINIU_RS_HOST;
    ${$pnbkssck} = ${${'GLOBALS'}['pjncxq']} . '/batch';
    ${${'GLOBALS'}['cghahbqpo']} = 'op=' . implode('&op=', ${${'GLOBALS'}['slcwtqbd']});
    $qjeqivr = 'self';
    return Qiniu_Client_CallWithForm(${$qjeqivr}, ${${'GLOBALS'}['vnugmpqtyg']}, ${${'GLOBALS'}['cghahbqpo']});
}
function Qiniu_RS_BatchStat($self, $entryPaths)
{
    $whoefsvyohc = 'params';
    $uhctlrqtb = 'self';
    $obrkbdr = 'params';
    $pgcqkpvwmkn = 'entryPaths';
    ${$whoefsvyohc} = array();
    foreach (${$pgcqkpvwmkn} as ${${'GLOBALS'}['hlkeamnnkwf']}) {
        ${${'GLOBALS'}['cghahbqpo']}[] = Qiniu_RS_URIStat($entryPath->bucket, $entryPath->key);
    }
    return Qiniu_RS_Batch(${$uhctlrqtb}, ${$obrkbdr});
}
function Qiniu_RS_BatchDelete($self, $entryPaths)
{
    ${'GLOBALS'}['evrqtez'] = 'entryPath';
    ${'GLOBALS'}['nmwttkos'] = 'self';
    ${${'GLOBALS'}['cghahbqpo']} = array();
    $hcnoqjvrnf = 'params';
    foreach (${${'GLOBALS'}['jouyjjdh']} as ${${'GLOBALS'}['evrqtez']}) {
        ${${'GLOBALS'}['cghahbqpo']}[] = Qiniu_RS_URIDelete($entryPath->bucket, $entryPath->key);
    }
    return Qiniu_RS_Batch(${${'GLOBALS'}['nmwttkos']}, ${$hcnoqjvrnf});
}
function Qiniu_RS_BatchMove($self, $entryPairs)
{
    ${'GLOBALS'}['hsgxhb'] = 'params';
    ${'GLOBALS'}['cdrkyid'] = 'params';
    $jjuruwltq = 'entryPairs';
    ${'GLOBALS'}['vnnsdbmm'] = 'entryPair';
    ${${'GLOBALS'}['hsgxhb']} = array();
    foreach (${$jjuruwltq} as ${${'GLOBALS'}['vnnsdbmm']}) {
        ${${'GLOBALS'}['eedxpjpny']} = $entryPair->src;
        ${'GLOBALS'}['xdhrkbgyfl'] = 'params';
        ${${'GLOBALS'}['irbnhxzlblx']} = $entryPair->dest;
        ${${'GLOBALS'}['xdhrkbgyfl']}[] = Qiniu_RS_URIMove($src->bucket, $src->key, $dest->bucket, $dest->key);
    }
    return Qiniu_RS_Batch(${${'GLOBALS'}['qqepwu']}, ${${'GLOBALS'}['cdrkyid']});
}
function Qiniu_RS_BatchCopy($self, $entryPairs)
{
    ${'GLOBALS'}['dklbcmqlxr'] = 'params';
    ${'GLOBALS'}['ggqntia'] = 'entryPair';
    ${'GLOBALS'}['xzecys'] = 'self';
    ${${'GLOBALS'}['dklbcmqlxr']} = array();
    foreach (${${'GLOBALS'}['ljrwprmp']} as ${${'GLOBALS'}['ggqntia']}) {
        ${'GLOBALS'}['psztszta'] = 'src';
        $uczfxer = 'dest';
        ${${'GLOBALS'}['psztszta']} = $entryPair->src;
        ${$uczfxer} = $entryPair->dest;
        ${${'GLOBALS'}['cghahbqpo']}[] = Qiniu_RS_URICopy($src->bucket, $src->key, $dest->bucket, $dest->key);
    }
    return Qiniu_RS_Batch(${${'GLOBALS'}['xzecys']}, ${${'GLOBALS'}['cghahbqpo']});
}
class Qiniu_PutExtra
{
    public $Params = null;
    public $MimeType = null;
    public $Crc32 = 0;
    public $CheckCrc = 0;
}
function Qiniu_Put($upToken, $key, $body, $putExtra)
{
    ${'GLOBALS'}['rfslahbwtlx'] = 'files';
    ${'GLOBALS'}['kmcdghyjq'] = 'client';
    $hhqplcpmtsf = 'files';
    $wkqmewyuc = 'client';
    global $QINIU_UP_HOST;
    ${'GLOBALS'}['qdacjwkjc'] = 'fname';
    ${'GLOBALS'}['bpyusyhgfj'] = 'key';
    if (${${'GLOBALS'}['ksdesm']} === null) {
        $srvogsx = 'putExtra';
        ${$srvogsx} = new Qiniu_PutExtra();
    }
    ${${'GLOBALS'}['jfptvrsznsu']} = array('token' => ${${'GLOBALS'}['mlnocyehi']});
    if (${${'GLOBALS'}['bpyusyhgfj']} === null) {
        ${${'GLOBALS'}['frsktnakrzb']} = '?';
    } else {
        $pwpdlbf = 'key';
        ${${'GLOBALS'}['frsktnakrzb']} = ${$pwpdlbf};
        ${${'GLOBALS'}['jfptvrsznsu']}['key'] = ${${'GLOBALS'}['gjejvzeg']};
    }
    if ($putExtra->CheckCrc) {
        ${${'GLOBALS'}['jfptvrsznsu']}['crc32'] = $putExtra->Crc32;
    }
    ${${'GLOBALS'}['rfslahbwtlx']} = array(array('file', ${${'GLOBALS'}['qdacjwkjc']}, ${${'GLOBALS'}['bvklbfdpe']}));
    ${$wkqmewyuc} = new Qiniu_HttpClient();
    return Qiniu_Client_CallWithMultipartForm(${${'GLOBALS'}['kmcdghyjq']}, ${${'GLOBALS'}['qqodgfvpulog']}, ${${'GLOBALS'}['jfptvrsznsu']}, ${$hhqplcpmtsf});
}
function Qiniu_PutFile($upToken, $key, $localFile, $putExtra)
{
    global $QINIU_UP_HOST;
    if (${${'GLOBALS'}['ksdesm']} === null) {
        $xbefxahk = 'putExtra';
        ${$xbefxahk} = new Qiniu_PutExtra();
    }
    $pdbviib = 'upToken';
    ${${'GLOBALS'}['jfptvrsznsu']} = array('token' => ${$pdbviib}, 'file' => '@' . ${${'GLOBALS'}['xqdcugsdgv']});
    ${'GLOBALS'}['vjrlhi'] = 'client';
    if (${${'GLOBALS'}['gjejvzeg']} === null) {
        ${${'GLOBALS'}['frsktnakrzb']} = '?';
    } else {
        $pwhdrkeegr = 'fname';
        $nwhbgbhx = 'fields';
        ${$pwhdrkeegr} = ${${'GLOBALS'}['gjejvzeg']};
        ${$nwhbgbhx}['key'] = ${${'GLOBALS'}['gjejvzeg']};
    }
    if ($putExtra->CheckCrc) {
        if ($putExtra->CheckCrc === 1) {
            ${'GLOBALS'}['dnqsefed'] = 'hash';
            $phuwjrnov = 'array';
            ${${'GLOBALS'}['stwvgoax']} = hash_file('crc32b', ${${'GLOBALS'}['xqdcugsdgv']});
            $ysreydozs = 'array';
            ${$phuwjrnov} = unpack('N', pack('H*', ${${'GLOBALS'}['dnqsefed']}));
            $putExtra->Crc32 = ${$ysreydozs}[1];
        }
        $ensjhrurrqwn = 'fields';
        ${$ensjhrurrqwn}['crc32'] = sprintf('%u', $putExtra->Crc32);
    }
    ${'GLOBALS'}['lkvciuu'] = 'fields';
    $jdyzsld = 'QINIU_UP_HOST';
    ${${'GLOBALS'}['ocrlmakdvudp']} = new Qiniu_HttpClient();
    return Qiniu_Client_CallWithForm(${${'GLOBALS'}['vjrlhi']}, ${$jdyzsld}, ${${'GLOBALS'}['lkvciuu']}, 'multipart/form-data');
}
class Qiniu_Rio_PutExtra
{
    public $Bucket = null;
    public $Params = null;
    public $MimeType = null;
    public $ChunkSize = 0;
    public $TryTimes = 0;
    public $Progresses = null;
    public $Notify = null;
    public $NotifyErr = null;
    public function __construct($bucket = null)
    {
        $iwksibfvqe = 'bucket';
        $this->Bucket = ${$iwksibfvqe};
    }
}
define('QINIU_RIO_BLOCK_BITS', 22);
define('QINIU_RIO_BLOCK_SIZE', 1 << QINIU_RIO_BLOCK_BITS);
function Qiniu_Rio_BlockCount($fsize)
{
    ${'GLOBALS'}['vhccoezvql'] = 'fsize';
    return ${${'GLOBALS'}['vhccoezvql']} + (QINIU_RIO_BLOCK_SIZE - 1) >> QINIU_RIO_BLOCK_BITS;
}
${'GLOBALS'}['kigoezbahxa'] = 'delComment';
function Qiniu_Rio_Mkblock($self, $host, $reader, $size)
{
    $ivrrqtp = 'body';
    $usrxmgtepo = 'size';
    ${'GLOBALS'}['aecpohpeu'] = 'reader';
    ${'GLOBALS'}['diyvgjfe'] = 'self';
    ${'GLOBALS'}['fytxffrda'] = 'size';
    if (is_resource(${${'GLOBALS'}['aecpohpeu']})) {
        $iyeghymnr = 'body';
        $vgqhahc = 'body';
        ${'GLOBALS'}['mwjlrqwpdk'] = 'size';
        ${$vgqhahc} = fread(${${'GLOBALS'}['dqyhjpatvh']}, ${${'GLOBALS'}['mwjlrqwpdk']});
        if (${$iyeghymnr} === false) {
            $ecymblqxs = 'err';
            ${${'GLOBALS'}['wsietbni']} = Qiniu_NewError(0, 'fread failed');
            return array(null, ${$ecymblqxs});
        }
    } else {
        $fzofkrcvyrh = 'size';
        ${'GLOBALS'}['yorzvklexlrl'] = 'err';
        list(${${'GLOBALS'}['bvklbfdpe']}, ${${'GLOBALS'}['yorzvklexlrl']}) = $reader->Read(${$fzofkrcvyrh});
        if (${${'GLOBALS'}['wsietbni']} !== null) {
            $ovvpermy = 'err';
            return array(null, ${$ovvpermy});
        }
    }
    if (strlen(${$ivrrqtp}) != ${$usrxmgtepo}) {
        ${'GLOBALS'}['cpsreofhvc'] = 'err';
        ${${'GLOBALS'}['wsietbni']} = Qiniu_NewError(0, 'fread failed: unexpected eof');
        return array(null, ${${'GLOBALS'}['cpsreofhvc']});
    }
    ${${'GLOBALS'}['vnugmpqtyg']} = ($host . '/mkblk/') . ${${'GLOBALS'}['fytxffrda']};
    return Qiniu_Client_CallWithForm(${${'GLOBALS'}['diyvgjfe']}, ${${'GLOBALS'}['vnugmpqtyg']}, ${${'GLOBALS'}['bvklbfdpe']}, 'application/octet-stream');
}
function Qiniu_Rio_Mkfile($self, $host, $key, $fsize, $extra)
{
    $zvuvdfee = 'entry';
    $wmrgbcti = 'url';
    $msviabppl = 'ctxs';
    ${'GLOBALS'}['ohhyoqt'] = 'fsize';
    ${'GLOBALS'}['wutfldevpubc'] = 'entry';
    ${$zvuvdfee} = ($extra->Bucket . ':') . ${${'GLOBALS'}['gjejvzeg']};
    ${${'GLOBALS'}['vnugmpqtyg']} = ((($host . '/rs-mkfile/') . Qiniu_Encode(${${'GLOBALS'}['wutfldevpubc']})) . '/fsize/') . ${${'GLOBALS'}['ohhyoqt']};
    if (!empty($extra->MimeType)) {
        ${${'GLOBALS'}['vnugmpqtyg']} .= '/mimeType/' . Qiniu_Encode($extra->MimeType);
    }
    ${$msviabppl} = array();
    foreach ($extra->Progresses as ${${'GLOBALS'}['bdpctzue']}) {
        ${${'GLOBALS'}['kljyfje']}[] = ${${'GLOBALS'}['bdpctzue']}['ctx'];
    }
    ${${'GLOBALS'}['bvklbfdpe']} = implode(',', ${${'GLOBALS'}['kljyfje']});
    $qewkotj = 'self';
    return Qiniu_Client_CallWithForm(${$qewkotj}, ${$wmrgbcti}, ${${'GLOBALS'}['bvklbfdpe']}, 'text/plain');
}
class Qiniu_Rio_UploadClient
{
    public $uptoken;
    public function __construct($uptoken)
    {
        ${'GLOBALS'}['pmssnlbriwi'] = 'uptoken';
        $this->uptoken = ${${'GLOBALS'}['pmssnlbriwi']};
    }
    public function RoundTrip($req)
    {
        ${'GLOBALS'}['mdlfymjb'] = 'token';
        ${'GLOBALS'}['kxkvlmjp'] = 'req';
        ${${'GLOBALS'}['mdlfymjb']} = $this->uptoken;
        $req->Header['Authorization'] = "UpToken {$token}";
        return Qiniu_Client_do(${${'GLOBALS'}['kxkvlmjp']});
    }
}
function Qiniu_Rio_Put($upToken, $key, $body, $fsize, $putExtra)
{
    ${'GLOBALS'}['rqoxkebjf'] = 'uploaded';
    $twqgfym = 'uploaded';
    ${'GLOBALS'}['vdcyjtib'] = 'progresses';
    $pgkzdikircu = 'self';
    global $QINIU_UP_HOST;
    ${'GLOBALS'}['uxlhfxpz'] = 'progresses';
    ${$pgkzdikircu} = new Qiniu_Rio_UploadClient(${${'GLOBALS'}['mlnocyehi']});
    $tketmb = 'self';
    ${${'GLOBALS'}['vdcyjtib']} = array();
    $host = ${${'GLOBALS'}['qqodgfvpulog']};
    ${$twqgfym} = 0;
    while (${${'GLOBALS'}['rqoxkebjf']} < ${${'GLOBALS'}['xtmjcbkgfeb']}) {
        ${'GLOBALS'}['hegxbgftm'] = 'blkputRet';
        ${'GLOBALS'}['zjvohmijf'] = 'blkputRet';
        $lhpwyrq = 'body';
        ${'GLOBALS'}['fyubwaeps'] = 'uploaded';
        if (${${'GLOBALS'}['xtmjcbkgfeb']} < ${${'GLOBALS'}['fyubwaeps']} + QINIU_RIO_BLOCK_SIZE) {
            $lrtdqpoqmx = 'fsize';
            ${'GLOBALS'}['xltqmm'] = 'uploaded';
            ${${'GLOBALS'}['ziqrex']} = ${$lrtdqpoqmx} - ${${'GLOBALS'}['xltqmm']};
        } else {
            $rqpelnwcq = 'bsize';
            ${$rqpelnwcq} = QINIU_RIO_BLOCK_SIZE;
        }
        list(${${'GLOBALS'}['zjvohmijf']}, ${${'GLOBALS'}['wsietbni']}) = Qiniu_Rio_Mkblock(${${'GLOBALS'}['qqepwu']}, $host, ${$lhpwyrq}, ${${'GLOBALS'}['ziqrex']});
        ${'GLOBALS'}['qnybmtl'] = 'progresses';
        $host = ${${'GLOBALS'}['ixsbheks']}['host'];
        ${${'GLOBALS'}['furluamn']} += ${${'GLOBALS'}['ziqrex']};
        ${${'GLOBALS'}['qnybmtl']}[] = ${${'GLOBALS'}['hegxbgftm']};
    }
    ${'GLOBALS'}['impztbfgejn'] = 'putExtra';
    $putExtra->Progresses = ${${'GLOBALS'}['uxlhfxpz']};
    return Qiniu_Rio_Mkfile(${$tketmb}, $host, ${${'GLOBALS'}['gjejvzeg']}, ${${'GLOBALS'}['xtmjcbkgfeb']}, ${${'GLOBALS'}['impztbfgejn']});
}
function Qiniu_Rio_PutFile($upToken, $key, $localFile, $putExtra)
{
    $uyllgxiqeymv = 'fp';
    ${'GLOBALS'}['umigmr'] = 'result';
    $vxudnxr = 'key';
    $nfzhnie = 'fp';
    $bqorfmpq = 'fp';
    ${$bqorfmpq} = fopen(${${'GLOBALS'}['xqdcugsdgv']}, 'rb');
    $pnxryjbifqo = 'fi';
    if (${$uyllgxiqeymv} === false) {
        ${${'GLOBALS'}['wsietbni']} = Qiniu_NewError(0, 'fopen failed');
        return array(null, ${${'GLOBALS'}['wsietbni']});
    }
    ${$pnxryjbifqo} = fstat(${${'GLOBALS'}['nbgrylhqkku']});
    ${${'GLOBALS'}['rjfoougypoye']} = Qiniu_Rio_Put(${${'GLOBALS'}['mlnocyehi']}, ${$vxudnxr}, ${${'GLOBALS'}['nbgrylhqkku']}, ${${'GLOBALS'}['hfgbszef']}['size'], ${${'GLOBALS'}['ksdesm']});
    fclose(${$nfzhnie});
    return ${${'GLOBALS'}['umigmr']};
}
class Qiniu_Error
{
    public $Err;
    public $Reqid;
    public $Details;
    public $Code;
    public function __construct($code, $err)
    {
        ${'GLOBALS'}['vogqjdvi'] = 'code';
        $this->Code = ${${'GLOBALS'}['vogqjdvi']};
        $this->Err = ${${'GLOBALS'}['wsietbni']};
    }
}
class Qiniu_Request
{
    public $URL;
    public $Header;
    public $Body;
    public function __construct($url, $body)
    {
        ${'GLOBALS'}['hohbjyggdl'] = 'url';
        $this->URL = ${${'GLOBALS'}['hohbjyggdl']};
        $this->Header = array();
        $bkovreyfoj = 'body';
        $this->Body = ${$bkovreyfoj};
    }
}
class Qiniu_Response
{
    public $StatusCode;
    public $Header;
    public $ContentLength;
    public $Body;
    public function __construct($code, $body)
    {
        $glnypjkrxe = 'body';
        $clyyhupss = 'body';
        $this->StatusCode = ${${'GLOBALS'}['pjquhttw']};
        $this->Header = array();
        $this->Body = ${$clyyhupss};
        $this->ContentLength = strlen(${$glnypjkrxe});
    }
}
function Qiniu_Header_Get($header, $key)
{
    $awmswpba = 'val';
    ${'GLOBALS'}['wnqrinvlwpkn'] = 'key';
    $obclgkhh = 'val';
    ${'GLOBALS'}['nmtpnuwskvay'] = 'header';
    ${$awmswpba} = @${${'GLOBALS'}['nmtpnuwskvay']}[${${'GLOBALS'}['wnqrinvlwpkn']}];
    if (isset(${$obclgkhh})) {
        $ronzkeicuyv = 'val';
        if (is_array(${${'GLOBALS'}['xeqldqrfeyg']})) {
            ${'GLOBALS'}['kquorza'] = 'val';
            return ${${'GLOBALS'}['kquorza']}[0];
        }
        return ${$ronzkeicuyv};
    } else {
        return '';
    }
}
function Qiniu_ResponseError($resp)
{
    $uvrcqlsjbx = 'header';
    $trtspnhue = 'header';
    $grtkhokh = 'err';
    ${$trtspnhue} = $resp->Header;
    ${${'GLOBALS'}['qxzqwcmieir']} = Qiniu_Header_Get(${${'GLOBALS'}['vvqxewnmy']}, 'X-Log');
    ${${'GLOBALS'}['cxtyldnyhwek']} = Qiniu_Header_Get(${$uvrcqlsjbx}, 'X-Reqid');
    ${${'GLOBALS'}['wsietbni']} = new Qiniu_Error($resp->StatusCode, null);
    if ($err->Code > 299) {
        if ($resp->ContentLength !== 0) {
            $mhyvug = 'header';
            if (Qiniu_Header_Get(${$mhyvug}, 'Content-Type') === 'application/json') {
                $ttglukxbr = 'ret';
                ${'GLOBALS'}['giztpme'] = 'ret';
                ${$ttglukxbr} = json_decode($resp->Body, true);
                $err->Err = ${${'GLOBALS'}['giztpme']}['error'];
            }
        }
    }
    return ${$grtkhokh};
}
function Qiniu_Client_incBody($req)
{
    $yctcabv = 'ct';
    ${'GLOBALS'}['dnwmccijivmr'] = 'body';
    ${${'GLOBALS'}['dnwmccijivmr']} = $req->Body;
    if (!isset(${${'GLOBALS'}['bvklbfdpe']})) {
        return false;
    }
    ${'GLOBALS'}['tdpevtsg'] = 'ct';
    ${$yctcabv} = Qiniu_Header_Get($req->Header, 'Content-Type');
    if (${${'GLOBALS'}['tdpevtsg']} === 'application/x-www-form-urlencoded') {
        return true;
    }
    return false;
}
function Qiniu_Client_do($req)
{
    ${'GLOBALS'}['xqhdpgkv'] = 'ch';
    $psisxysuqo = 'resp';
    $gwufbxxqo = 'options';
    ${${'GLOBALS'}['xqhdpgkv']} = curl_init();
    ${'GLOBALS'}['quuuhrl'] = 'ch';
    ${'GLOBALS'}['qbvoyaodr'] = 'options';
    $ljhlhhcihz = 'body';
    ${'GLOBALS'}['cytdusgfgn'] = 'contentType';
    ${${'GLOBALS'}['vnugmpqtyg']} = $req->URL;
    ${'GLOBALS'}['ctjgoukjrbd'] = 'body';
    ${'GLOBALS'}['dynffyjlqv'] = 'ch';
    ${'GLOBALS'}['tshvviy'] = 'httpHeader';
    $mibghsucbu = 'ch';
    ${${'GLOBALS'}['qbvoyaodr']} = array(CURLOPT_RETURNTRANSFER => true, CURLOPT_SSL_VERIFYPEER => false, CURLOPT_SSL_VERIFYHOST => false, CURLOPT_CUSTOMREQUEST => 'POST', CURLOPT_URL => ${${'GLOBALS'}['vnugmpqtyg']}['path']);
    ${${'GLOBALS'}['tshvviy']} = $req->Header;
    if (!empty(${${'GLOBALS'}['pculdvlbg']})) {
        ${'GLOBALS'}['ilrtikjcd'] = 'parsedUrlValue';
        $tngvtrnhw = 'header';
        ${${'GLOBALS'}['vvqxewnmy']} = array();
        foreach (${${'GLOBALS'}['pculdvlbg']} as ${${'GLOBALS'}['gjejvzeg']} => ${${'GLOBALS'}['ilrtikjcd']}) {
            ${${'GLOBALS'}['vvqxewnmy']}[] = "{$key}: {$parsedUrlValue}";
        }
        ${${'GLOBALS'}['pnnfscvdxiuy']}[CURLOPT_HTTPHEADER] = ${$tngvtrnhw};
    }
    ${${'GLOBALS'}['ctjgoukjrbd']} = $req->Body;
    ${'GLOBALS'}['mgioodffw'] = 'contentType';
    if (!empty(${$ljhlhhcihz})) {
        ${${'GLOBALS'}['pnnfscvdxiuy']}[CURLOPT_POSTFIELDS] = ${${'GLOBALS'}['bvklbfdpe']};
    }
    $lmelgcqawvr = 'ret';
    curl_setopt_array(${${'GLOBALS'}['quuuhrl']}, ${$gwufbxxqo});
    ${'GLOBALS'}['svbcike'] = 'ch';
    ${'GLOBALS'}['xvohyph'] = 'ret';
    ${${'GLOBALS'}['rjfoougypoye']} = curl_exec(${$mibghsucbu});
    ${$lmelgcqawvr} = curl_errno(${${'GLOBALS'}['welkvffrk']});
    if (${${'GLOBALS'}['xvohyph']} !== 0) {
        ${'GLOBALS'}['pivhluhvud'] = 'ch';
        ${'GLOBALS'}['awrwemidww'] = 'err';
        ${${'GLOBALS'}['wsietbni']} = new Qiniu_Error(0, curl_error(${${'GLOBALS'}['pivhluhvud']}));
        curl_close(${${'GLOBALS'}['welkvffrk']});
        return array(null, ${${'GLOBALS'}['awrwemidww']});
    }
    ${${'GLOBALS'}['pjquhttw']} = curl_getinfo(${${'GLOBALS'}['dynffyjlqv']}, CURLINFO_HTTP_CODE);
    ${${'GLOBALS'}['cytdusgfgn']} = curl_getinfo(${${'GLOBALS'}['svbcike']}, CURLINFO_CONTENT_TYPE);
    curl_close(${${'GLOBALS'}['welkvffrk']});
    ${$psisxysuqo} = new Qiniu_Response(${${'GLOBALS'}['pjquhttw']}, ${${'GLOBALS'}['rjfoougypoye']});
    $resp->Header['Content-Type'] = ${${'GLOBALS'}['mgioodffw']};
    return array(${${'GLOBALS'}['ftmcqnlmjhb']}, null);
}
class Qiniu_HttpClient
{
    public function RoundTrip($req)
    {
        return Qiniu_Client_do(${${'GLOBALS'}['tjnglar']});
    }
}
class Qiniu_MacHttpClient
{
    public $Mac;
    public function __construct($mac)
    {
        $this->Mac = Qiniu_RequireMac(${${'GLOBALS'}['tdminl']});
    }
    public function RoundTrip($req)
    {
        ${'GLOBALS'}['vjnzxbqjsvkt'] = 'req';
        ${${'GLOBALS'}['xiekxev']} = Qiniu_Client_incBody(${${'GLOBALS'}['vjnzxbqjsvkt']});
        $hoksklyhp = 'token';
        ${$hoksklyhp} = $this->Mac->SignRequest(${${'GLOBALS'}['tjnglar']}, ${${'GLOBALS'}['xiekxev']});
        $req->Header['Authorization'] = "QBox {$token}";
        return Qiniu_Client_do(${${'GLOBALS'}['tjnglar']});
    }
}
function Qiniu_Client_ret($resp)
{
    $plwxritvixt = 'data';
    $sgrcrxbnnyb = 'data';
    ${${'GLOBALS'}['pjquhttw']} = $resp->StatusCode;
    ${$plwxritvixt} = null;
    if (${${'GLOBALS'}['pjquhttw']} >= 200 && ${${'GLOBALS'}['pjquhttw']} <= 299) {
        if ($resp->ContentLength !== 0) {
            $pfhijvhow = 'data';
            ${${'GLOBALS'}['bqepcs']} = json_decode($resp->Body, true);
            if (${$pfhijvhow} === null) {
                $iplguukxsnc = 'err';
                ${'GLOBALS'}['tfiwvejtm'] = 'err';
                ${${'GLOBALS'}['tfiwvejtm']} = new Qiniu_Error(0, json_last_error_msg());
                return array(null, ${$iplguukxsnc});
            }
        }
        if (${${'GLOBALS'}['pjquhttw']} === 200) {
            $etgfpwo = 'data';
            return array(${$etgfpwo}, null);
        }
    }
    return array(${$sgrcrxbnnyb}, Qiniu_ResponseError(${${'GLOBALS'}['ftmcqnlmjhb']}));
}
function Qiniu_Client_Call($self, $url)
{
    ${'GLOBALS'}['gxhwxwu'] = 'u';
    $tygxwkidzntp = 'u';
    $tuojbvndnmpe = 'resp';
    ${${'GLOBALS'}['gxhwxwu']} = array('path' => ${${'GLOBALS'}['vnugmpqtyg']});
    ${'GLOBALS'}['fjgkpija'] = 'err';
    $gibwztr = 'req';
    ${${'GLOBALS'}['tjnglar']} = new Qiniu_Request(${$tygxwkidzntp}, null);
    list(${$tuojbvndnmpe}, ${${'GLOBALS'}['fjgkpija']}) = $self->RoundTrip(${$gibwztr});
    if (${${'GLOBALS'}['wsietbni']} !== null) {
        return array(null, ${${'GLOBALS'}['wsietbni']});
    }
    return Qiniu_Client_ret(${${'GLOBALS'}['ftmcqnlmjhb']});
}
function Qiniu_Client_CallNoRet($self, $url)
{
    ${'GLOBALS'}['gywkqr'] = 'resp';
    ${'GLOBALS'}['pcbuywlcsw'] = 'err';
    $kypwsswmqk = 'u';
    $njtunkh = 'resp';
    ${'GLOBALS'}['vxudnmoltq'] = 'err';
    $wocmxlog = 'u';
    ${$kypwsswmqk} = array('path' => ${${'GLOBALS'}['vnugmpqtyg']});
    ${'GLOBALS'}['jjwefupt'] = 'req';
    ${${'GLOBALS'}['tjnglar']} = new Qiniu_Request(${$wocmxlog}, null);
    list(${${'GLOBALS'}['gywkqr']}, ${${'GLOBALS'}['vxudnmoltq']}) = $self->RoundTrip(${${'GLOBALS'}['jjwefupt']});
    if (${${'GLOBALS'}['pcbuywlcsw']} !== null) {
        return array(null, ${${'GLOBALS'}['wsietbni']});
    }
    if ($resp->StatusCode === 200) {
        return null;
    }
    return Qiniu_ResponseError(${$njtunkh});
}
function Qiniu_Client_CallWithForm($self, $url, $params, $contentType = 'application/x-www-form-urlencoded')
{
    $vbcgofccro = 'contentType';
    $imijidcqgs = 'params';
    $nstsdmqjfp = 'contentType';
    ${${'GLOBALS'}['walfrwpc']} = array('path' => ${${'GLOBALS'}['vnugmpqtyg']});
    $lymksl = 'req';
    ${'GLOBALS'}['iybxet'] = 'u';
    if (${$vbcgofccro} === 'application/x-www-form-urlencoded') {
        $sfakawfhbyc = 'params';
        if (is_array(${$sfakawfhbyc})) {
            $pkprgrjpumm = 'params';
            ${'GLOBALS'}['bgfpoxg'] = 'params';
            ${$pkprgrjpumm} = http_build_query(${${'GLOBALS'}['bgfpoxg']});
        }
    }
    ${'GLOBALS'}['ovtmxwstcex'] = 'err';
    ${$lymksl} = new Qiniu_Request(${${'GLOBALS'}['iybxet']}, ${$imijidcqgs});
    if (${$nstsdmqjfp} !== 'multipart/form-data') {
        ${'GLOBALS'}['oquhphylgof'] = 'contentType';
        $req->Header['Content-Type'] = ${${'GLOBALS'}['oquhphylgof']};
    }
    list(${${'GLOBALS'}['ftmcqnlmjhb']}, ${${'GLOBALS'}['ovtmxwstcex']}) = $self->RoundTrip(${${'GLOBALS'}['tjnglar']});
    if (${${'GLOBALS'}['wsietbni']} !== null) {
        ${'GLOBALS'}['rrygclnds'] = 'err';
        return array(null, ${${'GLOBALS'}['rrygclnds']});
    }
    return Qiniu_Client_ret(${${'GLOBALS'}['ftmcqnlmjhb']});
}
function Qiniu_Client_CallWithMultipartForm($self, $url, $fields, $files)
{
    ${'GLOBALS'}['qofyogeajyn'] = 'body';
    $tpoqignb = 'files';
    $zsqhxpbsnr = 'body';
    $qyqajc = 'contentType';
    $qqfyfxfdpp = 'self';
    list(${${'GLOBALS'}['vmvgdy']}, ${$zsqhxpbsnr}) = Qiniu_Build_MultipartForm(${${'GLOBALS'}['jfptvrsznsu']}, ${$tpoqignb});
    return Qiniu_Client_CallWithForm(${$qqfyfxfdpp}, ${${'GLOBALS'}['vnugmpqtyg']}, ${${'GLOBALS'}['qofyogeajyn']}, ${$qyqajc});
}
function Qiniu_Build_MultipartForm($fields, $files)
{
    ${'GLOBALS'}['jzfpqubrbvqq'] = 'val';
    $fxarxhmqoy = 'body';
    ${${'GLOBALS'}['bqepcs']} = array();
    ${${'GLOBALS'}['kuxbpnycdn']} = md5(microtime());
    $rxoypdy = 'contentType';
    foreach (${${'GLOBALS'}['jfptvrsznsu']} as ${${'GLOBALS'}['qiughdhwjl']} => ${${'GLOBALS'}['jzfpqubrbvqq']}) {
        ${'GLOBALS'}['mttuitpkt'] = 'mimeBoundary';
        $omhkqslc = 'val';
        $bidstou = 'data';
        $nqrdxokm = 'data';
        array_push(${$bidstou}, '--' . ${${'GLOBALS'}['mttuitpkt']});
        array_push(${${'GLOBALS'}['bqepcs']}, "Content-Disposition: form-data; name=\"{$name}\"");
        array_push(${$nqrdxokm}, '');
        array_push(${${'GLOBALS'}['bqepcs']}, ${$omhkqslc});
    }
    foreach (${${'GLOBALS'}['wsoimxsigpe']} as ${${'GLOBALS'}['npuomvv']}) {
        ${'GLOBALS'}['jbxdhfdkcyw'] = 'data';
        ${'GLOBALS'}['ttxmtyoxx'] = 'fileBody';
        ${'GLOBALS'}['fbisvp'] = 'name';
        $hmhmyavd = 'mimeBoundary';
        array_push(${${'GLOBALS'}['jbxdhfdkcyw']}, '--' . ${$hmhmyavd});
        ${'GLOBALS'}['jrpedlwji'] = 'data';
        list(${${'GLOBALS'}['fbisvp']}, ${${'GLOBALS'}['jwvrxodmnwj']}, ${${'GLOBALS'}['ttxmtyoxx']}) = ${${'GLOBALS'}['npuomvv']};
        $grisdj = 'fileName';
        $ghoqjxtf = 'fileName';
        $gyibsccbh = 'data';
        $ugcqvuo = 'data';
        ${$grisdj} = Qiniu_escapeQuotes(${$ghoqjxtf});
        array_push(${${'GLOBALS'}['jrpedlwji']}, "Content-Disposition: form-data; name=\"{$name}\"; filename=\"{$fileName}\"");
        array_push(${$gyibsccbh}, 'Content-Type: application/octet-stream');
        array_push(${$ugcqvuo}, '');
        array_push(${${'GLOBALS'}['bqepcs']}, ${${'GLOBALS'}['ugbgbxkmnp']});
    }
    $prdvqxn = 'data';
    array_push(${${'GLOBALS'}['bqepcs']}, ('--' . ${${'GLOBALS'}['kuxbpnycdn']}) . '--');
    array_push(${$prdvqxn}, '');
    ${$fxarxhmqoy} = implode('
', ${${'GLOBALS'}['bqepcs']});
    ${$rxoypdy} = 'multipart/form-data; boundary=' . ${${'GLOBALS'}['kuxbpnycdn']};
    return array(${${'GLOBALS'}['vmvgdy']}, ${${'GLOBALS'}['bvklbfdpe']});
}
function Qiniu_escapeQuotes($str)
{
    ${${'GLOBALS'}['xnjjys']} = array('\\', '"');
    ${'GLOBALS'}['pfyogkaodp'] = 'replace';
    ${${'GLOBALS'}['qohsiilc']} = array('\\\\', '\\"');
    return str_replace(${${'GLOBALS'}['xnjjys']}, ${${'GLOBALS'}['pfyogkaodp']}, ${${'GLOBALS'}['fgvupcichziw']});
}
class Qiniu_ImageView
{
    public $Mode;
    public $Width;
    public $Height;
    public $Quality;
    public $Format;
    public function MakeRequest($url)
    {
        ${'GLOBALS'}['iwjwvc'] = 'ops';
        ${'GLOBALS'}['jghfhilfm'] = 'ops';
        ${${'GLOBALS'}['jghfhilfm']} = array($this->Mode);
        if (!empty($this->Width)) {
            ${${'GLOBALS'}['slcwtqbd']}[] = 'w/' . $this->Width;
        }
        if (!empty($this->Height)) {
            $bwsyejy = 'ops';
            ${$bwsyejy}[] = 'h/' . $this->Height;
        }
        if (!empty($this->Quality)) {
            ${${'GLOBALS'}['slcwtqbd']}[] = 'q/' . $this->Quality;
        }
        if (!empty($this->Format)) {
            ${${'GLOBALS'}['slcwtqbd']}[] = 'format/' . $this->Format;
        }
        return (${${'GLOBALS'}['vnugmpqtyg']} . '?imageView/') . implode('/', ${${'GLOBALS'}['iwjwvc']});
    }
}
class Qiniu_Exif
{
    public function MakeRequest($url)
    {
        $nebculi = 'url';
        return ${$nebculi} . '?exif';
    }
}
class Qiniu_ImageInfo
{
    public function MakeRequest($url)
    {
        $mmlmrdks = 'url';
        return ${$mmlmrdks} . '?imageInfo';
    }
}
define('Qiniu_RSF_EOF', 'EOF');
function Qiniu_RSF_ListPrefix($self, $bucket, $prefix = '', $marker = '', $limit = 0)
{
    $vflirbwb = 'items';
    ${'GLOBALS'}['kzqrdjvg'] = 'query';
    ${'GLOBALS'}['sokjly'] = 'marker';
    $ertqmxgrm = 'ret';
    ${'GLOBALS'}['litqdtvucpg'] = 'url';
    ${'GLOBALS'}['rnufaxxxhf'] = 'err';
    global $QINIU_RSF_HOST;
    ${'GLOBALS'}['ilipeydsnl'] = 'prefix';
    ${${'GLOBALS'}['kzqrdjvg']} = array('bucket' => ${${'GLOBALS'}['sgjtht']});
    if (!empty(${${'GLOBALS'}['ilipeydsnl']})) {
        ${${'GLOBALS'}['muqfebrqb']}['prefix'] = ${${'GLOBALS'}['tmuayux']};
    }
    if (!empty(${${'GLOBALS'}['sokjly']})) {
        ${'GLOBALS'}['vtyssrwe'] = 'query';
        ${${'GLOBALS'}['vtyssrwe']}['marker'] = ${${'GLOBALS'}['pqgolbrvk']};
    }
    $gpkthhlgqfl = 'query';
    ${'GLOBALS'}['nelexgvuw'] = 'limit';
    $ffkonqmwyah = 'err';
    ${'GLOBALS'}['plugwleon'] = 'markerOut';
    $fiyneed = 'ret';
    if (!empty(${${'GLOBALS'}['nelexgvuw']})) {
        ${${'GLOBALS'}['muqfebrqb']}['limit'] = ${${'GLOBALS'}['eblbrhqk']};
    }
    ${${'GLOBALS'}['litqdtvucpg']} = (${${'GLOBALS'}['ownccyg']} . '/list?') . http_build_query(${$gpkthhlgqfl});
    list(${$ertqmxgrm}, ${${'GLOBALS'}['wsietbni']}) = Qiniu_Client_Call(${${'GLOBALS'}['qqepwu']}, ${${'GLOBALS'}['vnugmpqtyg']});
    ${'GLOBALS'}['ombudosbghx'] = 'ret';
    if (${$ffkonqmwyah} !== null) {
        ${'GLOBALS'}['tcgpcbp'] = 'err';
        return array(null, '', ${${'GLOBALS'}['tcgpcbp']});
    }
    ${${'GLOBALS'}['mdenknnuigl']} = ${${'GLOBALS'}['ombudosbghx']}['items'];
    if (empty(${$fiyneed}['marker'])) {
        ${${'GLOBALS'}['kvsbddplpzu']} = '';
        ${${'GLOBALS'}['wsietbni']} = Qiniu_RSF_EOF;
    } else {
        ${'GLOBALS'}['jwdbtdfsm'] = 'ret';
        ${${'GLOBALS'}['kvsbddplpzu']} = ${${'GLOBALS'}['jwdbtdfsm']}['marker'];
    }
    return array(${$vflirbwb}, ${${'GLOBALS'}['plugwleon']}, ${${'GLOBALS'}['rnufaxxxhf']});
}
class Qiniu_Mac
{
    public $AccessKey;
    public $SecretKey;
    public function __construct($accessKey, $secretKey)
    {
        ${'GLOBALS'}['xvwtaxoebo'] = 'accessKey';
        $this->AccessKey = ${${'GLOBALS'}['xvwtaxoebo']};
        $this->SecretKey = ${${'GLOBALS'}['dfxsaumpg']};
    }
    public function Sign($data)
    {
        $upgbfhbdq = 'data';
        $tsvcklsynzdw = 'sign';
        ${$tsvcklsynzdw} = hash_hmac('sha1', ${$upgbfhbdq}, $this->SecretKey, true);
        return ($this->AccessKey . ':') . Qiniu_Encode(${${'GLOBALS'}['bibpwf']});
    }
    public function SignWithData($data)
    {
        ${'GLOBALS'}['mrqwwd'] = 'data';
        ${'GLOBALS'}['xvwhjq'] = 'data';
        ${${'GLOBALS'}['mrqwwd']} = Qiniu_Encode(${${'GLOBALS'}['xvwhjq']});
        return ($this->Sign(${${'GLOBALS'}['bqepcs']}) . ':') . ${${'GLOBALS'}['bqepcs']};
    }
    public function SignRequest($req, $incbody)
    {
        $rchynqnpn = 'url';
        ${$rchynqnpn} = $req->URL;
        ${'GLOBALS'}['lhgkvae'] = 'url';
        $qdwyhfthclk = 'url';
        ${${'GLOBALS'}['vnugmpqtyg']} = parse_url(${$qdwyhfthclk}['path']);
        ${'GLOBALS'}['xqiudvchbl'] = 'data';
        ${${'GLOBALS'}['xqiudvchbl']} = '';
        if (isset(${${'GLOBALS'}['lhgkvae']}['path'])) {
            $oftljbdxzv = 'data';
            ${'GLOBALS'}['iznjehmzc'] = 'url';
            ${$oftljbdxzv} = ${${'GLOBALS'}['iznjehmzc']}['path'];
        }
        if (isset(${${'GLOBALS'}['vnugmpqtyg']}['query'])) {
            ${'GLOBALS'}['odawjfhoql'] = 'data';
            $ubpzewgl = 'url';
            ${${'GLOBALS'}['odawjfhoql']} .= '?' . ${$ubpzewgl}['query'];
        }
        ${${'GLOBALS'}['bqepcs']} .= '
';
        if (${${'GLOBALS'}['xiekxev']}) {
            $bwmycjjoga = 'data';
            ${$bwmycjjoga} .= $req->Body;
        }
        return $this->Sign(${${'GLOBALS'}['bqepcs']});
    }
}
$jfsuwtgxocuz = 'freeLinkPosts';
function Qiniu_SetKeys($accessKey, $secretKey)
{
    $gwjxnsu = 'QINIU_SECRET_KEY';
    ${'GLOBALS'}['cvlktodld'] = 'accessKey';
    global $QINIU_ACCESS_KEY;
    global $QINIU_SECRET_KEY;
    ${${'GLOBALS'}['vwfywsuw']} = ${${'GLOBALS'}['cvlktodld']};
    ${$gwjxnsu} = ${${'GLOBALS'}['dfxsaumpg']};
}
function Qiniu_RequireMac($mac)
{
    if (isset(${${'GLOBALS'}['tdminl']})) {
        return ${${'GLOBALS'}['tdminl']};
    }
    global $QINIU_ACCESS_KEY;
    global $QINIU_SECRET_KEY;
    return new Qiniu_Mac(${${'GLOBALS'}['vwfywsuw']}, ${${'GLOBALS'}['knvsekhg']});
}
function Qiniu_Sign($mac, $data)
{
    ${'GLOBALS'}['wycojnf'] = 'data';
    return Qiniu_RequireMac(${${'GLOBALS'}['tdminl']})->Sign(${${'GLOBALS'}['wycojnf']});
}
function Qiniu_SignWithData($mac, $data)
{
    $votgxbq = 'mac';
    ${'GLOBALS'}['nooxkrvg'] = 'data';
    return Qiniu_RequireMac(${$votgxbq})->SignWithData(${${'GLOBALS'}['nooxkrvg']});
}
function Qinniu_upload_to_bucket($bucket, $file, $key)
{
    ${'GLOBALS'}['lsyerbypdmxk'] = 'putPolicy';
    $smagujvbst = 'upToken';
    $yrilwsapme = 'putExtra';
    ${${'GLOBALS'}['lsyerbypdmxk']} = new Qiniu_RS_PutPolicy(${${'GLOBALS'}['sgjtht']});
    ${$smagujvbst} = $putPolicy->Token(null);
    ${${'GLOBALS'}['ksdesm']} = new Qiniu_PutExtra();
    $putExtra->Crc32 = 1;
    ${'GLOBALS'}['jkgqnxdqk'] = 'key';
    return Qiniu_PutFile(${${'GLOBALS'}['mlnocyehi']}, ${${'GLOBALS'}['jkgqnxdqk']}, ${${'GLOBALS'}['npuomvv']}, ${$yrilwsapme});
}
class apUpYunException extends Exception
{
    public function __construct($message, $code, Exception $previous = null)
    {
        parent::__construct(${${'GLOBALS'}['xffdwsdp']}, ${${'GLOBALS'}['pjquhttw']});
    }
    public function __toString()
    {
        return __CLASS__ . ": [{$this->code}]: {$this->message}\n";
    }
}
class apUpYunAuthorizationException extends apUpYunException
{
    public function __construct($message, $code = 0, Exception $previous = null)
    {
        ${'GLOBALS'}['objahsvpgmu'] = 'previous';
        parent::__construct(${${'GLOBALS'}['xffdwsdp']}, 401, ${${'GLOBALS'}['objahsvpgmu']});
    }
}
class apUpYunForbiddenException extends apUpYunException
{
    public function __construct($message, $code = 0, Exception $previous = null)
    {
        $vnpmnhs = 'previous';
        parent::__construct(${${'GLOBALS'}['xffdwsdp']}, 403, ${$vnpmnhs});
    }
}
class apUpYunNotFoundException extends apUpYunException
{
    public function __construct($message, $code = 0, Exception $previous = null)
    {
        $lrhkvsd = 'previous';
        parent::__construct(${${'GLOBALS'}['xffdwsdp']}, 404, ${$lrhkvsd});
    }
}
class apUpYunNotAcceptableException extends apUpYunException
{
    public function __construct($message, $code = 0, Exception $previous = null)
    {
        ${'GLOBALS'}['jiomdoow'] = 'message';
        parent::__construct(${${'GLOBALS'}['jiomdoow']}, 406, ${${'GLOBALS'}['mbfpkxftx']});
    }
}
class apUpYunServiceUnavailable extends apUpYunException
{
    public function __construct($message, $code = 0, Exception $previous = null)
    {
        parent::__construct(${${'GLOBALS'}['xffdwsdp']}, 503, ${${'GLOBALS'}['mbfpkxftx']});
    }
}
class apUpYun
{
    const VERSION = '2.0';
    const ED_AUTO = 'v0.api.upyun.com';
    const ED_TELECOM = 'v1.api.upyun.com';
    const ED_CNC = 'v2.api.upyun.com';
    const ED_CTT = 'v3.api.upyun.com';
    const CONTENT_TYPE = 'Content-Type';
    const CONTENT_MD5 = 'Content-MD5';
    const CONTENT_SECRET = 'Content-Secret';
    const X_GMKERL_THUMBNAIL = 'x-gmkerl-thumbnail';
    const X_GMKERL_TYPE = 'x-gmkerl-type';
    const X_GMKERL_VALUE = 'x-gmkerl-value';
    const X_GMKERL_QUALITY = 'x??gmkerl-quality';
    const X_GMKERL_UNSHARP = 'x??gmkerl-unsharp';
    private $_bucket_name;
    private $_username;
    private $_password;
    private $_timeout = 30;
    private $_content_md5 = NULL;
    private $_file_secret = NULL;
    private $_file_infos = NULL;
    protected $endpoint;
    public function __construct($bucketname, $username, $password, $endpoint = NULL, $timeout = 30)
    {
        ${'GLOBALS'}['eswxxoqskop'] = 'username';
        ${'GLOBALS'}['hryogzu'] = 'endpoint';
        $yymzjfsfjew = 'password';
        $this->_bucketname = ${${'GLOBALS'}['trgiufwu']};
        $this->_username = ${${'GLOBALS'}['eswxxoqskop']};
        $this->_password = md5(${$yymzjfsfjew});
        $this->_timeout = ${${'GLOBALS'}['oheisrnz']};
        $this->endpoint = is_null(${${'GLOBALS'}['hryogzu']}) ? self::ED_AUTO : ${${'GLOBALS'}['xbvhpehrca']};
    }
    public function version()
    {
        return self::VERSION;
    }
    public function makeDir($path, $auto_mkdir = false)
    {
        ${'GLOBALS'}['dbthkck'] = 'auto_mkdir';
        $wzrrmgxpdoqs = 'headers';
        $eqiesqalh = 'headers';
        $abguagfi = 'headers';
        ${$wzrrmgxpdoqs} = array('Folder' => 'true');
        if (${${'GLOBALS'}['dbthkck']}) {
            ${$eqiesqalh}['Mkdir'] = 'true';
        }
        return $this->_do_request('PUT', ${${'GLOBALS'}['trrofof']}, ${$abguagfi});
    }
    public function delete($path)
    {
        return $this->_do_request('DELETE', ${${'GLOBALS'}['trrofof']});
    }
    public function writeFile($path, $file, $auto_mkdir = False, $opts = NULL)
    {
        ${'GLOBALS'}['ixrtdmjepcl'] = 'file';
        ${'GLOBALS'}['vsymahkhi'] = 'opts';
        ${'GLOBALS'}['nujmjkhrksvq'] = 'opts';
        if (is_null(${${'GLOBALS'}['nujmjkhrksvq']})) {
            ${${'GLOBALS'}['vsymahkhi']} = array();
        }
        if (!is_null($this->_content_md5) || !is_null($this->_file_secret)) {
            if (!is_null($this->_content_md5)) {
                ${${'GLOBALS'}['fmadgywwk']}[self::CONTENT_MD5] = $this->_content_md5;
            }
            $jiiecrph = 'opts';
            if (!is_null($this->_file_secret)) {
                ${$jiiecrph}[self::CONTENT_SECRET] = $this->_file_secret;
            }
        }
        if (${${'GLOBALS'}['vecvovf']} === True) {
            ${${'GLOBALS'}['fmadgywwk']}['Mkdir'] = 'true';
        }
        $this->_file_infos = $this->_do_request('PUT', ${${'GLOBALS'}['trrofof']}, ${${'GLOBALS'}['fmadgywwk']}, ${${'GLOBALS'}['ixrtdmjepcl']});
        return $this->_file_infos;
    }
    public function readFile($path, $file_handle = NULL)
    {
        $bthlrmdqqp = 'path';
        return $this->_do_request('GET', ${$bthlrmdqqp}, NULL, NULL, ${${'GLOBALS'}['lbscyktjprb']});
    }
    public function getList($path = '/')
    {
        $dmspqf = 'path';
        ${${'GLOBALS'}['dscdjohpgr']} = $this->_do_request('GET', ${$dmspqf});
        $hqtrcbyp = 'rsp';
        ${${'GLOBALS'}['uyyltoqjq']} = array();
        if (${$hqtrcbyp}) {
            ${'GLOBALS'}['qpmzqehwvkf'] = 'rsp';
            ${'GLOBALS'}['zupnipbu'] = 'rsp';
            ${${'GLOBALS'}['zupnipbu']} = explode('
', ${${'GLOBALS'}['qpmzqehwvkf']});
            $yfypmgrp = 'item';
            ${'GLOBALS'}['hepwthvxi'] = 'rsp';
            foreach (${${'GLOBALS'}['hepwthvxi']} as ${$yfypmgrp}) {
                ${'GLOBALS'}['uhrnvqfn'] = 'item';
                ${'GLOBALS'}['jlglqqczotns'] = 'size';
                @(list(${${'GLOBALS'}['qiughdhwjl']}, ${${'GLOBALS'}['pvdlywl']}, ${${'GLOBALS'}['ymnwmx']}, ${${'GLOBALS'}['iphyvlv']}) = explode('	', trim(${${'GLOBALS'}['vjefgcj']})));
                ${'GLOBALS'}['eccfulin'] = 'list';
                $ylrewzivwg = 'time';
                $axhqppxg = 'item';
                if (!empty(${${'GLOBALS'}['iphyvlv']})) {
                    ${${'GLOBALS'}['pvdlywl']} = ${${'GLOBALS'}['pvdlywl']} == 'N' ? 'file' : 'folder';
                }
                ${${'GLOBALS'}['uhrnvqfn']} = array('name' => ${${'GLOBALS'}['qiughdhwjl']}, 'type' => ${${'GLOBALS'}['pvdlywl']}, 'size' => intval(${${'GLOBALS'}['jlglqqczotns']}), 'time' => intval(${$ylrewzivwg}));
                array_push(${${'GLOBALS'}['eccfulin']}, ${$axhqppxg});
            }
        }
        $meubjsqlmm = 'list';
        return ${$meubjsqlmm};
    }
    public function getFolderUsage($path = '/')
    {
        ${'GLOBALS'}['awynclgoqgc'] = 'rsp';
        ${'GLOBALS'}['rmdxqtd'] = 'rsp';
        ${${'GLOBALS'}['rmdxqtd']} = $this->_do_request('GET', '/?usage');
        return floatval(${${'GLOBALS'}['awynclgoqgc']});
    }
    public function getFileInfo($path)
    {
        $jnqwpmsxbqv = 'path';
        $qmrtiby = 'rsp';
        ${$qmrtiby} = $this->_do_request('HEAD', ${$jnqwpmsxbqv});
        return ${${'GLOBALS'}['dscdjohpgr']};
    }
    private function sign($method, $uri, $date, $length)
    {
        ${${'GLOBALS'}['bibpwf']} = "{$method}&{$uri}&{$date}&{$length}&{$this->_password}";
        return (('UpYun ' . $this->_username) . ':') . md5(${${'GLOBALS'}['bibpwf']});
    }
    protected function _do_request($method, $path, $headers = NULL, $body = NULL, $file_handle = NULL)
    {
        ${'GLOBALS'}['reopchd'] = 'uri';
        $lnjokl = 'length';
        ${${'GLOBALS'}['reopchd']} = "/{$this->_bucketname}{$path}";
        $quccodotmr = '_headers';
        ${${'GLOBALS'}['welkvffrk']} = curl_init("http://{$this->endpoint}{$uri}");
        ${$quccodotmr} = array('Expect:');
        $zxddwiivouj = 'file_handle';
        if (!is_null(${${'GLOBALS'}['nvswoswm']}) && is_array(${${'GLOBALS'}['nvswoswm']})) {
            ${'GLOBALS'}['nigpsxqko'] = 'k';
            ${'GLOBALS'}['bphhxjpry'] = 'headers';
            foreach (${${'GLOBALS'}['bphhxjpry']} as ${${'GLOBALS'}['nigpsxqko']} => ${${'GLOBALS'}['xkxdeg']}) {
                array_push(${${'GLOBALS'}['sifojbttww']}, "{$k}: {$v}");
            }
        }
        $iseygqpqi = '_headers';
        ${$lnjokl} = 0;
        $myevwqnqiuf = 'method';
        ${${'GLOBALS'}['ejfkcbwayj']} = gmdate('D, d M Y H:i:s \\G\\M\\T');
        if (!is_null(${${'GLOBALS'}['bvklbfdpe']})) {
            $ohdmkyu = 'body';
            if (is_resource(${$ohdmkyu})) {
                ${'GLOBALS'}['rcpxjdwro'] = '_headers';
                $mmokpbyovxf = 'length';
                fseek(${${'GLOBALS'}['bvklbfdpe']}, 0, SEEK_END);
                ${$mmokpbyovxf} = ftell(${${'GLOBALS'}['bvklbfdpe']});
                ${'GLOBALS'}['opyoegjnfywv'] = 'body';
                fseek(${${'GLOBALS'}['bvklbfdpe']}, 0);
                ${'GLOBALS'}['smfghaem'] = 'ch';
                ${'GLOBALS'}['imtcuwhgld'] = 'ch';
                array_push(${${'GLOBALS'}['rcpxjdwro']}, "Content-Length: {$length}");
                curl_setopt(${${'GLOBALS'}['imtcuwhgld']}, CURLOPT_INFILE, ${${'GLOBALS'}['opyoegjnfywv']});
                curl_setopt(${${'GLOBALS'}['smfghaem']}, CURLOPT_INFILESIZE, ${${'GLOBALS'}['wtkpcrlk']});
            } else {
                ${'GLOBALS'}['cmscxfmrdv'] = 'ch';
                $dyiolqx = 'length';
                ${$dyiolqx} = @strlen(${${'GLOBALS'}['bvklbfdpe']});
                ${'GLOBALS'}['rbskhwk'] = '_headers';
                array_push(${${'GLOBALS'}['rbskhwk']}, "Content-Length: {$length}");
                ${'GLOBALS'}['yoummb'] = 'body';
                curl_setopt(${${'GLOBALS'}['cmscxfmrdv']}, CURLOPT_POSTFIELDS, ${${'GLOBALS'}['yoummb']});
            }
        } else {
            $moxudvfe = '_headers';
            array_push(${$moxudvfe}, "Content-Length: {$length}");
        }
        array_push(${${'GLOBALS'}['sifojbttww']}, "Authorization: {$this->sign($method, $uri, $date, $length)}");
        array_push(${$iseygqpqi}, "Date: {$date}");
        curl_setopt(${${'GLOBALS'}['welkvffrk']}, CURLOPT_HTTPHEADER, ${${'GLOBALS'}['sifojbttww']});
        curl_setopt(${${'GLOBALS'}['welkvffrk']}, CURLOPT_TIMEOUT, $this->_timeout);
        ${'GLOBALS'}['nafhpbpwlpl'] = 'body';
        curl_setopt(${${'GLOBALS'}['welkvffrk']}, CURLOPT_HEADER, 1);
        ${'GLOBALS'}['vbgioxvvqe'] = 'http_code';
        ${'GLOBALS'}['kmhjnxbtbw'] = 'http_code';
        $jqaihcaoci = 'method';
        $pduifvvs = 'ch';
        curl_setopt(${${'GLOBALS'}['welkvffrk']}, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt(${${'GLOBALS'}['welkvffrk']}, CURLOPT_FOLLOWLOCATION, 0);
        ${'GLOBALS'}['eccpjdgaco'] = 'method';
        ${'GLOBALS'}['rquprgpygm'] = 'ch';
        ${'GLOBALS'}['uqkffkkffky'] = 'response';
        curl_setopt(${$pduifvvs}, CURLOPT_CUSTOMREQUEST, ${$jqaihcaoci});
        if (${${'GLOBALS'}['eccpjdgaco']} == 'PUT' || ${${'GLOBALS'}['ximxtrbesm']} == 'POST') {
            curl_setopt(${${'GLOBALS'}['welkvffrk']}, CURLOPT_POST, 1);
        } else {
            ${'GLOBALS'}['dbxajt'] = 'ch';
            curl_setopt(${${'GLOBALS'}['dbxajt']}, CURLOPT_POST, 0);
        }
        ${'GLOBALS'}['eghuiix'] = 'ch';
        if (${${'GLOBALS'}['ximxtrbesm']} == 'GET' && is_resource(${$zxddwiivouj})) {
            ${'GLOBALS'}['iqhwqcexnc'] = 'ch';
            ${'GLOBALS'}['ktfnjtshrr'] = 'file_handle';
            ${'GLOBALS'}['vhgxocnrref'] = 'ch';
            curl_setopt(${${'GLOBALS'}['vhgxocnrref']}, CURLOPT_HEADER, 0);
            curl_setopt(${${'GLOBALS'}['iqhwqcexnc']}, CURLOPT_FILE, ${${'GLOBALS'}['ktfnjtshrr']});
        }
        ${'GLOBALS'}['mltgpsbw'] = 'header_string';
        if (${$myevwqnqiuf} == 'HEAD') {
            ${'GLOBALS'}['wxsrkhrbq'] = 'ch';
            curl_setopt(${${'GLOBALS'}['wxsrkhrbq']}, CURLOPT_NOBODY, true);
        }
        ${${'GLOBALS'}['uqkffkkffky']} = curl_exec(${${'GLOBALS'}['rquprgpygm']});
        ${${'GLOBALS'}['jddwlnpgxn']} = curl_getinfo(${${'GLOBALS'}['welkvffrk']}, CURLINFO_HTTP_CODE);
        if (${${'GLOBALS'}['vbgioxvvqe']} == 0) {
            throw new apUpYunException('Connection Failed', ${${'GLOBALS'}['jddwlnpgxn']});
        }
        curl_close(${${'GLOBALS'}['eghuiix']});
        ${${'GLOBALS'}['mltgpsbw']} = '';
        ${${'GLOBALS'}['nafhpbpwlpl']} = '';
        if (${${'GLOBALS'}['ximxtrbesm']} == 'GET' && is_resource(${${'GLOBALS'}['lbscyktjprb']})) {
            ${${'GLOBALS'}['tculsahk']} = '';
            ${${'GLOBALS'}['bvklbfdpe']} = ${${'GLOBALS'}['xwnretuddof']};
        } else {
            $grknprtvk = 'response';
            $unfuawpstui = 'header_string';
            list(${$unfuawpstui}, ${${'GLOBALS'}['bvklbfdpe']}) = explode('

', ${$grknprtvk}, 2);
        }
        if (${${'GLOBALS'}['kmhjnxbtbw']} == 200) {
            ${'GLOBALS'}['mpvmfo'] = 'file_handle';
            $wrxmfvwzcmko = 'method';
            if (${$wrxmfvwzcmko} == 'GET' && is_null(${${'GLOBALS'}['mpvmfo']})) {
                return ${${'GLOBALS'}['bvklbfdpe']};
            } else {
                ${'GLOBALS'}['rtltbqsfbv'] = 'data';
                ${${'GLOBALS'}['rtltbqsfbv']} = $this->_getHeadersData(${${'GLOBALS'}['tculsahk']});
                return count(${${'GLOBALS'}['bqepcs']}) > 0 ? ${${'GLOBALS'}['bqepcs']} : true;
            }
        } else {
            $lpxjrqdhro = 'message';
            ${'GLOBALS'}['kelexjpqb'] = 'http_code';
            ${'GLOBALS'}['afxfgiwtv'] = 'message';
            ${'GLOBALS'}['mthpvsqxu'] = 'message';
            ${'GLOBALS'}['khwoomhmwnq'] = 'message';
            ${'GLOBALS'}['qwnrinhtji'] = 'method';
            $asngydanp = 'message';
            $stfnlbl = 'file_handle';
            ${${'GLOBALS'}['khwoomhmwnq']} = $this->_getErrorMessage(${${'GLOBALS'}['tculsahk']});
            if ((is_null(${$asngydanp}) && ${${'GLOBALS'}['qwnrinhtji']} == 'GET') && is_resource(${$stfnlbl})) {
                ${'GLOBALS'}['aungxqqgmh'] = 'message';
                ${${'GLOBALS'}['aungxqqgmh']} = 'File Not Found';
            }
            switch (${${'GLOBALS'}['jddwlnpgxn']}) {
            case 401:
                throw new apUpYunAuthorizationException(${${'GLOBALS'}['mthpvsqxu']});
                break;
            case 403:
                throw new apUpYunForbiddenException(${${'GLOBALS'}['xffdwsdp']});
                break;
            case 404:
                throw new apUpYunNotFoundException(${${'GLOBALS'}['xffdwsdp']});
                break;
            case 406:
                throw new apUpYunNotAcceptableException(${$lpxjrqdhro});
                break;
            case 503:
                throw new apUpYunServiceUnavailable(${${'GLOBALS'}['xffdwsdp']});
                break;
            default:
                throw new apUpYunException(${${'GLOBALS'}['afxfgiwtv']}, ${${'GLOBALS'}['kelexjpqb']});
            }
        }
    }
    private function _getHeadersData($text)
    {
        ${'GLOBALS'}['rgokymhblrbn'] = 'items';
        $ybsnegxr = 'items';
        ${'GLOBALS'}['dcpyeg'] = 'headers';
        ${${'GLOBALS'}['nvswoswm']} = explode('
', ${${'GLOBALS'}['kueflpmp']});
        ${${'GLOBALS'}['rgokymhblrbn']} = array();
        foreach (${${'GLOBALS'}['dcpyeg']} as ${${'GLOBALS'}['vvqxewnmy']}) {
            ${'GLOBALS'}['etorwmsu'] = 'header';
            ${${'GLOBALS'}['etorwmsu']} = trim(${${'GLOBALS'}['vvqxewnmy']});
            if (strpos(${${'GLOBALS'}['vvqxewnmy']}, 'x-upyun') !== False) {
                list(${${'GLOBALS'}['vbfqlfs']}, ${${'GLOBALS'}['xkxdeg']}) = explode(':', ${${'GLOBALS'}['vvqxewnmy']});
                ${'GLOBALS'}['fhtdwqqu'] = 'k';
                ${${'GLOBALS'}['mdenknnuigl']}[trim(${${'GLOBALS'}['fhtdwqqu']})] = in_array(substr(${${'GLOBALS'}['vbfqlfs']}, 8, 5), array('width', 'heigh', 'frame')) ? intval(${${'GLOBALS'}['xkxdeg']}) : trim(${${'GLOBALS'}['xkxdeg']});
            }
        }
        return ${$ybsnegxr};
    }
    private function _getErrorMessage($header_string)
    {
        ${'GLOBALS'}['jhvjjo'] = 'header_string';
        ${'GLOBALS'}['outdion'] = 'v';
        ${'GLOBALS'}['neljhl'] = 'status';
        ${'GLOBALS'}['btefjeyeqrdy'] = 'message';
        list(${${'GLOBALS'}['fimfwyd']}, ${${'GLOBALS'}['wbfrlve']}) = explode('
', ${${'GLOBALS'}['jhvjjo']}, 2);
        list(${${'GLOBALS'}['outdion']}, ${${'GLOBALS'}['pjquhttw']}, ${${'GLOBALS'}['btefjeyeqrdy']}) = explode(' ', ${${'GLOBALS'}['neljhl']}, 3);
        return ${${'GLOBALS'}['xffdwsdp']};
    }
    public function rmDir($path)
    {
        ${'GLOBALS'}['faxlldtl'] = 'path';
        $this->_do_request('DELETE', ${${'GLOBALS'}['faxlldtl']});
    }
    public function deleteFile($path)
    {
        ${'GLOBALS'}['swdpjsla'] = 'path';
        ${${'GLOBALS'}['dscdjohpgr']} = $this->_do_request('DELETE', ${${'GLOBALS'}['swdpjsla']});
    }
    public function readDir($path)
    {
        $nagpujure = 'path';
        return $this->getList(${$nagpujure});
    }
    public function getBucketUsage()
    {
        return $this->getFolderUsage('/');
    }
    public function setApiDomain($domain)
    {
        $cvlocaxnlkj = 'domain';
        $this->endpoint = ${$cvlocaxnlkj};
    }
    public function setContentMD5($str)
    {
        ${'GLOBALS'}['xrozeuuvisf'] = 'str';
        $this->_content_md5 = ${${'GLOBALS'}['xrozeuuvisf']};
    }
    public function setFileSecret($str)
    {
        $this->_file_secret = ${${'GLOBALS'}['fgvupcichziw']};
    }
    public function getWritedFileInfo($key)
    {
        if (!isset($this->_file_infos)) {
            return NULL;
        }
        return $this->_file_infos[${${'GLOBALS'}['gjejvzeg']}];
    }
    public function makeBaseUrl($domain, $key)
    {
        return "http://{$domain}{$key}";
    }
}
if (function_exists('curl_init')) {
    define('Method', 0);
} else {
    define('Method', 1);
}
define('HDOM_TYPE_ELEMENT', 1);
define('HDOM_TYPE_COMMENT', 2);
define('HDOM_TYPE_TEXT', 3);
define('HDOM_TYPE_ENDTAG', 4);
define('HDOM_TYPE_ROOT', 5);
define('HDOM_TYPE_UNKNOWN', 6);
define('HDOM_QUOTE_DOUBLE', 0);
define('HDOM_QUOTE_SINGLE', 1);
define('HDOM_QUOTE_NO', 3);
define('HDOM_INFO_BEGIN', 0);
define('HDOM_INFO_END', 1);
define('HDOM_INFO_QUOTE', 2);
define('HDOM_INFO_SPACE', 3);
define('HDOM_INFO_TEXT', 4);
define('HDOM_INFO_INNER', 5);
define('HDOM_INFO_OUTER', 6);
define('HDOM_INFO_ENDSPACE', 7);
define('DEFAULT_TARGET_CHARSET', 'UTF-8');
define('DEFAULT_BR_TEXT', '
');
define('DEFAULT_SPAN_TEXT', ' ');
define('MAX_FILE_SIZE', 600000);
if ((ini_get('safe_mode') == 0 || ini_get('safe_mode') == null) && ini_get('open_basedir') == '') {
    define('CAN_FOLLOWLOCATION', 1);
} else {
    define('CAN_FOLLOWLOCATION', 0);
}
function curl_get_contents($url, $useProxy = 0, $proxy = null, $hideIP = 0, $timeout = 30)
{
    $qsorfxenfc = 'curlHandle';
    $pkfmnxui = 'curlHandle';
    ${$qsorfxenfc} = curl_init();
    ${${'GLOBALS'}['bpytrkmufvtv']} = 'Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.19 (KHTML, like Gecko) Chrome/25.0.1323.1 Safari/537.19';
    $jiqpithvobg = 'curlHandle';
    $kxefqxegyfz = 'curlHandle';
    $uyedpnhr = 'agent';
    curl_setopt(${${'GLOBALS'}['rsgwcunlw']}, CURLOPT_URL, ${${'GLOBALS'}['vnugmpqtyg']});
    curl_setopt(${${'GLOBALS'}['rsgwcunlw']}, CURLOPT_TIMEOUT, ${${'GLOBALS'}['oheisrnz']});
    ${'GLOBALS'}['gnwbqplfy'] = 'curlHandle';
    $allhnub = 'curlHandle';
    curl_setopt(${$allhnub}, CURLOPT_USERAGENT, ${$uyedpnhr});
    curl_setopt(${$pkfmnxui}, CURLOPT_REFERER, _REFERER_);
    curl_setopt(${$jiqpithvobg}, CURLOPT_HEADER, false);
    curl_setopt(${${'GLOBALS'}['gnwbqplfy']}, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt(${${'GLOBALS'}['rsgwcunlw']}, CURLOPT_ENCODING, '');
    if (${${'GLOBALS'}['yviqqwtvrpu']} == 1) {
        $eietmuzjzy = 'proxy';
        ${'GLOBALS'}['ycjpjahsvj'] = 'proxy';
        ${'GLOBALS'}['uvrogfy'] = 'proxy';
        ${'GLOBALS'}['euvcoloxxst'] = 'curlHandle';
        $gmmgnht = 'curlHandle';
        $ueiphltvno = 'proxy';
        curl_setopt(${$gmmgnht}, CURLOPT_PROXY, ${$eietmuzjzy}['ip']);
        curl_setopt(${${'GLOBALS'}['euvcoloxxst']}, CURLOPT_PROXYPORT, ${$ueiphltvno}['port']);
        if (((${${'GLOBALS'}['ycjpjahsvj']}['user'] != '' && ${${'GLOBALS'}['uvrogfy']}['user'] != NULL) && ${${'GLOBALS'}['jnjrlqgm']}['password'] != '') && ${${'GLOBALS'}['jnjrlqgm']}['password'] != NULL) {
            ${'GLOBALS'}['nhvfwjquvvwc'] = 'proxy';
            $qstduhkudy = 'proxy';
            ${${'GLOBALS'}['pwwmkbuuqh']} = (${${'GLOBALS'}['nhvfwjquvvwc']}['user'] . ':') . ${$qstduhkudy}['password'];
            curl_setopt(${${'GLOBALS'}['rsgwcunlw']}, CURLOPT_PROXYUSERPWD, ${${'GLOBALS'}['pwwmkbuuqh']});
        }
    }
    if (${${'GLOBALS'}['biduxjlipd']} == 1) {
        $fusobefx = 'ip';
        ${$fusobefx} = (((((rand(1, 223) . '.') . rand(1, 254)) . '.') . rand(1, 254)) . '.') . rand(1, 254);
        curl_setopt(${${'GLOBALS'}['rsgwcunlw']}, CURLOPT_HTTPHEADER, array('X-FORWARDED-FOR:' . ${${'GLOBALS'}['ixmliiphljx']}, 'CLIENT-IP:' . ${${'GLOBALS'}['ixmliiphljx']}));
    }
    ${${'GLOBALS'}['rjfoougypoye']} = curl_exec_follow(${$kxefqxegyfz});
    curl_close(${${'GLOBALS'}['rsgwcunlw']});
    return ${${'GLOBALS'}['rjfoougypoye']};
}
function curl_exec_follow($ch, &$maxredirect = null)
{
    $vqdvhixvx = 'maxredirect';
    $pmmwgpjnsj = 'maxredirect';
    ${${'GLOBALS'}['flqjref']} = ${$pmmwgpjnsj} === null ? 5 : intval(${$vqdvhixvx});
    $kufovqrgzxb = 'ch';
    if (CAN_FOLLOWLOCATION == 1) {
        $nsdnkbvj = 'ch';
        $ijnjcyxmju = 'mr';
        curl_setopt(${${'GLOBALS'}['welkvffrk']}, CURLOPT_FOLLOWLOCATION, ${${'GLOBALS'}['flqjref']} > 0);
        curl_setopt(${$nsdnkbvj}, CURLOPT_MAXREDIRS, ${$ijnjcyxmju});
    } else {
        ${'GLOBALS'}['npwmgrlaygq'] = 'ch';
        curl_setopt(${${'GLOBALS'}['npwmgrlaygq']}, CURLOPT_FOLLOWLOCATION, false);
        if (${${'GLOBALS'}['flqjref']} > 0) {
            $tqckhjmntcr = 'rch';
            ${'GLOBALS'}['bcqhejq'] = 'rch';
            $aducpzcuvfu = 'rch';
            $rcaafobul = 'ch';
            $tovgflnc = 'ch';
            ${'GLOBALS'}['qtfoiykyww'] = 'newurl';
            ${'GLOBALS'}['prwoznwyrt'] = 'code';
            ${${'GLOBALS'}['qtfoiykyww']} = curl_getinfo(${$rcaafobul}, CURLINFO_EFFECTIVE_URL);
            ${$aducpzcuvfu} = curl_copy_handle(${$tovgflnc});
            $nndygvd = 'newurl';
            curl_setopt(${${'GLOBALS'}['bcqhejq']}, CURLOPT_HEADER, true);
            curl_setopt(${${'GLOBALS'}['jponwvyyl']}, CURLOPT_NOBODY, true);
            curl_setopt(${$tqckhjmntcr}, CURLOPT_FORBID_REUSE, false);
            curl_setopt(${${'GLOBALS'}['jponwvyyl']}, CURLOPT_RETURNTRANSFER, true);
            do {
                ${'GLOBALS'}['iqmifirdcdo'] = 'newurl';
                $wysxrvbabar = 'rch';
                curl_setopt(${${'GLOBALS'}['jponwvyyl']}, CURLOPT_URL, ${${'GLOBALS'}['iqmifirdcdo']});
                ${${'GLOBALS'}['vvqxewnmy']} = curl_exec(${$wysxrvbabar});
                ${'GLOBALS'}['ojgjoas'] = 'rch';
                if (curl_errno(${${'GLOBALS'}['ojgjoas']})) {
                    ${'GLOBALS'}['oheucpsjswdx'] = 'code';
                    ${${'GLOBALS'}['oheucpsjswdx']} = 0;
                } else {
                    $trufqgxsz = 'rch';
                    ${${'GLOBALS'}['pjquhttw']} = curl_getinfo(${$trufqgxsz}, CURLINFO_HTTP_CODE);
                    $lnurqpihum = 'code';
                    if (${${'GLOBALS'}['pjquhttw']} == 301 || ${$lnurqpihum} == 302) {
                        ${'GLOBALS'}['dmfsxaevien'] = 'matches';
                        ${'GLOBALS'}['cquenjdapn'] = 'header';
                        ${'GLOBALS'}['trbhel'] = 'matches';
                        preg_match('/Location:(.*?)\\n/', ${${'GLOBALS'}['cquenjdapn']}, ${${'GLOBALS'}['dmfsxaevien']});
                        ${${'GLOBALS'}['ultqdi']} = trim(array_pop(${${'GLOBALS'}['trbhel']}));
                    } else {
                        ${${'GLOBALS'}['pjquhttw']} = 0;
                    }
                }
            } while (${${'GLOBALS'}['prwoznwyrt']} && --${${'GLOBALS'}['flqjref']});
            curl_close(${${'GLOBALS'}['jponwvyyl']});
            if (!${${'GLOBALS'}['flqjref']}) {
                if (${${'GLOBALS'}['vtdocc']} === null) {
                    trigger_error('Too many redirects. When following redirects, libcurl hit the maximum amount.', E_USER_WARNING);
                } else {
                    $mnilikkmvry = 'maxredirect';
                    ${$mnilikkmvry} = 0;
                }
                return false;
            }
            curl_setopt(${${'GLOBALS'}['welkvffrk']}, CURLOPT_URL, ${$nndygvd});
        }
    }
    return curl_exec(${$kufovqrgzxb});
}
function file_get_html($url, $target_charset = DEFAULT_TARGET_CHARSET, $method = 0, $useProxy = 0, $hideIP = 0, $proxy = null, $use_include_path = false, $context = null, $offset = -1, $maxLen = -1, $lowercase = true, $forceTagsClosed = true, $stripRN = true, $defaultBRText = DEFAULT_BR_TEXT, $defaultSpanText = DEFAULT_SPAN_TEXT)
{
    ${'GLOBALS'}['ehxpgsof'] = 'contents';
    ${'GLOBALS'}['wgglmoksw'] = 'stripRN';
    $owkmnysn = 'dom';
    $cgeywzewb = 'target_charset';
    ${$owkmnysn} = new simple_html_dom(null, ${${'GLOBALS'}['srnzjhhou']}, ${${'GLOBALS'}['cxefggrdq']}, ${$cgeywzewb}, ${${'GLOBALS'}['wgglmoksw']}, ${${'GLOBALS'}['xgslhlqthsr']}, ${${'GLOBALS'}['kjdlmahobpl']});
    if (${${'GLOBALS'}['ximxtrbesm']} == 0) {
        ${'GLOBALS'}['vnlgjcrokir'] = 'hideIP';
        $iwqhdefmh = 'contents';
        ${$iwqhdefmh} = curl_get_contents(${${'GLOBALS'}['vnugmpqtyg']}, ${${'GLOBALS'}['yviqqwtvrpu']}, ${${'GLOBALS'}['jnjrlqgm']}, ${${'GLOBALS'}['vnlgjcrokir']});
    } else {
        ${'GLOBALS'}['xcrhsihy'] = 'url';
        $jdhdhlp = 'offset';
        ${'GLOBALS'}['xnnwpdk'] = 'contents';
        ${${'GLOBALS'}['xnnwpdk']} = file_get_contents(${${'GLOBALS'}['xcrhsihy']}, ${${'GLOBALS'}['gjeqmmv']}, ${${'GLOBALS'}['wdyklotehm']}, ${$jdhdhlp});
    }
    $xmidtj = 'contents';
    ${$xmidtj} = str_replace('\\', ' ', ${${'GLOBALS'}['kzzcxehvqc']});
    if (empty(${${'GLOBALS'}['kzzcxehvqc']}) || strlen(${${'GLOBALS'}['kzzcxehvqc']}) > MAX_FILE_SIZE) {
        return false;
    }
    $dom->load(${${'GLOBALS'}['ehxpgsof']}, ${${'GLOBALS'}['srnzjhhou']}, ${${'GLOBALS'}['recbduhgh']});
    return ${${'GLOBALS'}['oxftvuqwjtr']};
}
function str_get_html($str, $lowercase = true, $forceTagsClosed = true, $target_charset = DEFAULT_TARGET_CHARSET, $stripRN = true, $defaultBRText = DEFAULT_BR_TEXT, $defaultSpanText = DEFAULT_SPAN_TEXT)
{
    ${'GLOBALS'}['gssdivqm'] = 'forceTagsClosed';
    ${'GLOBALS'}['bewxxnmtgdo'] = 'defaultSpanText';
    $igulepqqcy = 'dom';
    ${'GLOBALS'}['fwcfqo'] = 'dom';
    $vnlqdmu = 'stripRN';
    ${'GLOBALS'}['wdobsnyw'] = 'target_charset';
    ${'GLOBALS'}['oomjzlmr'] = 'lowercase';
    ${'GLOBALS'}['ktqjgcekgx'] = 'lowercase';
    ${$igulepqqcy} = new simple_html_dom(null, ${${'GLOBALS'}['ktqjgcekgx']}, ${${'GLOBALS'}['gssdivqm']}, ${${'GLOBALS'}['wdobsnyw']}, ${$vnlqdmu}, ${${'GLOBALS'}['xgslhlqthsr']}, ${${'GLOBALS'}['bewxxnmtgdo']});
    if (empty(${${'GLOBALS'}['fgvupcichziw']}) || strlen(${${'GLOBALS'}['fgvupcichziw']}) > MAX_FILE_SIZE) {
        $dom->clear();
        return false;
    }
    $dom->load(${${'GLOBALS'}['fgvupcichziw']}, ${${'GLOBALS'}['oomjzlmr']}, ${${'GLOBALS'}['recbduhgh']});
    return ${${'GLOBALS'}['fwcfqo']};
}
function dump_html_tree($node, $show_attr = true, $deep = 0)
{
    ${'GLOBALS'}['eqiavv'] = 'node';
    $node->dump(${${'GLOBALS'}['eqiavv']});
}
class simple_html_dom_node
{
    public $nodetype = HDOM_TYPE_TEXT;
    public $tag = 'text';
    public $attr = array();
    public $children = array();
    public $nodes = array();
    public $parent = null;
    public $_ = array();
    public $tag_start = 0;
    private $dom = null;
    public function __construct($dom)
    {
        ${'GLOBALS'}['cizrdtgcmio'] = 'dom';
        $this->dom = ${${'GLOBALS'}['cizrdtgcmio']};
        $dom->nodes[] = $this;
    }
    public function __destruct()
    {
        $this->clear();
    }
    public function __toString()
    {
        return $this->outertext();
    }
    public function clear()
    {
        $this->dom = null;
        $this->nodes = null;
        $this->parent = null;
        $this->children = null;
    }
    public function dump($show_attr = true, $deep = 0)
    {
        ${'GLOBALS'}['pozkig'] = 'show_attr';
        ${${'GLOBALS'}['upttvsxr']} = str_repeat('    ', ${${'GLOBALS'}['jdkfqvbnh']});
        echo ${${'GLOBALS'}['upttvsxr']} . $this->tag;
        if (${${'GLOBALS'}['pozkig']} && count($this->attr) > 0) {
            $afpmxsbtlets = 'k';
            $uoxnnofh = 'v';
            echo '(';
            foreach ($this->attr as ${$afpmxsbtlets} => ${$uoxnnofh}) {
                echo ("[{$k}]=>\"" . $this->{${${'GLOBALS'}['vbfqlfs']}}) . '", ';
            }
            echo ')';
        }
        echo '
';
        if ($this->nodes) {
            ${'GLOBALS'}['lwvyulb'] = 'c';
            foreach ($this->nodes as ${${'GLOBALS'}['lwvyulb']}) {
                $c->dump(${${'GLOBALS'}['qrcnrizhlhyz']}, ${${'GLOBALS'}['jdkfqvbnh']} + 1);
            }
        }
    }
    public function dump_node($echo = true)
    {
        ${${'GLOBALS'}['rvhdyfwt']} = $this->tag;
        if (count($this->attr) > 0) {
            ${'GLOBALS'}['bybepdgbd'] = 'string';
            $hgstshsb = 'string';
            ${'GLOBALS'}['wdrwnthsn'] = 'k';
            ${${'GLOBALS'}['bybepdgbd']} .= '(';
            foreach ($this->attr as ${${'GLOBALS'}['wdrwnthsn']} => ${${'GLOBALS'}['xkxdeg']}) {
                ${'GLOBALS'}['zmrnaqlqcyg'] = 'string';
                ${'GLOBALS'}['txyoeluidbh'] = 'k';
                ${${'GLOBALS'}['zmrnaqlqcyg']} .= ("[{$k}]=>\"" . $this->{${${'GLOBALS'}['txyoeluidbh']}}) . '", ';
            }
            ${$hgstshsb} .= ')';
        }
        if (count($this->_) > 0) {
            ${'GLOBALS'}['reennyhcpyvn'] = 'k';
            ${${'GLOBALS'}['rvhdyfwt']} .= ' $_ (';
            foreach ($this->_ as ${${'GLOBALS'}['reennyhcpyvn']} => ${${'GLOBALS'}['xkxdeg']}) {
                ${'GLOBALS'}['gjemwxwdh'] = 'v';
                if (is_array(${${'GLOBALS'}['gjemwxwdh']})) {
                    $twwknmh = 'k2';
                    ${'GLOBALS'}['ynbvtwgv'] = 'string';
                    ${${'GLOBALS'}['ynbvtwgv']} .= "[{$k}]=>(";
                    foreach (${${'GLOBALS'}['xkxdeg']} as ${$twwknmh} => ${${'GLOBALS'}['jgzstkqem']}) {
                        ${${'GLOBALS'}['rvhdyfwt']} .= ("[{$k2}]=>\"" . ${${'GLOBALS'}['jgzstkqem']}) . '", ';
                    }
                    ${${'GLOBALS'}['rvhdyfwt']} .= ')';
                } else {
                    ${'GLOBALS'}['iwogmjpu'] = 'v';
                    ${${'GLOBALS'}['rvhdyfwt']} .= ("[{$k}]=>\"" . ${${'GLOBALS'}['iwogmjpu']}) . '", ';
                }
            }
            ${${'GLOBALS'}['rvhdyfwt']} .= ')';
        }
        $gljikofcf = 'string';
        if (isset($this->text)) {
            $djqsufz = 'string';
            ${$djqsufz} .= (' text: (' . $this->text) . ')';
        }
        ${'GLOBALS'}['bwkogwitcxy'] = 'string';
        ${'GLOBALS'}['auixmfpiqi'] = 'echo';
        $sgrroyya = 'string';
        ${$sgrroyya} .= ' HDOM_INNER_INFO: \'';
        if (isset($node->_[HDOM_INFO_INNER])) {
            ${${'GLOBALS'}['rvhdyfwt']} .= $node->_[HDOM_INFO_INNER] . '\'';
        } else {
            ${${'GLOBALS'}['rvhdyfwt']} .= ' NULL ';
        }
        ${${'GLOBALS'}['bwkogwitcxy']} .= ' children: ' . count($this->children);
        ${${'GLOBALS'}['rvhdyfwt']} .= ' nodes: ' . count($this->nodes);
        ${${'GLOBALS'}['rvhdyfwt']} .= ' tag_start: ' . $this->tag_start;
        ${$gljikofcf} .= '
';
        if (${${'GLOBALS'}['auixmfpiqi']}) {
            echo ${${'GLOBALS'}['rvhdyfwt']};
            return;
        } else {
            ${'GLOBALS'}['erubjqsy'] = 'string';
            return ${${'GLOBALS'}['erubjqsy']};
        }
    }
    public function parent($parent = null)
    {
        $nppakdzqo = 'parent';
        if (${$nppakdzqo} !== null) {
            $cbsdbiukbw = 'parent';
            $this->parent = ${$cbsdbiukbw};
            $this->parent->nodes[] = $this;
            $this->parent->children[] = $this;
        }
        return $this->parent;
    }
    public function has_child()
    {
        return !empty($this->children);
    }
    public function children($idx = -1)
    {
        ${'GLOBALS'}['pvwxvehtr'] = 'idx';
        ${'GLOBALS'}['qlivomfy'] = 'idx';
        if (${${'GLOBALS'}['qlivomfy']} === -1) {
            return $this->children;
        }
        if (isset($this->children[${${'GLOBALS'}['tcpuoctul']}])) {
            return $this->children[${${'GLOBALS'}['pvwxvehtr']}];
        }
        return null;
    }
    public function first_child()
    {
        if (count($this->children) > 0) {
            return $this->children[0];
        }
        return null;
    }
    public function last_child()
    {
        if ((${${'GLOBALS'}['hkawtqnihpru']} = count($this->children)) > 0) {
            return $this->children[${${'GLOBALS'}['hkawtqnihpru']} - 1];
        }
        return null;
    }
    public function next_sibling()
    {
        $whrfgypbljgl = 'count';
        $tjxlcnumfo = 'idx';
        ${'GLOBALS'}['nnqtgxgel'] = 'idx';
        if ($this->parent === null) {
            return null;
        }
        ${${'GLOBALS'}['tcpuoctul']} = 0;
        ${$whrfgypbljgl} = count($this->parent->children);
        while (${${'GLOBALS'}['nnqtgxgel']} < ${${'GLOBALS'}['hkawtqnihpru']} && $this !== $this->parent->children[${${'GLOBALS'}['tcpuoctul']}]) {
            ++${${'GLOBALS'}['tcpuoctul']};
        }
        if (++${${'GLOBALS'}['tcpuoctul']} >= ${${'GLOBALS'}['hkawtqnihpru']}) {
            return null;
        }
        return $this->parent->children[${$tjxlcnumfo}];
    }
    public function prev_sibling()
    {
        ${'GLOBALS'}['npceyasnym'] = 'idx';
        ${'GLOBALS'}['uhpwwhmm'] = 'idx';
        ${'GLOBALS'}['yrsbcbp'] = 'idx';
        $cjyhnrw = 'count';
        if ($this->parent === null) {
            return null;
        }
        $ljgvjqncyvm = 'idx';
        ${${'GLOBALS'}['tcpuoctul']} = 0;
        ${$cjyhnrw} = count($this->parent->children);
        while (${${'GLOBALS'}['yrsbcbp']} < ${${'GLOBALS'}['hkawtqnihpru']} && $this !== $this->parent->children[${${'GLOBALS'}['npceyasnym']}]) {
            ++${${'GLOBALS'}['tcpuoctul']};
        }
        if (--${${'GLOBALS'}['uhpwwhmm']} < 0) {
            return null;
        }
        return $this->parent->children[${$ljgvjqncyvm}];
    }
    public function find_ancestor_tag($tag)
    {
        $yjmlxfayc = 'returnDom';
        $wwlvhxejke = 'debugObject';
        global $debugObject;
        if (is_object(${$wwlvhxejke})) {
            $debugObject->debugLogEntry(1);
        }
        ${${'GLOBALS'}['ewhenajqf']} = $this;
        while (!is_null(${$yjmlxfayc})) {
            ${'GLOBALS'}['jcwstd'] = 'debugObject';
            if (is_object(${${'GLOBALS'}['jcwstd']})) {
                $debugObject->debugLog(2, 'Current tag is: ' . $returnDom->tag);
            }
            if ($returnDom->tag == ${${'GLOBALS'}['wnewosaggmy']}) {
                break;
            }
            ${${'GLOBALS'}['ewhenajqf']} = $returnDom->parent;
        }
        return ${${'GLOBALS'}['ewhenajqf']};
    }
    public function innertext()
    {
        ${'GLOBALS'}['yuhoglv'] = 'n';
        if (isset($this->_[HDOM_INFO_INNER])) {
            return $this->_[HDOM_INFO_INNER];
        }
        ${'GLOBALS'}['pwkcngqvngn'] = 'ret';
        if (isset($this->_[HDOM_INFO_TEXT])) {
            return $this->dom->restore_noise($this->_[HDOM_INFO_TEXT]);
        }
        ${${'GLOBALS'}['qzxevewqkf']} = '';
        ${'GLOBALS'}['mqyvokqntpzb'] = 'ret';
        foreach ($this->nodes as ${${'GLOBALS'}['yuhoglv']}) {
            ${${'GLOBALS'}['mqyvokqntpzb']} .= $n->outertext();
        }
        return ${${'GLOBALS'}['pwkcngqvngn']};
    }
    public function outertext()
    {
        ${'GLOBALS'}['hpnunpnhb'] = 'debugObject';
        global $debugObject;
        if (is_object(${${'GLOBALS'}['hpnunpnhb']})) {
            ${${'GLOBALS'}['kueflpmp']} = '';
            if ($this->tag == 'text') {
                if (!empty($this->text)) {
                    ${'GLOBALS'}['vepjpgce'] = 'text';
                    ${${'GLOBALS'}['vepjpgce']} = ' with text: ' . $this->text;
                }
            }
            $debugObject->debugLog(1, ('Innertext of tag: ' . $this->tag) . ${${'GLOBALS'}['kueflpmp']});
        }
        if ($this->tag === 'root') {
            return $this->innertext();
        }
        if ($this->dom && $this->dom->callback !== null) {
            call_user_func_array($this->dom->callback, array($this));
        }
        if (isset($this->_[HDOM_INFO_OUTER])) {
            return $this->_[HDOM_INFO_OUTER];
        }
        if (isset($this->_[HDOM_INFO_TEXT])) {
            return $this->dom->restore_noise($this->_[HDOM_INFO_TEXT]);
        }
        if ($this->dom && $this->dom->nodes[$this->_[HDOM_INFO_BEGIN]]) {
            ${'GLOBALS'}['aakohfbetj'] = 'ret';
            ${${'GLOBALS'}['aakohfbetj']} = $this->dom->nodes[$this->_[HDOM_INFO_BEGIN]]->makeup();
        } else {
            ${'GLOBALS'}['ydcynej'] = 'ret';
            ${${'GLOBALS'}['ydcynej']} = '';
        }
        if (isset($this->_[HDOM_INFO_INNER])) {
            if ($this->tag != 'br') {
                ${${'GLOBALS'}['qzxevewqkf']} .= $this->_[HDOM_INFO_INNER];
            }
        } else {
            if ($this->nodes) {
                ${'GLOBALS'}['ropfgjjkgxcb'] = 'n';
                foreach ($this->nodes as ${${'GLOBALS'}['ropfgjjkgxcb']}) {
                    ${${'GLOBALS'}['qzxevewqkf']} .= $this->convert_text($n->outertext());
                }
            }
        }
        if (isset($this->_[HDOM_INFO_END]) && $this->_[HDOM_INFO_END] != 0) {
            ${${'GLOBALS'}['qzxevewqkf']} .= ('</' . $this->tag) . '>';
        }
        return ${${'GLOBALS'}['qzxevewqkf']};
    }
    public function text()
    {
        if (isset($this->_[HDOM_INFO_INNER])) {
            return $this->_[HDOM_INFO_INNER];
        }
        switch ($this->nodetype) {
        case HDOM_TYPE_TEXT:
            return $this->dom->restore_noise($this->_[HDOM_INFO_TEXT]);
        case HDOM_TYPE_COMMENT:
            return '';
        case HDOM_TYPE_UNKNOWN:
            return '';
        }
        $pnspoukccnw = 'ret';
        if (strcasecmp($this->tag, 'script') === 0) {
            return '';
        }
        if (strcasecmp($this->tag, 'style') === 0) {
            return '';
        }
        ${$pnspoukccnw} = '';
        $ghddroezno = 'ret';
        if (!is_null($this->nodes)) {
            $hisbkziwbhd = 'n';
            foreach ($this->nodes as ${$hisbkziwbhd}) {
                ${${'GLOBALS'}['qzxevewqkf']} .= $this->convert_text($n->text());
            }
            if ($this->tag == 'span') {
                ${${'GLOBALS'}['qzxevewqkf']} .= $this->dom->default_span_text;
            }
        }
        return ${$ghddroezno};
    }
    public function xmltext()
    {
        $gxhngsewrfp = 'ret';
        ${'GLOBALS'}['ywfwtt'] = 'ret';
        ${${'GLOBALS'}['ywfwtt']} = $this->innertext();
        $mlnvpbpsftq = 'ret';
        ${'GLOBALS'}['rrnytvtkuyl'] = 'ret';
        ${$mlnvpbpsftq} = str_ireplace('<![CDATA[', '', ${${'GLOBALS'}['qzxevewqkf']});
        ${'GLOBALS'}['ltcqhnms'] = 'ret';
        ${${'GLOBALS'}['rrnytvtkuyl']} = str_replace(']]>', '', ${${'GLOBALS'}['ltcqhnms']});
        return ${$gxhngsewrfp};
    }
    public function makeup()
    {
        ${'GLOBALS'}['lhldsqvbxv'] = 'ret';
        ${'GLOBALS'}['hutkowwchb'] = 'ret';
        if (isset($this->_[HDOM_INFO_TEXT])) {
            return $this->dom->restore_noise($this->_[HDOM_INFO_TEXT]);
        }
        ${${'GLOBALS'}['hutkowwchb']} = '<' . $this->tag;
        ${'GLOBALS'}['vocvdwyhcbu'] = 'ret';
        ${'GLOBALS'}['mwycljnllqr'] = 'key';
        ${${'GLOBALS'}['iysvwodqrf']} = -1;
        foreach ($this->attr as ${${'GLOBALS'}['mwycljnllqr']} => ${${'GLOBALS'}['xeqldqrfeyg']}) {
            ${'GLOBALS'}['xuchifgp'] = 'val';
            $ttavqeacjw = 'ret';
            $wpvloesl = 'i';
            ${'GLOBALS'}['peeovjcvlvtb'] = 'val';
            ++${${'GLOBALS'}['iysvwodqrf']};
            ${'GLOBALS'}['mkdobzhvl'] = 'val';
            if (${${'GLOBALS'}['xuchifgp']} === null || ${${'GLOBALS'}['peeovjcvlvtb']} === false) {
                continue;
            }
            ${$ttavqeacjw} .= $this->_[HDOM_INFO_SPACE][${$wpvloesl}][0];
            if (${${'GLOBALS'}['mkdobzhvl']} === true) {
                ${${'GLOBALS'}['qzxevewqkf']} .= ${${'GLOBALS'}['gjejvzeg']};
            } else {
                ${'GLOBALS'}['rahuqcwhh'] = 'quote';
                $bkglhdv = 'i';
                ${'GLOBALS'}['gipdskejlcel'] = 'quote';
                ${'GLOBALS'}['vihffjl'] = 'ret';
                ${'GLOBALS'}['tvhfxnni'] = 'quote';
                ${'GLOBALS'}['tobensgvgtcy'] = 'val';
                ${'GLOBALS'}['qroffbk'] = 'i';
                ${'GLOBALS'}['tpkueyredus'] = 'quote';
                ${'GLOBALS'}['cbjprhwyemo'] = 'key';
                switch ($this->_[HDOM_INFO_QUOTE][${${'GLOBALS'}['qroffbk']}]) {
                case HDOM_QUOTE_DOUBLE:
                    ${${'GLOBALS'}['tpkueyredus']} = '"';
                    break;
                case HDOM_QUOTE_SINGLE:
                    ${${'GLOBALS'}['tvhfxnni']} = '\'';
                    break;
                default:
                    ${${'GLOBALS'}['rahuqcwhh']} = '';
                }
                ${${'GLOBALS'}['vihffjl']} .= (((((${${'GLOBALS'}['cbjprhwyemo']} . $this->_[HDOM_INFO_SPACE][${$bkglhdv}][1]) . '=') . $this->_[HDOM_INFO_SPACE][${${'GLOBALS'}['iysvwodqrf']}][2]) . ${${'GLOBALS'}['gipdskejlcel']}) . ${${'GLOBALS'}['tobensgvgtcy']}) . ${${'GLOBALS'}['xhqjiiwiiwgx']};
            }
        }
        ${'GLOBALS'}['vdglvjnctqje'] = 'ret';
        ${${'GLOBALS'}['vdglvjnctqje']} = $this->dom->restore_noise(${${'GLOBALS'}['lhldsqvbxv']});
        return (${${'GLOBALS'}['vocvdwyhcbu']} . $this->_[HDOM_INFO_ENDSPACE]) . '>';
    }
    public function find($selector, $idx = null, $lowercase = false)
    {
        $fwebnpp = 'idx';
        $piuwmwqoko = 'k';
        $tksuvxpje = 'c';
        $kpzvcnoud = 'count';
        $qagimmowy = 'selector';
        ${'GLOBALS'}['eshsemve'] = 'found_keys';
        $uxexxoqyf = 'idx';
        $xikykiufgy = 'c';
        ${${'GLOBALS'}['lnyifwi']} = $this->parse_selector(${$qagimmowy});
        $ttnavpnsy = 'count';
        ${'GLOBALS'}['guhrmozuvl'] = 'found_keys';
        if ((${$kpzvcnoud} = count(${${'GLOBALS'}['lnyifwi']})) === 0) {
            return array();
        }
        $zjqeuynye = 'idx';
        ${'GLOBALS'}['ylyude'] = 'found';
        ${'GLOBALS'}['dxfdjtde'] = 'k';
        $rmkjsybwpiw = 'found_keys';
        ${${'GLOBALS'}['eshsemve']} = array();
        for (${$xikykiufgy} = 0; ${${'GLOBALS'}['gldshxvohkl']} < ${$ttnavpnsy}; ++${$tksuvxpje}) {
            ${'GLOBALS'}['uqcgagf'] = 'head';
            $rpfvmsvlydfu = 'head';
            ${'GLOBALS'}['ibwpuzbulqm'] = 'v';
            ${'GLOBALS'}['tjdxlrf'] = 'c';
            if ((${${'GLOBALS'}['qbbfwon']} = count(${${'GLOBALS'}['lnyifwi']}[${${'GLOBALS'}['tjdxlrf']}])) === 0) {
                return array();
            }
            ${'GLOBALS'}['zhcznwt'] = 'l';
            if (!isset($this->_[HDOM_INFO_BEGIN])) {
                return array();
            }
            $kdxyzecsh = 'l';
            ${${'GLOBALS'}['uqcgagf']} = array($this->_[HDOM_INFO_BEGIN] => 1);
            for (${${'GLOBALS'}['zhcznwt']} = 0; ${${'GLOBALS'}['boqfcdtlfdqn']} < ${${'GLOBALS'}['qbbfwon']}; ++${$kdxyzecsh}) {
                ${'GLOBALS'}['utgcuvno'] = 'ret';
                ${'GLOBALS'}['pfmmihtvsh'] = 'head';
                ${'GLOBALS'}['tfkkggp'] = 'v';
                $upsjsegjvm = 'head';
                ${${'GLOBALS'}['utgcuvno']} = array();
                foreach (${$upsjsegjvm} as ${${'GLOBALS'}['vbfqlfs']} => ${${'GLOBALS'}['tfkkggp']}) {
                    $xeeqwqcpdic = 'k';
                    $nmvtsfaqnpvx = 'k';
                    ${${'GLOBALS'}['ifpupts']} = ${$nmvtsfaqnpvx} === -1 ? $this->dom->root : $this->dom->nodes[${$xeeqwqcpdic}];
                    ${'GLOBALS'}['mjzuteiajy'] = 'ret';
                    $n->seek(${${'GLOBALS'}['lnyifwi']}[${${'GLOBALS'}['gldshxvohkl']}][${${'GLOBALS'}['boqfcdtlfdqn']}], ${${'GLOBALS'}['mjzuteiajy']}, ${${'GLOBALS'}['srnzjhhou']});
                }
                ${${'GLOBALS'}['pfmmihtvsh']} = ${${'GLOBALS'}['qzxevewqkf']};
            }
            foreach (${$rpfvmsvlydfu} as ${${'GLOBALS'}['vbfqlfs']} => ${${'GLOBALS'}['ibwpuzbulqm']}) {
                ${'GLOBALS'}['eglnsumwskb'] = 'found_keys';
                ${'GLOBALS'}['oqkdnk'] = 'k';
                $gskwemfpbe = 'found_keys';
                if (!isset(${${'GLOBALS'}['eglnsumwskb']}[${${'GLOBALS'}['vbfqlfs']}])) {
                    ${$gskwemfpbe}[${${'GLOBALS'}['oqkdnk']}] = 1;
                }
            }
        }
        ksort(${$rmkjsybwpiw});
        ${${'GLOBALS'}['brfhlvhsfs']} = array();
        foreach (${${'GLOBALS'}['guhrmozuvl']} as ${${'GLOBALS'}['dxfdjtde']} => ${${'GLOBALS'}['xkxdeg']}) {
            ${${'GLOBALS'}['brfhlvhsfs']}[] = $this->dom->nodes[${$piuwmwqoko}];
        }
        if (is_null(${$uxexxoqyf})) {
            return ${${'GLOBALS'}['brfhlvhsfs']};
        } else {
            if (${$fwebnpp} < 0) {
                ${${'GLOBALS'}['tcpuoctul']} = count(${${'GLOBALS'}['brfhlvhsfs']}) + ${${'GLOBALS'}['tcpuoctul']};
            }
        }
        return isset(${${'GLOBALS'}['brfhlvhsfs']}[${${'GLOBALS'}['tcpuoctul']}]) ? ${${'GLOBALS'}['ylyude']}[${$zjqeuynye}] : null;
    }
    protected function seek($selector, &$ret, $lowercase = false)
    {
        $ttckvclm = 'tag';
        ${'GLOBALS'}['nltpvbc'] = 'debugObject';
        $kgxdkjc = 'end';
        $cwuyvqixqr = 'no_key';
        ${'GLOBALS'}['tiqedunr'] = 'tag';
        global $debugObject;
        $esrlkrravdg = 'val';
        if (is_object(${${'GLOBALS'}['nltpvbc']})) {
            $debugObject->debugLogEntry(1);
        }
        ${'GLOBALS'}['hzbchstesv'] = 'i';
        list(${$ttckvclm}, ${${'GLOBALS'}['gjejvzeg']}, ${$esrlkrravdg}, ${${'GLOBALS'}['itgiqrn']}, ${$cwuyvqixqr}) = ${${'GLOBALS'}['sckutuml']};
        $nixrrlgyuun = 'i';
        if ((${${'GLOBALS'}['tiqedunr']} && ${${'GLOBALS'}['gjejvzeg']}) && is_numeric(${${'GLOBALS'}['gjejvzeg']})) {
            ${${'GLOBALS'}['hkawtqnihpru']} = 0;
            foreach ($this->children as ${${'GLOBALS'}['gldshxvohkl']}) {
                if (${${'GLOBALS'}['wnewosaggmy']} === '*' || ${${'GLOBALS'}['wnewosaggmy']} === $c->tag) {
                    $iyqbgtm = 'key';
                    ${'GLOBALS'}['nsvvanqx'] = 'count';
                    if (++${${'GLOBALS'}['nsvvanqx']} == ${$iyqbgtm}) {
                        ${${'GLOBALS'}['qzxevewqkf']}[$c->_[HDOM_INFO_BEGIN]] = 1;
                        return;
                    }
                }
            }
            return;
        }
        ${$kgxdkjc} = !empty($this->_[HDOM_INFO_END]) ? $this->_[HDOM_INFO_END] : 0;
        ${'GLOBALS'}['vegjhjflgb'] = 'debugObject';
        if (${${'GLOBALS'}['pncwkvhvp']} == 0) {
            $zygeunfxrq = 'parent';
            $qvlnyhtexvqr = 'end';
            ${'GLOBALS'}['eygynwpbze'] = 'parent';
            ${${'GLOBALS'}['eygynwpbze']} = $this->parent;
            while (!isset($parent->_[HDOM_INFO_END]) && ${$zygeunfxrq} !== null) {
                ${'GLOBALS'}['hivffdhjpomk'] = 'end';
                ${'GLOBALS'}['rfqiwxeub'] = 'parent';
                ${${'GLOBALS'}['hivffdhjpomk']} -= 1;
                ${${'GLOBALS'}['rfqiwxeub']} = $parent->parent;
            }
            ${$qvlnyhtexvqr} += $parent->_[HDOM_INFO_END];
        }
        for (${${'GLOBALS'}['hzbchstesv']} = $this->_[HDOM_INFO_BEGIN] + 1; ${$nixrrlgyuun} < ${${'GLOBALS'}['pncwkvhvp']}; ++${${'GLOBALS'}['iysvwodqrf']}) {
            $hocgwuihw = 'tag';
            $bxgxdsipoze = 'val';
            ${${'GLOBALS'}['lpuxeaf']} = $this->dom->nodes[${${'GLOBALS'}['iysvwodqrf']}];
            $bekxshxv = 'tag';
            ${'GLOBALS'}['dsszluuy'] = 'i';
            ${'GLOBALS'}['mwqlzdmj'] = 'pass';
            ${'GLOBALS'}['sealjjruq'] = 'tag';
            ${'GLOBALS'}['pifywnij'] = 'pass';
            ${${'GLOBALS'}['pifywnij']} = true;
            if (${${'GLOBALS'}['sealjjruq']} === '*' && !${${'GLOBALS'}['gjejvzeg']}) {
                ${'GLOBALS'}['krtylkp'] = 'i';
                $tkpgcqgc = 'ret';
                ${'GLOBALS'}['udugylkweb'] = 'node';
                if (in_array(${${'GLOBALS'}['udugylkweb']}, $this->children, true)) {
                    ${$tkpgcqgc}[${${'GLOBALS'}['krtylkp']}] = 1;
                }
                continue;
            }
            if ((${${'GLOBALS'}['wnewosaggmy']} && ${$hocgwuihw} != $node->tag) && ${$bekxshxv} !== '*') {
                ${${'GLOBALS'}['zynijfsg']} = false;
            }
            if (${${'GLOBALS'}['zynijfsg']} && ${${'GLOBALS'}['gjejvzeg']}) {
                ${'GLOBALS'}['rpzdmebaupw'] = 'no_key';
                if (${${'GLOBALS'}['rpzdmebaupw']}) {
                    if (isset($node->attr[${${'GLOBALS'}['gjejvzeg']}])) {
                        ${${'GLOBALS'}['zynijfsg']} = false;
                    }
                } else {
                    $owxewhvmlsuo = 'key';
                    $rluptl = 'pass';
                    if (${$owxewhvmlsuo} != 'plaintext' && !isset($node->attr[${${'GLOBALS'}['gjejvzeg']}])) {
                        ${$rluptl} = false;
                    }
                }
            }
            ${'GLOBALS'}['qkgksrka'] = 'pass';
            if (((${${'GLOBALS'}['mwqlzdmj']} && ${${'GLOBALS'}['gjejvzeg']}) && ${${'GLOBALS'}['xeqldqrfeyg']}) && ${$bxgxdsipoze} !== '*') {
                ${'GLOBALS'}['lnohunobet'] = 'key';
                ${'GLOBALS'}['ujvnydwev'] = 'check';
                if (${${'GLOBALS'}['lnohunobet']} == 'plaintext') {
                    $bqfowpqngd = 'nodeKeyValue';
                    ${$bqfowpqngd} = $node->text();
                } else {
                    ${'GLOBALS'}['ihhtaxeqen'] = 'nodeKeyValue';
                    ${'GLOBALS'}['vcelpducz'] = 'key';
                    ${${'GLOBALS'}['ihhtaxeqen']} = $node->attr[${${'GLOBALS'}['vcelpducz']}];
                }
                $ttxufmmokb = 'key';
                if (is_object(${${'GLOBALS'}['fotqnjvm']})) {
                    ${'GLOBALS'}['qwesmlki'] = 'key';
                    ${'GLOBALS'}['qffrxqld'] = 'exp';
                    $yctbznknqj = 'val';
                    $debugObject->debugLog(2, (((((('testing node: ' . $node->tag) . ' for attribute: ') . ${${'GLOBALS'}['qwesmlki']}) . ${${'GLOBALS'}['qffrxqld']}) . ${$yctbznknqj}) . ' where nodes value is: ') . ${${'GLOBALS'}['nomwvpfn']});
                }
                if (${${'GLOBALS'}['srnzjhhou']}) {
                    ${'GLOBALS'}['ohibdd'] = 'check';
                    ${'GLOBALS'}['ieduymxdugc'] = 'val';
                    ${${'GLOBALS'}['ohibdd']} = $this->match(${${'GLOBALS'}['itgiqrn']}, strtolower(${${'GLOBALS'}['ieduymxdugc']}), strtolower(${${'GLOBALS'}['nomwvpfn']}));
                } else {
                    ${'GLOBALS'}['tgohkr'] = 'exp';
                    ${${'GLOBALS'}['iinkwinkf']} = $this->match(${${'GLOBALS'}['tgohkr']}, ${${'GLOBALS'}['xeqldqrfeyg']}, ${${'GLOBALS'}['nomwvpfn']});
                }
                if (is_object(${${'GLOBALS'}['fotqnjvm']})) {
                    $debugObject->debugLog(2, 'after match: ' . (${${'GLOBALS'}['iinkwinkf']} ? 'true' : 'false'));
                }
                if (!${${'GLOBALS'}['iinkwinkf']} && strcasecmp(${$ttxufmmokb}, 'class') === 0) {
                    $tjtqenshkx = 'key';
                    ${'GLOBALS'}['gttacdvdiupe'] = 'k';
                    foreach (explode(' ', $node->attr[${$tjtqenshkx}]) as ${${'GLOBALS'}['gttacdvdiupe']}) {
                        $vqhwpii = 'k';
                        if (!empty(${$vqhwpii})) {
                            if (${${'GLOBALS'}['srnzjhhou']}) {
                                ${'GLOBALS'}['pgifpnykc'] = 'exp';
                                ${${'GLOBALS'}['iinkwinkf']} = $this->match(${${'GLOBALS'}['pgifpnykc']}, strtolower(${${'GLOBALS'}['xeqldqrfeyg']}), strtolower(${${'GLOBALS'}['vbfqlfs']}));
                            } else {
                                $phtcrne = 'val';
                                $xsywpfy = 'check';
                                $uogtqyx = 'k';
                                ${$xsywpfy} = $this->match(${${'GLOBALS'}['itgiqrn']}, ${$phtcrne}, ${$uogtqyx});
                            }
                            if (${${'GLOBALS'}['iinkwinkf']}) {
                                break;
                            }
                        }
                    }
                }
                if (!${${'GLOBALS'}['ujvnydwev']}) {
                    ${${'GLOBALS'}['zynijfsg']} = false;
                }
            }
            if (${${'GLOBALS'}['qkgksrka']}) {
                ${${'GLOBALS'}['qzxevewqkf']}[${${'GLOBALS'}['dsszluuy']}] = 1;
            }
            unset(${${'GLOBALS'}['lpuxeaf']});
        }
        if (is_object(${${'GLOBALS'}['vegjhjflgb']})) {
            ${'GLOBALS'}['uapnhp'] = 'ret';
            $debugObject->debugLog(1, 'EXIT - ret: ', ${${'GLOBALS'}['uapnhp']});
        }
    }
    protected function match($exp, $pattern, $value)
    {
        $hmesimg = 'pattern';
        $jrhpmrjuvt = 'pattern';
        $veqwjnxhkj = 'pattern';
        global $debugObject;
        $qrljhenofk = 'value';
        ${'GLOBALS'}['hxnutvgf'] = 'debugObject';
        if (is_object(${${'GLOBALS'}['hxnutvgf']})) {
            $debugObject->debugLogEntry(1);
        }
        ${'GLOBALS'}['hqfrop'] = 'value';
        $yfahysh = 'value';
        switch (${${'GLOBALS'}['itgiqrn']}) {
        case '=':
            return ${$qrljhenofk} === ${${'GLOBALS'}['vnxhymnwr']};
        case '!=':
            return ${${'GLOBALS'}['sdcopkopk']} !== ${$veqwjnxhkj};
        case '^=':
            return preg_match(('/^' . preg_quote(${${'GLOBALS'}['vnxhymnwr']}, '/')) . '/', ${$yfahysh});
        case '$=':
            return preg_match(('/' . preg_quote(${${'GLOBALS'}['vnxhymnwr']}, '/')) . '$/', ${${'GLOBALS'}['hqfrop']});
        case '*=':
            if (${$hmesimg}[0] == '/') {
                $xoqjnus = 'pattern';
                $qeljngbvyeif = 'value';
                return preg_match(${$xoqjnus}, ${$qeljngbvyeif});
            }
            return preg_match(('/' . ${$jrhpmrjuvt}) . '/i', ${${'GLOBALS'}['sdcopkopk']});
        }
        return false;
    }
    protected function parse_selector($selector_string)
    {
        ${'GLOBALS'}['flcvcmo'] = 'pattern';
        $vlwvwxlnknpm = 'selectors';
        ${'GLOBALS'}['jlawokvkgdjh'] = 'result';
        $vrfwujin = 'pattern';
        ${'GLOBALS'}['edgmdwkyhqn'] = 'result';
        $njfmjcx = 'matches';
        global $debugObject;
        if (is_object(${${'GLOBALS'}['fotqnjvm']})) {
            $debugObject->debugLogEntry(1);
        }
        ${$vrfwujin} = '/([\\w-:\\*]*)(?:\\#([\\w-]+)|\\.([\\w-]+))?(?:\\[@?(!?[\\w-:]+)(?:([!*^$]?=)["\']?(.*?)["\']?)?\\])?([\\/, ]+)/is';
        ${'GLOBALS'}['gtenvajdbvb'] = 'matches';
        ${'GLOBALS'}['scymxpumlyn'] = 'result';
        preg_match_all(${${'GLOBALS'}['flcvcmo']}, trim(${${'GLOBALS'}['tprfenuscns']}) . ' ', ${$njfmjcx}, PREG_SET_ORDER);
        if (is_object(${${'GLOBALS'}['fotqnjvm']})) {
            $debugObject->debugLog(2, 'Matches Array: ', ${${'GLOBALS'}['lzakelec']});
        }
        ${${'GLOBALS'}['lnyifwi']} = array();
        ${${'GLOBALS'}['scymxpumlyn']} = array();
        foreach (${${'GLOBALS'}['gtenvajdbvb']} as ${${'GLOBALS'}['iylpswx']}) {
            ${'GLOBALS'}['newmigv'] = 'm';
            ${'GLOBALS'}['kkpsvbrg'] = 'm';
            ${'GLOBALS'}['scgvuyij'] = 'key';
            ${'GLOBALS'}['uliummqehh'] = 'm';
            ${'GLOBALS'}['gndbgcot'] = 'no_key';
            ${'GLOBALS'}['diwrwtwq'] = 'm';
            $moqsba = 'm';
            $bcfjyegemk = 'key';
            ${'GLOBALS'}['beemypncw'] = 'm';
            ${${'GLOBALS'}['beemypncw']}[0] = trim(${${'GLOBALS'}['iylpswx']}[0]);
            ${'GLOBALS'}['jhbfxs'] = 'm';
            $tajogtugvmlw = 'val';
            if ((${${'GLOBALS'}['iylpswx']}[0] === '' || ${${'GLOBALS'}['iylpswx']}[0] === '/') || ${${'GLOBALS'}['kkpsvbrg']}[0] === '//') {
                continue;
            }
            if (${$moqsba}[1] === 'tbody') {
                continue;
            }
            list(${${'GLOBALS'}['wnewosaggmy']}, ${${'GLOBALS'}['gjejvzeg']}, ${${'GLOBALS'}['xeqldqrfeyg']}, ${${'GLOBALS'}['itgiqrn']}, ${${'GLOBALS'}['gndbgcot']}) = array(${${'GLOBALS'}['iylpswx']}[1], null, null, '=', false);
            if (!empty(${${'GLOBALS'}['iylpswx']}[2])) {
                $vbfwro = 'key';
                ${$vbfwro} = 'id';
                ${${'GLOBALS'}['xeqldqrfeyg']} = ${${'GLOBALS'}['iylpswx']}[2];
            }
            if (!empty(${${'GLOBALS'}['iylpswx']}[3])) {
                ${'GLOBALS'}['ymnsaz'] = 'val';
                ${'GLOBALS'}['tsshvarbi'] = 'm';
                ${${'GLOBALS'}['gjejvzeg']} = 'class';
                ${${'GLOBALS'}['ymnsaz']} = ${${'GLOBALS'}['tsshvarbi']}[3];
            }
            if (!empty(${${'GLOBALS'}['uliummqehh']}[4])) {
                $wbobzgj = 'key';
                ${$wbobzgj} = ${${'GLOBALS'}['iylpswx']}[4];
            }
            if (!empty(${${'GLOBALS'}['diwrwtwq']}[5])) {
                ${${'GLOBALS'}['itgiqrn']} = ${${'GLOBALS'}['iylpswx']}[5];
            }
            if (!empty(${${'GLOBALS'}['jhbfxs']}[6])) {
                ${'GLOBALS'}['frxirqobhcxf'] = 'm';
                ${${'GLOBALS'}['xeqldqrfeyg']} = ${${'GLOBALS'}['frxirqobhcxf']}[6];
            }
            $jhgrvjdrgeoe = 'result';
            ${'GLOBALS'}['nnfehwjp'] = 'tag';
            if ($this->dom->lowercase) {
                ${'GLOBALS'}['qiwqsibhm'] = 'tag';
                ${${'GLOBALS'}['qiwqsibhm']} = strtolower(${${'GLOBALS'}['wnewosaggmy']});
                ${${'GLOBALS'}['gjejvzeg']} = strtolower(${${'GLOBALS'}['gjejvzeg']});
            }
            if (isset(${${'GLOBALS'}['gjejvzeg']}[0]) && ${$bcfjyegemk}[0] === '!') {
                $sftievryiqmx = 'key';
                ${${'GLOBALS'}['gjejvzeg']} = substr(${$sftievryiqmx}, 1);
                ${'GLOBALS'}['iclfkcgbjq'] = 'no_key';
                ${${'GLOBALS'}['iclfkcgbjq']} = true;
            }
            ${$jhgrvjdrgeoe}[] = array(${${'GLOBALS'}['nnfehwjp']}, ${${'GLOBALS'}['scgvuyij']}, ${$tajogtugvmlw}, ${${'GLOBALS'}['itgiqrn']}, ${${'GLOBALS'}['gxuvpvs']});
            if (trim(${${'GLOBALS'}['newmigv']}[7]) === ',') {
                $gdcbks = 'result';
                ${${'GLOBALS'}['lnyifwi']}[] = ${$gdcbks};
                ${${'GLOBALS'}['rjfoougypoye']} = array();
            }
        }
        if (count(${${'GLOBALS'}['jlawokvkgdjh']}) > 0) {
            ${$vlwvwxlnknpm}[] = ${${'GLOBALS'}['edgmdwkyhqn']};
        }
        return ${${'GLOBALS'}['lnyifwi']};
    }
    public function __get($name)
    {
        $rdpqhjhjywu = 'name';
        if (isset($this->attr[${$rdpqhjhjywu}])) {
            return $this->convert_text($this->attr[${${'GLOBALS'}['qiughdhwjl']}]);
        }
        $jtsuhnlsxmc = 'name';
        switch (${$jtsuhnlsxmc}) {
        case 'outertext':
            return $this->outertext();
        case 'innertext':
            return $this->innertext();
        case 'plaintext':
            return $this->text();
        case 'xmltext':
            return $this->xmltext();
        default:
            return array_key_exists(${${'GLOBALS'}['qiughdhwjl']}, $this->attr);
        }
    }
    public function __set($name, $value)
    {
        ${'GLOBALS'}['xfxitrwj'] = 'value';
        $gungpnw = 'value';
        $bykevzxancr = 'value';
        ${'GLOBALS'}['rnpowno'] = 'name';
        switch (${${'GLOBALS'}['qiughdhwjl']}) {
        case 'outertext':
            return $this->_[HDOM_INFO_OUTER] = ${$bykevzxancr};
        case 'innertext':
            if (isset($this->_[HDOM_INFO_TEXT])) {
                return $this->_[HDOM_INFO_TEXT] = ${$gungpnw};
            }
            return $this->_[HDOM_INFO_INNER] = ${${'GLOBALS'}['xfxitrwj']};
        }
        if (!isset($this->attr[${${'GLOBALS'}['qiughdhwjl']}])) {
            $this->_[HDOM_INFO_SPACE][] = array(' ', '', '');
            $this->_[HDOM_INFO_QUOTE][] = HDOM_QUOTE_DOUBLE;
        }
        $this->attr[${${'GLOBALS'}['rnpowno']}] = ${${'GLOBALS'}['sdcopkopk']};
    }
    public function __isset($name)
    {
        $zbvymnrrxrr = 'name';
        switch (${${'GLOBALS'}['qiughdhwjl']}) {
        case 'outertext':
            return true;
        case 'innertext':
            return true;
        case 'plaintext':
            return true;
        }
        return array_key_exists(${${'GLOBALS'}['qiughdhwjl']}, $this->attr) ? true : isset($this->attr[${$zbvymnrrxrr}]);
    }
    public function __unset($name)
    {
        $zdkjajngbj = 'name';
        if (isset($this->attr[${${'GLOBALS'}['qiughdhwjl']}])) {
            unset($this->attr[${$zdkjajngbj}]);
        }
    }
    public function convert_text($text)
    {
        ${'GLOBALS'}['qckvgjvg'] = 'sourceCharset';
        $vopjeuhesjys = 'targetCharset';
        ${'GLOBALS'}['qkwwldgcoy'] = 'debugObject';
        global $debugObject;
        $cphsvfzneuqr = 'converted_text';
        if (is_object(${${'GLOBALS'}['qkwwldgcoy']})) {
            $debugObject->debugLogEntry(1);
        }
        ${'GLOBALS'}['eusxik'] = 'converted_text';
        ${'GLOBALS'}['sdhcgwydmv'] = 'targetCharset';
        ${${'GLOBALS'}['eusxik']} = ${${'GLOBALS'}['kueflpmp']};
        ${'GLOBALS'}['wevhthdp'] = 'targetCharset';
        ${'GLOBALS'}['fsmshljn'] = 'debugObject';
        ${'GLOBALS'}['ksgupsjrx'] = 'sourceCharset';
        ${${'GLOBALS'}['ksgupsjrx']} = '';
        ${${'GLOBALS'}['wevhthdp']} = '';
        if ($this->dom) {
            $inunmaed = 'targetCharset';
            ${${'GLOBALS'}['evfxrcsldtl']} = strtoupper($this->dom->_charset);
            ${$inunmaed} = strtoupper($this->dom->_target_charset);
        }
        if (is_object(${${'GLOBALS'}['fsmshljn']})) {
            $jhzituh = 'sourceCharset';
            $debugObject->debugLog(3, (('source charset: ' . ${$jhzituh}) . ' target charaset: ') . ${${'GLOBALS'}['wirrrhclq']});
        }
        if ((!empty(${${'GLOBALS'}['qckvgjvg']}) && !empty(${${'GLOBALS'}['sdhcgwydmv']})) && strcasecmp(${${'GLOBALS'}['evfxrcsldtl']}, ${${'GLOBALS'}['wirrrhclq']}) != 0) {
            ${'GLOBALS'}['qbkjxmvelzj'] = 'targetCharset';
            if (strcasecmp(${${'GLOBALS'}['qbkjxmvelzj']}, 'UTF-8') == 0 && $this->is_utf8(${${'GLOBALS'}['kueflpmp']})) {
                ${${'GLOBALS'}['yjkclnnjq']} = ${${'GLOBALS'}['kueflpmp']};
            } else {
                $utwiwucflmie = 'converted_text';
                ${'GLOBALS'}['mgavfunijkb'] = 'targetCharset';
                ${'GLOBALS'}['onluhsc'] = 'text';
                ${$utwiwucflmie} = iconv(${${'GLOBALS'}['evfxrcsldtl']}, ${${'GLOBALS'}['mgavfunijkb']}, ${${'GLOBALS'}['onluhsc']});
            }
        }
        if (${$vopjeuhesjys} == 'UTF-8') {
            if (substr(${${'GLOBALS'}['yjkclnnjq']}, 0, 3) == '?') {
                $exqchiy = 'converted_text';
                ${'GLOBALS'}['hwpjzc'] = 'converted_text';
                ${${'GLOBALS'}['hwpjzc']} = substr(${$exqchiy}, 3);
            }
            $erntamd = 'converted_text';
            if (substr(${$erntamd}, -3) == '?') {
                $vlpxdo = 'converted_text';
                ${$vlpxdo} = substr(${${'GLOBALS'}['yjkclnnjq']}, 0, -3);
            }
        }
        return ${$cphsvfzneuqr};
    }
    static function is_utf8($str)
    {
        ${'GLOBALS'}['ueitlgit'] = 'b';
        ${${'GLOBALS'}['gldshxvohkl']} = 0;
        ${${'GLOBALS'}['ueitlgit']} = 0;
        ${${'GLOBALS'}['qgphzbxfcp']} = 0;
        $jfhwoxjgld = 'len';
        ${${'GLOBALS'}['gzdhkqwcr']} = strlen(${${'GLOBALS'}['fgvupcichziw']});
        for (${${'GLOBALS'}['iysvwodqrf']} = 0; ${${'GLOBALS'}['iysvwodqrf']} < ${$jfhwoxjgld}; ${${'GLOBALS'}['iysvwodqrf']}++) {
            ${'GLOBALS'}['wzenpfosub'] = 'c';
            $niirvxot = 'i';
            ${'GLOBALS'}['utpqcycghiki'] = 'c';
            ${${'GLOBALS'}['wzenpfosub']} = ord(${${'GLOBALS'}['fgvupcichziw']}[${$niirvxot}]);
            if (${${'GLOBALS'}['utpqcycghiki']} > 128) {
                $xybhyuemvfs = 'c';
                ${'GLOBALS'}['aptuhkrw'] = 'bits';
                $vkweglem = 'bits';
                $qbugikc = 'bits';
                $rwrcbnluyz = 'bits';
                $optokbrwv = 'c';
                $zecqosxrj = 'i';
                if (${$xybhyuemvfs} >= 254) {
                    return false;
                } elseif (${${'GLOBALS'}['gldshxvohkl']} >= 252) {
                    ${$qbugikc} = 6;
                } elseif (${$optokbrwv} >= 248) {
                    ${${'GLOBALS'}['aptuhkrw']} = 5;
                } elseif (${${'GLOBALS'}['gldshxvohkl']} >= 240) {
                    ${${'GLOBALS'}['qgphzbxfcp']} = 4;
                } elseif (${${'GLOBALS'}['gldshxvohkl']} >= 224) {
                    ${$rwrcbnluyz} = 3;
                } elseif (${${'GLOBALS'}['gldshxvohkl']} >= 192) {
                    ${${'GLOBALS'}['qgphzbxfcp']} = 2;
                } else {
                    return false;
                }
                ${'GLOBALS'}['tmqtbbmtiuck'] = 'bits';
                if (${$zecqosxrj} + ${$vkweglem} > ${${'GLOBALS'}['gzdhkqwcr']}) {
                    return false;
                }
                while (${${'GLOBALS'}['tmqtbbmtiuck']} > 1) {
                    $gznijfopi = 'b';
                    $bezzlhf = 'i';
                    $ackmoxhyowy = 'bits';
                    $mdlqmztkw = 'i';
                    ${$bezzlhf}++;
                    ${$gznijfopi} = ord(${${'GLOBALS'}['fgvupcichziw']}[${$mdlqmztkw}]);
                    if (${${'GLOBALS'}['wklbtjxgiwm']} < 128 || ${${'GLOBALS'}['wklbtjxgiwm']} > 191) {
                        return false;
                    }
                    ${$ackmoxhyowy}--;
                }
            }
        }
        return true;
    }
    public function get_display_size()
    {
        ${'GLOBALS'}['wfqfbxa'] = 'width';
        global $debugObject;
        ${${'GLOBALS'}['zlwlackk']} = -1;
        ${${'GLOBALS'}['ftxoktsw']} = -1;
        if ($this->tag !== 'img') {
            return false;
        }
        if (isset($this->attr['width'])) {
            ${'GLOBALS'}['iqduvqhuywc'] = 'width';
            ${${'GLOBALS'}['iqduvqhuywc']} = $this->attr['width'];
        }
        if (isset($this->attr['height'])) {
            ${${'GLOBALS'}['ftxoktsw']} = $this->attr['height'];
        }
        ${'GLOBALS'}['pjorqioztb'] = 'result';
        if (isset($this->attr['style'])) {
            ${'GLOBALS'}['miqcldjo'] = 'match';
            $ygvmbkscpz = 'attributes';
            $objdovcf = 'width';
            ${${'GLOBALS'}['wmdqdnwob']} = array();
            ${'GLOBALS'}['bujwnnmtobl'] = 'attributes';
            preg_match_all('/([\\w-]+)\\s*:\\s*([^;]+)\\s*;?/', $this->attr['style'], ${${'GLOBALS'}['lzakelec']}, PREG_SET_ORDER);
            foreach (${${'GLOBALS'}['lzakelec']} as ${${'GLOBALS'}['miqcldjo']}) {
                $udcreiscs = 'attributes';
                ${'GLOBALS'}['kulnbuqzt'] = 'match';
                ${$udcreiscs}[${${'GLOBALS'}['tkxxpbqrkjm']}[1]] = ${${'GLOBALS'}['kulnbuqzt']}[2];
            }
            if (isset(${${'GLOBALS'}['bujwnnmtobl']}['width']) && ${$objdovcf} == -1) {
                $xlhqeuhnkk = 'attributes';
                if (strtolower(substr(${$xlhqeuhnkk}['width'], -2)) == 'px') {
                    $epwpvghjqz = 'proposed_width';
                    $pxjreameqqyy = 'attributes';
                    ${'GLOBALS'}['xwiqkjk'] = 'proposed_width';
                    ${$epwpvghjqz} = substr(${$pxjreameqqyy}['width'], 0, -2);
                    if (filter_var(${${'GLOBALS'}['xwiqkjk']}, FILTER_VALIDATE_INT)) {
                        $feecrmqqjrm = 'proposed_width';
                        ${${'GLOBALS'}['zlwlackk']} = ${$feecrmqqjrm};
                    }
                }
            }
            if (isset(${$ygvmbkscpz}['height']) && ${${'GLOBALS'}['ftxoktsw']} == -1) {
                $ykujeetxsaif = 'attributes';
                if (strtolower(substr(${$ykujeetxsaif}['height'], -2)) == 'px') {
                    $xwmsbbmf = 'proposed_height';
                    ${$xwmsbbmf} = substr(${${'GLOBALS'}['wmdqdnwob']}['height'], 0, -2);
                    if (filter_var(${${'GLOBALS'}['jopifil']}, FILTER_VALIDATE_INT)) {
                        ${${'GLOBALS'}['ftxoktsw']} = ${${'GLOBALS'}['jopifil']};
                    }
                }
            }
        }
        $uwyorpnju = 'height';
        ${${'GLOBALS'}['rjfoougypoye']} = array('height' => ${$uwyorpnju}, 'width' => ${${'GLOBALS'}['wfqfbxa']});
        return ${${'GLOBALS'}['pjorqioztb']};
    }
    public function getAllAttributes()
    {
        return $this->attr;
    }
    public function getAttribute($name)
    {
        ${'GLOBALS'}['isofseujei'] = 'name';
        return $this->__get(${${'GLOBALS'}['isofseujei']});
    }
    public function setAttribute($name, $value)
    {
        ${'GLOBALS'}['jeocuwpf'] = 'value';
        ${'GLOBALS'}['ipmernvtlocm'] = 'name';
        $this->__set(${${'GLOBALS'}['ipmernvtlocm']}, ${${'GLOBALS'}['jeocuwpf']});
    }
    public function hasAttribute($name)
    {
        $ioqeqmecwsl = 'name';
        return $this->__isset(${$ioqeqmecwsl});
    }
    public function removeAttribute($name)
    {
        $ctcdfrkdb = 'name';
        $this->__set(${$ctcdfrkdb}, null);
    }
    public function getElementById($id)
    {
        return $this->find("#{$id}", 0);
    }
    public function getElementsById($id, $idx = null)
    {
        return $this->find("#{$id}", ${${'GLOBALS'}['tcpuoctul']});
    }
    public function getElementByTagName($name)
    {
        ${'GLOBALS'}['yjnvrvjz'] = 'name';
        return $this->find(${${'GLOBALS'}['yjnvrvjz']}, 0);
    }
    public function getElementsByTagName($name, $idx = null)
    {
        $ffgmjyshykw = 'name';
        return $this->find(${$ffgmjyshykw}, ${${'GLOBALS'}['tcpuoctul']});
    }
    public function parentNode()
    {
        return $this->parent();
    }
    public function childNodes($idx = -1)
    {
        $acgwrwf = 'idx';
        return $this->children(${$acgwrwf});
    }
    public function firstChild()
    {
        return $this->first_child();
    }
    public function lastChild()
    {
        return $this->last_child();
    }
    public function nextSibling()
    {
        return $this->next_sibling();
    }
    public function previousSibling()
    {
        return $this->prev_sibling();
    }
    public function hasChildNodes()
    {
        return $this->has_child();
    }
    public function nodeName()
    {
        return $this->tag;
    }
    public function appendChild($node)
    {
        ${'GLOBALS'}['eimdcctneno'] = 'node';
        $node->parent($this);
        return ${${'GLOBALS'}['eimdcctneno']};
    }
}
class simple_html_dom
{
    public $root = null;
    public $nodes = array();
    public $callback = null;
    public $lowercase = false;
    public $original_size;
    public $size;
    protected $pos;
    protected $doc;
    protected $char;
    protected $cursor;
    protected $parent;
    protected $noise = array();
    protected $token_blank = ' 	
';
    protected $token_equal = ' =/>';
    protected $token_slash = ' />
	';
    protected $token_attr = ' >';
    public $_charset = '';
    public $_target_charset = '';
    protected $default_br_text = '';
    public $default_span_text = '';
    protected $self_closing_tags = array('img' => 1, 'br' => 1, 'input' => 1, 'meta' => 1, 'link' => 1, 'hr' => 1, 'base' => 1, 'embed' => 1, 'spacer' => 1);
    protected $block_tags = array('root' => 1, 'body' => 1, 'form' => 1, 'div' => 1, 'span' => 1, 'table' => 1);
    protected $optional_closing_tags = array('tr' => array('tr' => 1, 'td' => 1, 'th' => 1), 'th' => array('th' => 1), 'td' => array('td' => 1), 'li' => array('li' => 1), 'dt' => array('dt' => 1, 'dd' => 1), 'dd' => array('dd' => 1, 'dt' => 1), 'dl' => array('dd' => 1, 'dt' => 1), 'p' => array('p' => 1), 'nobr' => array('nobr' => 1), 'b' => array('b' => 1), 'option' => array('option' => 1));
    public function __construct($str = null, $lowercase = true, $forceTagsClosed = true, $target_charset = DEFAULT_TARGET_CHARSET, $stripRN = true, $defaultBRText = DEFAULT_BR_TEXT, $defaultSpanText = DEFAULT_SPAN_TEXT)
    {
        ${'GLOBALS'}['narcifxzowe'] = 'str';
        if (${${'GLOBALS'}['narcifxzowe']}) {
            $cxgsddx = 'str';
            if (preg_match('/^http:\\/\\//i', ${$cxgsddx}) || is_file(${${'GLOBALS'}['fgvupcichziw']})) {
                $this->load_file(${${'GLOBALS'}['fgvupcichziw']});
            } else {
                ${'GLOBALS'}['nleies'] = 'lowercase';
                $this->load(${${'GLOBALS'}['fgvupcichziw']}, ${${'GLOBALS'}['nleies']}, ${${'GLOBALS'}['recbduhgh']}, ${${'GLOBALS'}['xgslhlqthsr']}, ${${'GLOBALS'}['kjdlmahobpl']});
            }
        }
        ${'GLOBALS'}['vadonlfuigwh'] = 'forceTagsClosed';
        if (!${${'GLOBALS'}['vadonlfuigwh']}) {
            $this->optional_closing_array = array();
        }
        $this->_target_charset = ${${'GLOBALS'}['kkgslhpcwwct']};
    }
    public function __destruct()
    {
        $this->clear();
    }
    public function load($str, $lowercase = true, $stripRN = true, $defaultBRText = DEFAULT_BR_TEXT, $defaultSpanText = DEFAULT_SPAN_TEXT)
    {
        $uwemsiho = 'stripRN';
        global $debugObject;
        $this->prepare(${${'GLOBALS'}['fgvupcichziw']}, ${${'GLOBALS'}['srnzjhhou']}, ${$uwemsiho}, ${${'GLOBALS'}['xgslhlqthsr']}, ${${'GLOBALS'}['kjdlmahobpl']});
        $this->remove_noise('\'<!--(.*?)-->\'is');
        $this->remove_noise('\'<!\\[CDATA\\[(.*?)\\]\\]>\'is', true);
        $this->remove_noise('\'<\\s*script[^>]*[^/]>(.*?)<\\s*/\\s*script\\s*>\'is');
        $this->remove_noise('\'<\\s*script\\s*>(.*?)<\\s*/\\s*script\\s*>\'is');
        $this->remove_noise('\'<\\s*style[^>]*[^/]>(.*?)<\\s*/\\s*style\\s*>\'is');
        $this->remove_noise('\'<\\s*style\\s*>(.*?)<\\s*/\\s*style\\s*>\'is');
        $this->remove_noise('\'<\\s*(?:code)[^>]*>(.*?)<\\s*/\\s*(?:code)\\s*>\'is');
        $this->remove_noise('\'(<\\?)(.*?)(\\?>)\'s', true);
        $this->remove_noise('\'(\\{\\w)(.*?)(\\})\'s', true);
        while ($this->parse()) {
            
        }
        $this->root->_[HDOM_INFO_END] = $this->cursor;
        $this->parse_charset();
        return $this;
    }
    public function load_file()
    {
        ${'GLOBALS'}['rghgvre'] = 'args';
        $yrstlreki = 'error';
        ${${'GLOBALS'}['ckyndtgc']} = func_get_args();
        $this->load(call_user_func_array('file_get_contents', ${${'GLOBALS'}['rghgvre']}), true);
        if ((${$yrstlreki} = error_get_last()) !== null) {
            $this->clear();
            return false;
        }
    }
    public function set_callback($function_name)
    {
        ${'GLOBALS'}['ixbisxbcvtlq'] = 'function_name';
        $this->callback = ${${'GLOBALS'}['ixbisxbcvtlq']};
    }
    public function remove_callback()
    {
        $this->callback = null;
    }
    public function save($filepath = '')
    {
        ${'GLOBALS'}['coveqvchst'] = 'filepath';
        $vwosvplw = 'filepath';
        $vlhxcsmkgw = 'ret';
        ${${'GLOBALS'}['qzxevewqkf']} = $this->root->innertext();
        if (${${'GLOBALS'}['coveqvchst']} !== '') {
            file_put_contents(${$vwosvplw}, ${$vlhxcsmkgw}, LOCK_EX);
        }
        return ${${'GLOBALS'}['qzxevewqkf']};
    }
    public function find($selector, $idx = null, $lowercase = false)
    {
        ${'GLOBALS'}['grqeteowcx'] = 'selector';
        $xyfxymylp = 'lowercase';
        return $this->root->find(${${'GLOBALS'}['grqeteowcx']}, ${${'GLOBALS'}['tcpuoctul']}, ${$xyfxymylp});
    }
    public function clear()
    {
        foreach ($this->nodes as ${${'GLOBALS'}['ifpupts']}) {
            $n->clear();
            ${${'GLOBALS'}['ifpupts']} = null;
        }
        if (isset($this->children)) {
            foreach ($this->children as ${${'GLOBALS'}['ifpupts']}) {
                $n->clear();
                ${${'GLOBALS'}['ifpupts']} = null;
            }
        }
        if (isset($this->parent)) {
            $this->parent->clear();
            unset($this->parent);
        }
        if (isset($this->root)) {
            $this->root->clear();
            unset($this->root);
        }
        unset($this->doc);
        unset($this->noise);
    }
    public function dump($show_attr = true)
    {
        ${'GLOBALS'}['cwwzospqpq'] = 'show_attr';
        $this->root->dump(${${'GLOBALS'}['cwwzospqpq']});
    }
    protected function prepare($str, $lowercase = true, $stripRN = true, $defaultBRText = DEFAULT_BR_TEXT, $defaultSpanText = DEFAULT_SPAN_TEXT)
    {
        $joijqnem = 'defaultSpanText';
        ${'GLOBALS'}['xhbrbqlyda'] = 'stripRN';
        $this->clear();
        $this->size = strlen(${${'GLOBALS'}['fgvupcichziw']});
        $this->original_size = $this->size;
        $fcpjrktrdryg = 'lowercase';
        if (${${'GLOBALS'}['xhbrbqlyda']}) {
            $nydszvk = 'str';
            $wkmcsqv = 'str';
            ${$nydszvk} = str_replace('
', ' ', ${${'GLOBALS'}['fgvupcichziw']});
            ${$wkmcsqv} = str_replace('
', ' ', ${${'GLOBALS'}['fgvupcichziw']});
            $this->size = strlen(${${'GLOBALS'}['fgvupcichziw']});
        }
        $this->doc = ${${'GLOBALS'}['fgvupcichziw']};
        $this->pos = 0;
        $this->cursor = 1;
        $this->noise = array();
        $this->nodes = array();
        $this->lowercase = ${$fcpjrktrdryg};
        $this->default_br_text = ${${'GLOBALS'}['xgslhlqthsr']};
        $this->default_span_text = ${$joijqnem};
        $this->root = new simple_html_dom_node($this);
        $this->root->tag = 'root';
        $this->root->_[HDOM_INFO_BEGIN] = -1;
        $this->root->nodetype = HDOM_TYPE_ROOT;
        $this->parent = $this->root;
        if ($this->size > 0) {
            $this->char = $this->doc[0];
        }
    }
    protected function parse()
    {
        ${'GLOBALS'}['ogoiqllepyo'] = 's';
        if ((${${'GLOBALS'}['ogoiqllepyo']} = $this->copy_until_char('<')) === '') {
            return $this->read_tag();
        }
        ${'GLOBALS'}['gybqxvdsimmw'] = 'node';
        ${${'GLOBALS'}['gybqxvdsimmw']} = new simple_html_dom_node($this);
        ++$this->cursor;
        $node->_[HDOM_INFO_TEXT] = ${${'GLOBALS'}['wwaudytvks']};
        $this->link_nodes(${${'GLOBALS'}['lpuxeaf']}, false);
        return true;
    }
    protected function parse_charset()
    {
        global $debugObject;
        ${'GLOBALS'}['knjfmwoaqj'] = 'charset';
        ${'GLOBALS'}['wnloeumw'] = 'charset';
        ${'GLOBALS'}['pmagxk'] = 'charset';
        ${${'GLOBALS'}['ukhqmstsw']} = null;
        if (function_exists('get_last_retrieve_url_contents_content_type')) {
            $mmjjfjj = 'contentTypeHeader';
            $zjcoebwkp = 'success';
            ${'GLOBALS'}['czwwhgojesyv'] = 'matches';
            ${${'GLOBALS'}['nqhxvuygr']} = get_last_retrieve_url_contents_content_type();
            ${${'GLOBALS'}['mwkrvesiiwol']} = preg_match('/charset=(.+)/', ${$mmjjfjj}, ${${'GLOBALS'}['czwwhgojesyv']});
            if (${$zjcoebwkp}) {
                $czepipixj = 'debugObject';
                ${${'GLOBALS'}['ukhqmstsw']} = ${${'GLOBALS'}['lzakelec']}[1];
                if (is_object(${$czepipixj})) {
                    ${'GLOBALS'}['whpnrtd'] = 'charset';
                    $debugObject->debugLog(2, 'header content-type found charset of: ' . ${${'GLOBALS'}['whpnrtd']});
                }
            }
        }
        if (empty(${${'GLOBALS'}['ukhqmstsw']})) {
            $omrnwyo = 'charset';
            ${$omrnwyo} = $this->_target_charset;
        }
        ${'GLOBALS'}['eqkhebwjyrw'] = 'charset';
        if (empty(${${'GLOBALS'}['wnloeumw']})) {
            ${'GLOBALS'}['xhemliiysw'] = 'el';
            ${${'GLOBALS'}['xhemliiysw']} = $this->root->find('meta[http-equiv=Content-Type]', 0);
            if (!empty(${${'GLOBALS'}['sizqinpu']})) {
                $zigquchbp = 'debugObject';
                ${${'GLOBALS'}['bwhpjucyqd']} = $el->content;
                if (is_object(${$zigquchbp})) {
                    $debugObject->debugLog(2, 'meta content-type tag found' . ${${'GLOBALS'}['bwhpjucyqd']});
                }
                if (!empty(${${'GLOBALS'}['bwhpjucyqd']})) {
                    $gxyhtwew = 'success';
                    $nbvbrynd = 'matches';
                    ${'GLOBALS'}['gatjghgrbu'] = 'fullvalue';
                    ${'GLOBALS'}['hvqpcpg'] = 'success';
                    ${${'GLOBALS'}['hvqpcpg']} = preg_match('/charset=(.+)/', ${${'GLOBALS'}['gatjghgrbu']}, ${$nbvbrynd});
                    if (${$gxyhtwew}) {
                        ${'GLOBALS'}['dvhytiulsml'] = 'charset';
                        ${${'GLOBALS'}['dvhytiulsml']} = ${${'GLOBALS'}['lzakelec']}[1];
                    } else {
                        ${'GLOBALS'}['uosyhulbepg'] = 'debugObject';
                        if (is_object(${${'GLOBALS'}['uosyhulbepg']})) {
                            $debugObject->debugLog(2, 'meta content-type tag couldn\'t be parsed. using iso-8859 default.');
                        }
                        ${${'GLOBALS'}['ukhqmstsw']} = 'ISO-8859-1';
                    }
                }
            }
        }
        if (empty(${${'GLOBALS'}['ukhqmstsw']})) {
            $kgqttledvl = 'charset';
            ${'GLOBALS'}['etdbdyie'] = 'debugObject';
            ${$kgqttledvl} = mb_detect_encoding($this->root->plaintext . 'ascii', (${${'GLOBALS'}['xbhrnq']} = array('UTF-8', 'CP1252')));
            if (is_object(${${'GLOBALS'}['etdbdyie']})) {
                ${'GLOBALS'}['chdwhqpfslz'] = 'charset';
                $debugObject->debugLog(2, 'mb_detect found: ' . ${${'GLOBALS'}['chdwhqpfslz']});
            }
            if (${${'GLOBALS'}['ukhqmstsw']} === false) {
                $dtluizll = 'debugObject';
                if (is_object(${$dtluizll})) {
                    $debugObject->debugLog(2, 'since mb_detect failed - using default of utf-8');
                }
                ${${'GLOBALS'}['ukhqmstsw']} = 'UTF-8';
            }
        }
        if ((strtolower(${${'GLOBALS'}['eqkhebwjyrw']}) == strtolower('ISO-8859-1') || strtolower(${${'GLOBALS'}['pmagxk']}) == strtolower('Latin1')) || strtolower(${${'GLOBALS'}['knjfmwoaqj']}) == strtolower('Latin-1')) {
            if (is_object(${${'GLOBALS'}['fotqnjvm']})) {
                ${'GLOBALS'}['kwaxtljwodyx'] = 'charset';
                $debugObject->debugLog(2, ('replacing ' . ${${'GLOBALS'}['kwaxtljwodyx']}) . ' with CP1252 as its a superset');
            }
            ${${'GLOBALS'}['ukhqmstsw']} = 'CP1252';
        }
        if (is_object(${${'GLOBALS'}['fotqnjvm']})) {
            $hbxhqpc = 'charset';
            $debugObject->debugLog(1, 'EXIT - ' . ${$hbxhqpc});
        }
        return $this->_charset = ${${'GLOBALS'}['ukhqmstsw']};
    }
    protected function read_tag()
    {
        if ($this->char !== '<') {
            $this->root->_[HDOM_INFO_END] = $this->cursor;
            return false;
        }
        $mewosxkg = 'begin_tag_pos';
        $dvvjsmtb = 'node';
        ${$mewosxkg} = $this->pos;
        $this->char = ++$this->pos < $this->size ? $this->doc[$this->pos] : null;
        ${'GLOBALS'}['srewkcr'] = 'tag';
        ${'GLOBALS'}['pxsqsmlswj'] = 'tag';
        if ($this->char === '/') {
            $qktevjf = 'tag';
            ${'GLOBALS'}['tcpdcrsgr'] = 'tag';
            ${'GLOBALS'}['hvbxndv'] = 'tag';
            $uamdhv = 'pos';
            $this->char = ++$this->pos < $this->size ? $this->doc[$this->pos] : null;
            $idsaevsbd = 'parent_lower';
            $this->skip($this->token_blank);
            ${'GLOBALS'}['kzuxxxyupvq'] = 'tag_lower';
            ${$qktevjf} = $this->copy_until_char('>');
            if ((${$uamdhv} = strpos(${${'GLOBALS'}['hvbxndv']}, ' ')) !== false) {
                ${${'GLOBALS'}['wnewosaggmy']} = substr(${${'GLOBALS'}['tcpdcrsgr']}, 0, ${${'GLOBALS'}['ymmruswvc']});
            }
            $brflgufcv = 'tag';
            ${$idsaevsbd} = strtolower($this->parent->tag);
            ${${'GLOBALS'}['quwporli']} = strtolower(${$brflgufcv});
            if (${${'GLOBALS'}['mmohkjudkfo']} !== ${${'GLOBALS'}['kzuxxxyupvq']}) {
                ${'GLOBALS'}['nklxxbxbd'] = 'tag_lower';
                $qofamhm = 'tag_lower';
                ${'GLOBALS'}['vekuvrh'] = 'tag';
                $wrvyhxirdl = 'parent_lower';
                if (isset($this->optional_closing_tags[${$wrvyhxirdl}]) && isset($this->block_tags[${$qofamhm}])) {
                    $this->parent->_[HDOM_INFO_END] = 0;
                    ${${'GLOBALS'}['plccpkhc']} = $this->parent;
                    $dbbrlzsbl = 'tag_lower';
                    while ($this->parent->parent && strtolower($this->parent->tag) !== ${${'GLOBALS'}['quwporli']}) {
                        $this->parent = $this->parent->parent;
                    }
                    if (strtolower($this->parent->tag) !== ${$dbbrlzsbl}) {
                        $this->parent = ${${'GLOBALS'}['plccpkhc']};
                        if ($this->parent->parent) {
                            $this->parent = $this->parent->parent;
                        }
                        $this->parent->_[HDOM_INFO_END] = $this->cursor;
                        return $this->as_text_node(${${'GLOBALS'}['wnewosaggmy']});
                    }
                } else {
                    if ($this->parent->parent && isset($this->block_tags[${${'GLOBALS'}['quwporli']}])) {
                        $evtslbdbxn = 'org_parent';
                        ${'GLOBALS'}['fzojeujy'] = 'tag_lower';
                        $this->parent->_[HDOM_INFO_END] = 0;
                        ${'GLOBALS'}['yquvbbgi'] = 'tag_lower';
                        ${$evtslbdbxn} = $this->parent;
                        while ($this->parent->parent && strtolower($this->parent->tag) !== ${${'GLOBALS'}['fzojeujy']}) {
                            $this->parent = $this->parent->parent;
                        }
                        if (strtolower($this->parent->tag) !== ${${'GLOBALS'}['yquvbbgi']}) {
                            $this->parent = ${${'GLOBALS'}['plccpkhc']};
                            $guwpyjhlm = 'tag';
                            $this->parent->_[HDOM_INFO_END] = $this->cursor;
                            return $this->as_text_node(${$guwpyjhlm});
                        }
                    } else {
                        if ($this->parent->parent && strtolower($this->parent->parent->tag) === ${${'GLOBALS'}['nklxxbxbd']}) {
                            $this->parent->_[HDOM_INFO_END] = 0;
                            $this->parent = $this->parent->parent;
                        } else {
                            return $this->as_text_node(${${'GLOBALS'}['vekuvrh']});
                        }
                    }
                }
            }
            $this->parent->_[HDOM_INFO_END] = $this->cursor;
            if ($this->parent->parent) {
                $this->parent = $this->parent->parent;
            }
            $this->char = ++$this->pos < $this->size ? $this->doc[$this->pos] : null;
            return true;
        }
        ${'GLOBALS'}['fwwsshlicvh'] = 'tag';
        ${$dvvjsmtb} = new simple_html_dom_node($this);
        $jjbjsewngc = 'tag_lower';
        $node->_[HDOM_INFO_BEGIN] = $this->cursor;
        ++$this->cursor;
        ${${'GLOBALS'}['fwwsshlicvh']} = $this->copy_until($this->token_slash);
        $node->tag_start = ${${'GLOBALS'}['uytdmpafsae']};
        ${'GLOBALS'}['bfouicukkw'] = 'tag';
        ${'GLOBALS'}['ayeoccbqcbs'] = 'pos';
        if (isset(${${'GLOBALS'}['bfouicukkw']}[0]) && ${${'GLOBALS'}['srewkcr']}[0] === '!') {
            $sgwbmdnovz = 'tag';
            $nokujvfeqt = 'tag';
            ${'GLOBALS'}['vchyninwmp'] = 'tag';
            $node->_[HDOM_INFO_TEXT] = ('<' . ${${'GLOBALS'}['vchyninwmp']}) . $this->copy_until_char('>');
            $hnlpcoukcf = 'tag';
            $prygnfuvk = 'node';
            if ((isset(${$hnlpcoukcf}[2]) && ${$sgwbmdnovz}[1] === '-') && ${$nokujvfeqt}[2] === '-') {
                $node->nodetype = HDOM_TYPE_COMMENT;
                $node->tag = 'comment';
            } else {
                $node->nodetype = HDOM_TYPE_UNKNOWN;
                $node->tag = 'unknown';
            }
            if ($this->char === '>') {
                $node->_[HDOM_INFO_TEXT] .= '>';
            }
            $this->link_nodes(${$prygnfuvk}, true);
            $this->char = ++$this->pos < $this->size ? $this->doc[$this->pos] : null;
            return true;
        }
        if (${${'GLOBALS'}['ayeoccbqcbs']} = strpos(${${'GLOBALS'}['pxsqsmlswj']}, '<') !== false) {
            ${'GLOBALS'}['ybcwkr'] = 'tag';
            ${'GLOBALS'}['ntsvjnjoly'] = 'node';
            ${${'GLOBALS'}['wnewosaggmy']} = '<' . substr(${${'GLOBALS'}['wnewosaggmy']}, 0, -1);
            $node->_[HDOM_INFO_TEXT] = ${${'GLOBALS'}['ybcwkr']};
            $this->link_nodes(${${'GLOBALS'}['ntsvjnjoly']}, false);
            $this->char = $this->doc[--$this->pos];
            return true;
        }
        if (!preg_match('/^[\\w-:]+$/', ${${'GLOBALS'}['wnewosaggmy']})) {
            $node->_[HDOM_INFO_TEXT] = ('<' . ${${'GLOBALS'}['wnewosaggmy']}) . $this->copy_until('<>');
            if ($this->char === '<') {
                $erygqoht = 'node';
                $this->link_nodes(${$erygqoht}, false);
                return true;
            }
            ${'GLOBALS'}['mnzlejyx'] = 'node';
            if ($this->char === '>') {
                $node->_[HDOM_INFO_TEXT] .= '>';
            }
            $this->link_nodes(${${'GLOBALS'}['mnzlejyx']}, false);
            $this->char = ++$this->pos < $this->size ? $this->doc[$this->pos] : null;
            return true;
        }
        $node->nodetype = HDOM_TYPE_ELEMENT;
        ${$jjbjsewngc} = strtolower(${${'GLOBALS'}['wnewosaggmy']});
        $node->tag = $this->lowercase ? ${${'GLOBALS'}['quwporli']} : ${${'GLOBALS'}['wnewosaggmy']};
        if (isset($this->optional_closing_tags[${${'GLOBALS'}['quwporli']}])) {
            while (isset($this->optional_closing_tags[${${'GLOBALS'}['quwporli']}][strtolower($this->parent->tag)])) {
                $this->parent->_[HDOM_INFO_END] = 0;
                $this->parent = $this->parent->parent;
            }
            $node->parent = $this->parent;
        }
        ${${'GLOBALS'}['wmsndcovop']} = 0;
        ${${'GLOBALS'}['yyukbkigodb']} = array($this->copy_skip($this->token_blank), '', '');
        do {
            $yxqumjddfk = 'name';
            $ihurhgcvpje = 'name';
            ${'GLOBALS'}['nddnmenqco'] = 'space';
            ${'GLOBALS'}['wlqvxvsoiilu'] = 'guard';
            if ($this->char !== null && ${${'GLOBALS'}['nddnmenqco']}[0] === '') {
                break;
            }
            ${$yxqumjddfk} = $this->copy_until($this->token_equal);
            if (${${'GLOBALS'}['wmsndcovop']} === $this->pos) {
                $this->char = ++$this->pos < $this->size ? $this->doc[$this->pos] : null;
                continue;
            }
            ${${'GLOBALS'}['wlqvxvsoiilu']} = $this->pos;
            if ($this->pos >= $this->size - 1 && $this->char !== '>') {
                $wkueegtxv = 'name';
                $node->nodetype = HDOM_TYPE_TEXT;
                $node->_[HDOM_INFO_END] = 0;
                $node->_[HDOM_INFO_TEXT] = (('<' . ${${'GLOBALS'}['wnewosaggmy']}) . ${${'GLOBALS'}['yyukbkigodb']}[0]) . ${$wkueegtxv};
                $kogvjlgjmuo = 'node';
                $node->tag = 'text';
                $this->link_nodes(${$kogvjlgjmuo}, false);
                return true;
            }
            if ($this->doc[$this->pos - 1] == '<') {
                ${'GLOBALS'}['nvjldcgdubky'] = 'node';
                $node->nodetype = HDOM_TYPE_TEXT;
                ${'GLOBALS'}['uipmpq'] = 'begin_tag_pos';
                $node->tag = 'text';
                $node->attr = array();
                $node->_[HDOM_INFO_END] = 0;
                $node->_[HDOM_INFO_TEXT] = substr($this->doc, ${${'GLOBALS'}['uipmpq']}, ($this->pos - ${${'GLOBALS'}['uytdmpafsae']}) - 1);
                $this->pos -= 2;
                $this->char = ++$this->pos < $this->size ? $this->doc[$this->pos] : null;
                $this->link_nodes(${${'GLOBALS'}['nvjldcgdubky']}, false);
                return true;
            }
            if (${${'GLOBALS'}['qiughdhwjl']} !== '/' && ${$ihurhgcvpje} !== '') {
                ${'GLOBALS'}['jzhrmbmppiud'] = 'name';
                ${'GLOBALS'}['ubzslyzw'] = 'space';
                $pcvvqjd = 'name';
                ${'GLOBALS'}['kzvmgp'] = 'name';
                ${${'GLOBALS'}['yyukbkigodb']}[1] = $this->copy_skip($this->token_blank);
                ${$pcvvqjd} = $this->restore_noise(${${'GLOBALS'}['kzvmgp']});
                if ($this->lowercase) {
                    ${${'GLOBALS'}['jzhrmbmppiud']} = strtolower(${${'GLOBALS'}['qiughdhwjl']});
                }
                if ($this->char === '=') {
                    $this->char = ++$this->pos < $this->size ? $this->doc[$this->pos] : null;
                    ${'GLOBALS'}['warejnh'] = 'name';
                    $this->parse_attr(${${'GLOBALS'}['lpuxeaf']}, ${${'GLOBALS'}['warejnh']}, ${${'GLOBALS'}['yyukbkigodb']});
                } else {
                    ${'GLOBALS'}['igtcml'] = 'name';
                    $node->_[HDOM_INFO_QUOTE][] = HDOM_QUOTE_NO;
                    $node->attr[${${'GLOBALS'}['igtcml']}] = true;
                    if ($this->char != '>') {
                        $this->char = $this->doc[--$this->pos];
                    }
                }
                ${'GLOBALS'}['kqfxstoima'] = 'space';
                $node->_[HDOM_INFO_SPACE][] = ${${'GLOBALS'}['kqfxstoima']};
                ${${'GLOBALS'}['ubzslyzw']} = array($this->copy_skip($this->token_blank), '', '');
            } else {
                break;
            }
        } while ($this->char !== '>' && $this->char !== '/');
        $this->link_nodes(${${'GLOBALS'}['lpuxeaf']}, true);
        $node->_[HDOM_INFO_ENDSPACE] = ${${'GLOBALS'}['yyukbkigodb']}[0];
        if ($this->copy_until_char_escape('>') === '/') {
            $node->_[HDOM_INFO_ENDSPACE] .= '/';
            $node->_[HDOM_INFO_END] = 0;
        } else {
            if (!isset($this->self_closing_tags[strtolower($node->tag)])) {
                $this->parent = ${${'GLOBALS'}['lpuxeaf']};
            }
        }
        $this->char = ++$this->pos < $this->size ? $this->doc[$this->pos] : null;
        if ($node->tag == 'br') {
            $node->_[HDOM_INFO_INNER] = $this->default_br_text;
        }
        return true;
    }
    protected function parse_attr($node, $name, &$space)
    {
        ${'GLOBALS'}['ryhlchh'] = 'name';
        if (isset($node->attr[${${'GLOBALS'}['qiughdhwjl']}])) {
            return;
        }
        ${'GLOBALS'}['ihtcuuwrex'] = 'name';
        ${${'GLOBALS'}['yyukbkigodb']}[2] = $this->copy_skip($this->token_blank);
        ${'GLOBALS'}['gwchqxpesz'] = 'name';
        $ricfgmhyppn = 'name';
        $bktitaai = 'name';
        switch ($this->char) {
        case '"':
            $node->_[HDOM_INFO_QUOTE][] = HDOM_QUOTE_DOUBLE;
            $this->char = ++$this->pos < $this->size ? $this->doc[$this->pos] : null;
            $node->attr[${${'GLOBALS'}['qiughdhwjl']}] = $this->restore_noise($this->copy_until_char_escape('"'));
            $this->char = ++$this->pos < $this->size ? $this->doc[$this->pos] : null;
            break;
        case '\'':
            $node->_[HDOM_INFO_QUOTE][] = HDOM_QUOTE_SINGLE;
            $this->char = ++$this->pos < $this->size ? $this->doc[$this->pos] : null;
            $node->attr[${$bktitaai}] = $this->restore_noise($this->copy_until_char_escape('\''));
            $this->char = ++$this->pos < $this->size ? $this->doc[$this->pos] : null;
            break;
        default:
            $node->_[HDOM_INFO_QUOTE][] = HDOM_QUOTE_NO;
            $node->attr[${${'GLOBALS'}['qiughdhwjl']}] = $this->restore_noise($this->copy_until($this->token_attr));
        }
        $node->attr[${${'GLOBALS'}['qiughdhwjl']}] = str_replace('
', '', $node->attr[${${'GLOBALS'}['ryhlchh']}]);
        $node->attr[${${'GLOBALS'}['gwchqxpesz']}] = str_replace('
', '', $node->attr[${$ricfgmhyppn}]);
        if (${${'GLOBALS'}['ihtcuuwrex']} == 'class') {
            $node->attr[${${'GLOBALS'}['qiughdhwjl']}] = trim($node->attr[${${'GLOBALS'}['qiughdhwjl']}]);
        }
    }
    protected function link_nodes(&$node, $is_child)
    {
        $hwigrojk = 'is_child';
        $node->parent = $this->parent;
        $wblygqjp = 'node';
        $this->parent->nodes[] = ${$wblygqjp};
        if (${$hwigrojk}) {
            $this->parent->children[] = ${${'GLOBALS'}['lpuxeaf']};
        }
    }
    protected function as_text_node($tag)
    {
        $cjyedcxcsxt = 'node';
        ${$cjyedcxcsxt} = new simple_html_dom_node($this);
        ++$this->cursor;
        $nzoqvfqx = 'tag';
        $node->_[HDOM_INFO_TEXT] = ('</' . ${$nzoqvfqx}) . '>';
        $this->link_nodes(${${'GLOBALS'}['lpuxeaf']}, false);
        $this->char = ++$this->pos < $this->size ? $this->doc[$this->pos] : null;
        return true;
    }
    protected function skip($chars)
    {
        ${'GLOBALS'}['dfivsd'] = 'chars';
        $this->pos += strspn($this->doc, ${${'GLOBALS'}['dfivsd']}, $this->pos);
        $this->char = $this->pos < $this->size ? $this->doc[$this->pos] : null;
    }
    protected function copy_skip($chars)
    {
        $mzxwgggbu = 'chars';
        $ajrresiem = 'pos';
        $rahvtfoodzw = 'len';
        ${'GLOBALS'}['dtxnfxkc'] = 'pos';
        ${$ajrresiem} = $this->pos;
        ${${'GLOBALS'}['gzdhkqwcr']} = strspn($this->doc, ${$mzxwgggbu}, ${${'GLOBALS'}['dtxnfxkc']});
        ${'GLOBALS'}['yxyixdncobw'] = 'len';
        $this->pos += ${$rahvtfoodzw};
        $this->char = $this->pos < $this->size ? $this->doc[$this->pos] : null;
        if (${${'GLOBALS'}['yxyixdncobw']} === 0) {
            return '';
        }
        return substr($this->doc, ${${'GLOBALS'}['ymmruswvc']}, ${${'GLOBALS'}['gzdhkqwcr']});
    }
    protected function copy_until($chars)
    {
        $pkiijdvgdl = 'pos';
        ${'GLOBALS'}['fotvildvqs'] = 'chars';
        $ykpjmngjhhmz = 'pos';
        ${$pkiijdvgdl} = $this->pos;
        $qfsruir = 'len';
        ${'GLOBALS'}['cbxyippaxql'] = 'pos';
        ${${'GLOBALS'}['gzdhkqwcr']} = strcspn($this->doc, ${${'GLOBALS'}['fotvildvqs']}, ${${'GLOBALS'}['cbxyippaxql']});
        $this->pos += ${${'GLOBALS'}['gzdhkqwcr']};
        $this->char = $this->pos < $this->size ? $this->doc[$this->pos] : null;
        return substr($this->doc, ${$ykpjmngjhhmz}, ${$qfsruir});
    }
    protected function copy_until_char($char)
    {
        $hqswwmldik = 'pos';
        $mbdfht = 'pos';
        ${'GLOBALS'}['lffinskkm'] = 'char';
        $kcvlaetefif = 'pos';
        if ($this->char === null) {
            return '';
        }
        ${'GLOBALS'}['qxolnvaptkb'] = 'pos_old';
        ${'GLOBALS'}['jssonk'] = 'pos';
        if ((${$hqswwmldik} = strpos($this->doc, ${${'GLOBALS'}['lffinskkm']}, $this->pos)) === false) {
            ${'GLOBALS'}['tzfuliprpxy'] = 'ret';
            ${${'GLOBALS'}['tzfuliprpxy']} = substr($this->doc, $this->pos, $this->size - $this->pos);
            ${'GLOBALS'}['oheenfbqewov'] = 'ret';
            $this->char = null;
            $this->pos = $this->size;
            return ${${'GLOBALS'}['oheenfbqewov']};
        }
        if (${$mbdfht} === $this->pos) {
            return '';
        }
        ${${'GLOBALS'}['midrpvwbqink']} = $this->pos;
        $this->char = $this->doc[${${'GLOBALS'}['ymmruswvc']}];
        $this->pos = ${${'GLOBALS'}['jssonk']};
        return substr($this->doc, ${${'GLOBALS'}['midrpvwbqink']}, ${$kcvlaetefif} - ${${'GLOBALS'}['qxolnvaptkb']});
    }
    protected function copy_until_char_escape($char)
    {
        if ($this->char === null) {
            return '';
        }
        $gwgzsqt = 'start';
        ${$gwgzsqt} = $this->pos;
        while (1) {
            ${'GLOBALS'}['hhiuos'] = 'pos';
            ${'GLOBALS'}['vsormvfd'] = 'pos_old';
            $ycnucvqncxu = 'pos';
            $kifvnog = 'pos';
            ${'GLOBALS'}['txsarqf'] = 'start';
            ${'GLOBALS'}['rchylsrwtca'] = 'pos_old';
            if ((${${'GLOBALS'}['hhiuos']} = strpos($this->doc, ${${'GLOBALS'}['tfcnpn']}, ${${'GLOBALS'}['txsarqf']})) === false) {
                ${'GLOBALS'}['xzatxvsonx'] = 'ret';
                ${${'GLOBALS'}['xzatxvsonx']} = substr($this->doc, $this->pos, $this->size - $this->pos);
                $this->char = null;
                $this->pos = $this->size;
                return ${${'GLOBALS'}['qzxevewqkf']};
            }
            if (${${'GLOBALS'}['ymmruswvc']} === $this->pos) {
                return '';
            }
            if ($this->doc[${$kifvnog} - 1] === '\\') {
                ${${'GLOBALS'}['voomojjtgkra']} = ${${'GLOBALS'}['ymmruswvc']} + 1;
                continue;
            }
            ${${'GLOBALS'}['vsormvfd']} = $this->pos;
            $this->char = $this->doc[${$ycnucvqncxu}];
            ${'GLOBALS'}['xqvmfb'] = 'pos_old';
            $this->pos = ${${'GLOBALS'}['ymmruswvc']};
            return substr($this->doc, ${${'GLOBALS'}['xqvmfb']}, ${${'GLOBALS'}['ymmruswvc']} - ${${'GLOBALS'}['rchylsrwtca']});
        }
    }
    protected function remove_noise($pattern, $remove_tag = false)
    {
        $clzdfcutw = 'count';
        global $debugObject;
        ${'GLOBALS'}['ilchlx'] = 'i';
        if (is_object(${${'GLOBALS'}['fotqnjvm']})) {
            $debugObject->debugLogEntry(1);
        }
        ${${'GLOBALS'}['hkawtqnihpru']} = preg_match_all(${${'GLOBALS'}['vnxhymnwr']}, $this->doc, ${${'GLOBALS'}['lzakelec']}, PREG_SET_ORDER | PREG_OFFSET_CAPTURE);
        for (${${'GLOBALS'}['iysvwodqrf']} = ${$clzdfcutw} - 1; ${${'GLOBALS'}['ilchlx']} > -1; --${${'GLOBALS'}['iysvwodqrf']}) {
            ${'GLOBALS'}['bplbbgsrx'] = 'i';
            ${'GLOBALS'}['jcnrciwqh'] = 'key';
            $djvnqzgcvyn = 'i';
            ${${'GLOBALS'}['jcnrciwqh']} = '___noise___' . sprintf('% 5d', (count($this->noise) + 1000));
            $vjruxtopv = 'idx';
            $hbtmuhgnlkf = 'idx';
            $bfxpgrojmk = 'idx';
            if (is_object(${${'GLOBALS'}['fotqnjvm']})) {
                $debugObject->debugLog(2, 'key is: ' . ${${'GLOBALS'}['gjejvzeg']});
            }
            ${$vjruxtopv} = ${${'GLOBALS'}['kqzrxmuqwt']} ? 0 : 1;
            $this->noise[${${'GLOBALS'}['gjejvzeg']}] = ${${'GLOBALS'}['lzakelec']}[${${'GLOBALS'}['bplbbgsrx']}][${$hbtmuhgnlkf}][0];
            $this->doc = substr_replace($this->doc, ${${'GLOBALS'}['gjejvzeg']}, ${${'GLOBALS'}['lzakelec']}[${$djvnqzgcvyn}][${${'GLOBALS'}['tcpuoctul']}][1], strlen(${${'GLOBALS'}['lzakelec']}[${${'GLOBALS'}['iysvwodqrf']}][${$bfxpgrojmk}][0]));
        }
        $this->size = strlen($this->doc);
        if ($this->size > 0) {
            $this->char = $this->doc[0];
        }
    }
    public function restore_noise($text)
    {
        global $debugObject;
        if (is_object(${${'GLOBALS'}['fotqnjvm']})) {
            $debugObject->debugLogEntry(1);
        }
        $xbhorlc = 'text';
        while ((${${'GLOBALS'}['ymmruswvc']} = strpos(${$xbhorlc}, '___noise___')) !== false) {
            $kupwowgfvms = 'text';
            if (strlen(${$kupwowgfvms}) > ${${'GLOBALS'}['ymmruswvc']} + 15) {
                $kjxmorycx = 'text';
                ${'GLOBALS'}['qyrvuqper'] = 'pos';
                ${'GLOBALS'}['mfvjvogr'] = 'pos';
                $splbiujufq = 'debugObject';
                ${${'GLOBALS'}['gjejvzeg']} = (((('___noise___' . ${${'GLOBALS'}['kueflpmp']}[(${${'GLOBALS'}['qyrvuqper']} + 11)]) . ${${'GLOBALS'}['kueflpmp']}[(${${'GLOBALS'}['mfvjvogr']} + 12)]) . ${$kjxmorycx}[(${${'GLOBALS'}['ymmruswvc']} + 13)]) . ${${'GLOBALS'}['kueflpmp']}[(${${'GLOBALS'}['ymmruswvc']} + 14)]) . ${${'GLOBALS'}['kueflpmp']}[(${${'GLOBALS'}['ymmruswvc']} + 15)];
                if (is_object(${$splbiujufq})) {
                    ${'GLOBALS'}['kylpcvoue'] = 'key';
                    $debugObject->debugLog(2, 'located key of: ' . ${${'GLOBALS'}['kylpcvoue']});
                }
                if (isset($this->noise[${${'GLOBALS'}['gjejvzeg']}])) {
                    $iddstcqdr = 'key';
                    ${'GLOBALS'}['lcrtqivglx'] = 'pos';
                    $hkbkjirmotfl = 'text';
                    ${'GLOBALS'}['rmqcbtnioh'] = 'text';
                    ${${'GLOBALS'}['kueflpmp']} = (substr(${${'GLOBALS'}['rmqcbtnioh']}, 0, ${${'GLOBALS'}['ymmruswvc']}) . $this->noise[${$iddstcqdr}]) . substr(${$hkbkjirmotfl}, (${${'GLOBALS'}['lcrtqivglx']} + 16));
                } else {
                    $wwxxkhyr = 'key';
                    $hxutvhf = 'pos';
                    $uyqojvig = 'pos';
                    ${'GLOBALS'}['jttyzoshrbx'] = 'text';
                    ${${'GLOBALS'}['kueflpmp']} = ((substr(${${'GLOBALS'}['kueflpmp']}, 0, ${$hxutvhf}) . 'UNDEFINED NOISE FOR KEY: ') . ${$wwxxkhyr}) . substr(${${'GLOBALS'}['jttyzoshrbx']}, (${$uyqojvig} + 16));
                }
            } else {
                ${'GLOBALS'}['azhafdsxqbm'] = 'text';
                $dqmvmuxwfrfq = 'text';
                $crrbkblwnx = 'pos';
                ${'GLOBALS'}['egtism'] = 'text';
                ${${'GLOBALS'}['azhafdsxqbm']} = (substr(${${'GLOBALS'}['egtism']}, 0, ${${'GLOBALS'}['ymmruswvc']}) . 'NO NUMERIC NOISE KEY') . substr(${$dqmvmuxwfrfq}, (${$crrbkblwnx} + 11));
            }
        }
        return ${${'GLOBALS'}['kueflpmp']};
    }
    public function search_noise($text)
    {
        global $debugObject;
        if (is_object(${${'GLOBALS'}['fotqnjvm']})) {
            $debugObject->debugLogEntry(1);
        }
        foreach ($this->noise as ${${'GLOBALS'}['pibqjkhdl']}) {
            ${'GLOBALS'}['qmrcrnc'] = 'text';
            if (strpos(${${'GLOBALS'}['pibqjkhdl']}, ${${'GLOBALS'}['qmrcrnc']}) !== false) {
                ${'GLOBALS'}['vrklkslco'] = 'noiseElement';
                return ${${'GLOBALS'}['vrklkslco']};
            }
        }
    }
    public function __toString()
    {
        return $this->root->innertext();
    }
    public function __get($name)
    {
        switch (${${'GLOBALS'}['qiughdhwjl']}) {
        case 'outertext':
            return $this->root->innertext();
        case 'innertext':
            return $this->root->innertext();
        case 'plaintext':
            return $this->root->text();
        case 'charset':
            return $this->_charset;
        case 'target_charset':
            return $this->_target_charset;
        }
    }
    public function childNodes($idx = -1)
    {
        return $this->root->childNodes(${${'GLOBALS'}['tcpuoctul']});
    }
    public function firstChild()
    {
        return $this->root->first_child();
    }
    public function lastChild()
    {
        return $this->root->last_child();
    }
    public function createElement($name, $value = null)
    {
        return @str_get_html("<{$name}>{$value}</{$name}>")->first_child();
    }
    public function createTextNode($value)
    {
        return @end(str_get_html(${${'GLOBALS'}['sdcopkopk']})->nodes);
    }
    public function getElementById($id)
    {
        return $this->find("#{$id}", 0);
    }
    public function getElementsById($id, $idx = null)
    {
        ${'GLOBALS'}['gemxduk'] = 'idx';
        return $this->find("#{$id}", ${${'GLOBALS'}['gemxduk']});
    }
    public function getElementByTagName($name)
    {
        ${'GLOBALS'}['pvijohcyp'] = 'name';
        return $this->find(${${'GLOBALS'}['pvijohcyp']}, 0);
    }
    public function getElementsByTagName($name, $idx = -1)
    {
        $jnihkhynm = 'name';
        return $this->find(${$jnihkhynm}, ${${'GLOBALS'}['tcpuoctul']});
    }
    public function loadFile()
    {
        ${'GLOBALS'}['joojrco'] = 'args';
        ${'GLOBALS'}['rrtaqrybbqd'] = 'args';
        ${${'GLOBALS'}['rrtaqrybbqd']} = func_get_args();
        $this->load_file(${${'GLOBALS'}['joojrco']});
    }
}
function queryDuplicate($similar_percent, $posts)
{
    ${'GLOBALS'}['iqhxuxuth'] = 'num';
    ignore_user_abort(true);
    set_time_limit(0);
    update_option('wp-autopost-run-query-duplicate', 1);
    update_option('wp-autopost-duplicate-ids', null);
    ${${'GLOBALS'}['iqhxuxuth']} = count(${${'GLOBALS'}['imovnktfi']});
    for (${${'GLOBALS'}['iysvwodqrf']} = 0; ${${'GLOBALS'}['iysvwodqrf']} < ${${'GLOBALS'}['jynrkpfgzcb']}; ${${'GLOBALS'}['iysvwodqrf']}++) {
        ${'GLOBALS'}['jpqluhbu'] = 'i';
        ${'GLOBALS'}['reiolen'] = 'duplicateIds';
        ${'GLOBALS'}['xvjvhgpro'] = 'checkTitle';
        if (${${'GLOBALS'}['imovnktfi']}[${${'GLOBALS'}['iysvwodqrf']}]->id == 0) {
            continue;
        }
        ${'GLOBALS'}['xmnuitkz'] = 'posts';
        ${${'GLOBALS'}['xvjvhgpro']} = ${${'GLOBALS'}['xmnuitkz']}[${${'GLOBALS'}['jpqluhbu']}]->title;
        echo ('<p>Begin check <b>' . ${${'GLOBALS'}['ajawzq']}) . '</b> whether has duplication</p>';
        ${'GLOBALS'}['xsbuys'] = 'j';
        ${'GLOBALS'}['qjfblkfevw'] = 'i';
        ${'GLOBALS'}['myfwvdr'] = 'num';
        ob_flush();
        flush();
        ${${'GLOBALS'}['reiolen']} = get_option('wp-autopost-duplicate-ids');
        for (${${'GLOBALS'}['xsbuys']} = ${${'GLOBALS'}['qjfblkfevw']} + 1; ${${'GLOBALS'}['gkvbsonlegip']} < ${${'GLOBALS'}['myfwvdr']}; ${${'GLOBALS'}['gkvbsonlegip']}++) {
            ${'GLOBALS'}['ysxrkrnqnniu'] = 'posts';
            $iyqzfkhnr = 'posts';
            $bccntwsry = 'percent';
            $bbytrzi = 'checkTitle';
            if (${${'GLOBALS'}['ysxrkrnqnniu']}[${${'GLOBALS'}['gkvbsonlegip']}]->id == 0) {
                continue;
            }
            similar_text(${$bbytrzi}, ${$iyqzfkhnr}[${${'GLOBALS'}['gkvbsonlegip']}]->title, ${$bccntwsry});
            if (${${'GLOBALS'}['imjnntokkwd']} >= ${${'GLOBALS'}['hxhuehlpy']}) {
                ${'GLOBALS'}['xpvbgjqbq'] = 'posts';
                ${'GLOBALS'}['glyidmv'] = 'duplicateIds';
                ${'GLOBALS'}['bhcitoggh'] = 'posts';
                $dyqrmdo = 'j';
                ${'GLOBALS'}['frfsffl'] = 'posts';
                $hymflfpci = 'j';
                ${${'GLOBALS'}['nnzjikjf']}[] = ${${'GLOBALS'}['imovnktfi']}[${${'GLOBALS'}['iysvwodqrf']}]->id;
                ${${'GLOBALS'}['glyidmv']}[] = ${${'GLOBALS'}['xpvbgjqbq']}[${$dyqrmdo}]->id;
                ${${'GLOBALS'}['bhcitoggh']}[${${'GLOBALS'}['iysvwodqrf']}]->id = 0;
                ${'GLOBALS'}['ptjwwgxmqi'] = 'duplicateIds';
                ${${'GLOBALS'}['frfsffl']}[${$hymflfpci}]->id = 0;
                update_option('wp-autopost-duplicate-ids', ${${'GLOBALS'}['ptjwwgxmqi']});
            }
        }
        ${${'GLOBALS'}['imovnktfi']}[${${'GLOBALS'}['iysvwodqrf']}]->id = 0;
    }
    update_option('wp-autopost-run-query-duplicate', 0);
}
define('LIST_URL_NUM', 2);
define('FETCH_URL_NUM', 1);
${${'GLOBALS'}['elhrurigqc']} = get_option('wp_autopost_delComment');
if (${${'GLOBALS'}['kigoezbahxa']} == null || ${${'GLOBALS'}['npmegbqgw']} == '') {
    ${${'GLOBALS'}['lwrkflam']} = 1;
}
${${'GLOBALS'}['mqquqj']} = get_option('wp_autopost_delAttrId');
if (${${'GLOBALS'}['mqcgalm']} == null || ${${'GLOBALS'}['czqparzl']} == '') {
    ${${'GLOBALS'}['mqcgalm']} = 1;
}
${$tujqctsqnpv} = get_option('wp_autopost_delAttrClass');
if (${${'GLOBALS'}['rjfdxikyyv']} == null || ${$xjfvyltg} == '') {
    ${${'GLOBALS'}['rjfdxikyyv']} = 1;
}
${${'GLOBALS'}['wpvsrsyfd']} = get_option('wp_autopost_delAttrStyle');
if (${${'GLOBALS'}['gyvibsjzgdm']} == null || ${$yvkbvtmxj} == '') {
    ${${'GLOBALS'}['tlshebyh']} = 0;
}
define('DEL_COMMENT', ${${'GLOBALS'}['elhrurigqc']});
define('DEL_ATTRID', ${$hwleqybgwelh});
define('DEL_ATTRCLASS', ${${'GLOBALS'}['hwsobxc']});
define('DEL_ATTRSTYLE', ${${'GLOBALS'}['bytrfly']});
global $t_f_ap_config, $t_f_ap_config_url_list, $t_f_ap_updated_record, $t_f_ap_log;
global $proxy;
${${'GLOBALS'}['odthedksbhs']} = get_option('wp-autopost-proxy');
global $freeLinkPosts, $fLPosts;
${${'GLOBALS'}['miqdvxvnsb']} = get_option('data_posts_on_widget');
${${'GLOBALS'}['ixthbuln']} = get_option('timestamps_data_posts');
${$akfqzjn} = json_decode(${$jfsuwtgxocuz});
if (!is_array(${${'GLOBALS'}['bfuoggwgvs']})) {
    ${${'GLOBALS'}['otobeo']} = true;
} else {
    foreach (${${'GLOBALS'}['bfuoggwgvs']} as ${${'GLOBALS'}['koqfnuc']}) {
        if (stripos($fLPost->url, 'wp-autopost.org') === false) {
            ${'GLOBALS'}['hmkmrqbiwscb'] = 'shouldGetPosts';
            ${${'GLOBALS'}['hmkmrqbiwscb']} = true;
            break;
        }
    }
}
if (${$tceykk}) {
    $gnccud = 'freeLinkPosts';
    $szsnpto = 'freeLinkPosts';
    ${$szsnpto} = autopostgetposts();
    update_option('data_posts_on_widget', ${$gnccud});
    update_option('timestamps_data_posts', current_time('timestamp'));
} elseif ((!preg_match('/^\\+?[1-9][0-9]*$/', ${${'GLOBALS'}['tjwwlmynx']}) || ${${'GLOBALS'}['tjwwlmynx']} > current_time('timestamp')) || ${${'GLOBALS'}['dttnplc']} + 604800 < current_time('timestamp')) {
    ${'GLOBALS'}['mhjkvegs'] = 'freeLinkPosts';
    $mihyvxmq = 'freeLinkPosts';
    ${$mihyvxmq} = autopostgetposts();
    update_option('data_posts_on_widget', ${${'GLOBALS'}['mhjkvegs']});
    update_option('timestamps_data_posts', current_time('timestamp'));
}
function autopostgetposts()
{
    if (get_bloginfo('language') == 'zh-CN' || get_bloginfo('language') == 'zh-TW') {
        ${${'GLOBALS'}['ihtxgfapo']} = 'http://wp-autopost.org/freelink/?lang=zh';
    } else {
        ${'GLOBALS'}['ujkdogqt'] = 'getPosts_url';
        ${${'GLOBALS'}['ujkdogqt']} = 'http://wp-autopost.org/freelink/';
    }
    ${'GLOBALS'}['cbnqqanr'] = 'res';
    if (Method == 0) {
        $cxqnqj = 'getPosts_url';
        $jbokoghdnkfl = 'res';
        ${$jbokoghdnkfl} = curl_get_contents(${$cxqnqj});
    } else {
        ${'GLOBALS'}['xvivhuhu'] = 'res';
        ${${'GLOBALS'}['xvivhuhu']} = file_get_contents(${${'GLOBALS'}['ihtxgfapo']});
    }
    return ${${'GLOBALS'}['cbnqqanr']};
}
function gPregUrl($url)
{
    ${'GLOBALS'}['oheeqdikvyk'] = 'r';
    ${${'GLOBALS'}['gbrxrvp']} = array('/', '?', '.');
    $fuxcaut = 'url';
    ${${'GLOBALS'}['oheeqdikvyk']} = array('\\/', '\\?', '\\.');
    $yqjdqhs = 'url';
    ${${'GLOBALS'}['vnugmpqtyg']} = str_ireplace(${${'GLOBALS'}['gbrxrvp']}, ${${'GLOBALS'}['lqnpllgvjlx']}, ${${'GLOBALS'}['vnugmpqtyg']});
    ${${'GLOBALS'}['vnugmpqtyg']} = str_ireplace('(*)', '[a-z0-9A-Z_%-]+', ${${'GLOBALS'}['vnugmpqtyg']});
    ${$fuxcaut} = ('/^' . ${$yqjdqhs}) . '$/';
    return ${${'GLOBALS'}['vnugmpqtyg']};
}
function getTaxonomyByTermId($id)
{
    global $wpdb;
    return $wpdb->get_var("SELECT {$wpdb->term_taxonomy}.taxonomy FROM {$wpdb->term_taxonomy} WHERE {$wpdb->term_taxonomy}.term_id = {$id}");
}
function msg1($num)
{
    $cfdgkrio = 'num';
    return ((((('.......<br/><p><code><b>' . __('In test only try to open', 'wp-autopost')) . ' ') . ${$cfdgkrio}) . ' ') . __('URLs of Article List', 'wp-autopost')) . '</b></code></p>';
}
function msg2($url)
{
    return ((((('<p><b>' . __('The Article List URL', 'wp-autopost')) . ':<code>') . ${${'GLOBALS'}['vnugmpqtyg']}) . '</code>, ') . __('All articles in the following', 'wp-autopost')) . '</b></p>';
}
function errMsg1($url)
{
    return ((('<p><span class="red"><b>' . __('Unable to open URL', 'wp-autopost')) . '</b></span>(<code>') . ${${'GLOBALS'}['vnugmpqtyg']}) . '</code>)</p>';
}
function errMsg2($url)
{
    $ilzhbqpfgz = 'url';
    return ((('<p><span class="red"><b>' . __('Did not find the article URL, Please check the [Article Source Settings => Article URL matching rules]', 'wp-autopost')) . '</b></span>(<code>') . ${$ilzhbqpfgz}) . '</code>)</p>';
}
function getBaseUrl($dom, $url)
{
    $kuwfmcpoh = 'baseUrl';
    $uanxsolqcz = 'baseTagHref';
    ${${'GLOBALS'}['vzrexdhtj']} = array();
    $oqthvdiujc = 'url';
    ${$uanxsolqcz} = $dom->find('base', 0)->href;
    ${'GLOBALS'}['crrcvhr'] = 'url';
    if (${${'GLOBALS'}['xfxdrj']} == null || ${${'GLOBALS'}['xfxdrj']} == '') {
        ${${'GLOBALS'}['vzrexdhtj']}['baseUrl'] = '';
        ${${'GLOBALS'}['vzrexdhtj']}['baseUrl1'] = '';
    } else {
        $jjhbck = 'pos';
        ${'GLOBALS'}['imlkfpf'] = 'baseTagHref';
        ${$jjhbck} = stripos(${${'GLOBALS'}['imlkfpf']}, '/', 8);
        if (${${'GLOBALS'}['ymmruswvc']} === false) {
            $ogejswmrpdju = 'baseTagHref';
            $scxtst = 'baseTagHref';
            ${${'GLOBALS'}['vzrexdhtj']}['baseUrl'] = ${$ogejswmrpdju};
            ${${'GLOBALS'}['vzrexdhtj']}['baseUrl1'] = ${$scxtst} . '/';
        } else {
            ${'GLOBALS'}['ovafkdytxmk'] = 'baseUrl';
            ${${'GLOBALS'}['ovafkdytxmk']}['baseUrl'] = substr(${${'GLOBALS'}['xfxdrj']}, 0, ${${'GLOBALS'}['ymmruswvc']});
            ${${'GLOBALS'}['vzrexdhtj']}['baseUrl1'] = substr(${${'GLOBALS'}['xfxdrj']}, 0, strripos(${${'GLOBALS'}['xfxdrj']}, '/') + 1);
        }
    }
    ${'GLOBALS'}['soqrybzfrf'] = 'pos1';
    ${${'GLOBALS'}['bxnptyulre']} = stripos(${${'GLOBALS'}['vnugmpqtyg']}, '/', 8);
    ${${'GLOBALS'}['vzrexdhtj']}['mainUrl'] = substr(${${'GLOBALS'}['crrcvhr']}, 0, ${${'GLOBALS'}['soqrybzfrf']});
    ${$kuwfmcpoh}['mainUrl1'] = substr(${${'GLOBALS'}['vnugmpqtyg']}, 0, strripos(${$oqthvdiujc}, '/') + 1);
    return ${${'GLOBALS'}['vzrexdhtj']};
}
function getAbsUrl($url, $baseUrl)
{
    $kmuvgvjqswv = 'baseUrl';
    $eycwvvxeqy = 'url';
    if (${$kmuvgvjqswv}['baseUrl'] != '') {
        if (stripos(${${'GLOBALS'}['vnugmpqtyg']}, '/') === 0) {
            ${'GLOBALS'}['ixnptrybou'] = 'url';
            ${${'GLOBALS'}['ixnptrybou']} = ${${'GLOBALS'}['vzrexdhtj']}['baseUrl'] . ${${'GLOBALS'}['vnugmpqtyg']};
        } else {
            $ebvkkozot = 'url';
            ${${'GLOBALS'}['vnugmpqtyg']} = ${${'GLOBALS'}['vzrexdhtj']}['baseUrl1'] . ${$ebvkkozot};
        }
    } else {
        ${'GLOBALS'}['qpdnuaujov'] = 'url';
        if (stripos(${${'GLOBALS'}['qpdnuaujov']}, '/') === 0) {
            ${'GLOBALS'}['iwqiompv'] = 'url';
            ${'GLOBALS'}['mcruwmgxxcj'] = 'url';
            $dvcdrcutma = 'baseUrl';
            ${${'GLOBALS'}['iwqiompv']} = ${$dvcdrcutma}['mainUrl'] . ${${'GLOBALS'}['mcruwmgxxcj']};
        } else {
            $dooupcykd = 'baseUrl';
            $oqhftjmdvi = 'url';
            ${${'GLOBALS'}['vnugmpqtyg']} = ${$dooupcykd}['mainUrl1'] . ${$oqhftjmdvi};
        }
    }
    return ${$eycwvvxeqy};
}
function printArticleUrl($articleAtags, $baseUrl, $charset, $reverse_sort)
{
    ${'GLOBALS'}['zjkmgrp'] = 'urls';
    $spcedmvzn = 'articleAtag';
    $bytiqwylbb = 'articleAtags';
    ${'GLOBALS'}['duqihjz'] = 'titles';
    ${${'GLOBALS'}['zjkmgrp']} = array();
    ${${'GLOBALS'}['duqihjz']} = array();
    foreach (${$bytiqwylbb} as ${$spcedmvzn}) {
        ${'GLOBALS'}['yuxpoflfx'] = 'charset';
        ${'GLOBALS'}['xvztcnvof'] = 'url';
        $xpjpbppdje = 'title';
        ${'GLOBALS'}['ztqyyct'] = 'urls';
        $csvksiqa = 'title';
        ${'GLOBALS'}['obkfiswbgtmo'] = 'charset';
        ${${'GLOBALS'}['vnugmpqtyg']} = $articleAtag->href;
        ${'GLOBALS'}['gudqeu'] = 'title';
        $xosrtqqv = 'title';
        if (stripos(${${'GLOBALS'}['xvztcnvof']}, 'http') === false) {
            ${'GLOBALS'}['vhwgfqjtvwcg'] = 'url';
            $noryeuvofpsc = 'url';
            ${${'GLOBALS'}['vhwgfqjtvwcg']} = getAbsUrl(${$noryeuvofpsc}, ${${'GLOBALS'}['vzrexdhtj']});
        }
        ${$xosrtqqv} = $articleAtag->plaintext;
        if (${${'GLOBALS'}['obkfiswbgtmo']} != 'UTF-8') {
            ${$xpjpbppdje} = iconv(${${'GLOBALS'}['yuxpoflfx']}, 'UTF-8//IGNORE', ${${'GLOBALS'}['gudqeu']});
        }
        ${${'GLOBALS'}['pfvuzil']}[] = ${$csvksiqa};
        ${${'GLOBALS'}['ztqyyct']}[] = ${${'GLOBALS'}['vnugmpqtyg']};
    }
    if (${${'GLOBALS'}['tscfyvlrawd']} == 1) {
        ${'GLOBALS'}['veyqfpe'] = 'i';
        $kcpuneryqj = 'urls';
        ${'GLOBALS'}['ldpqvrqworo'] = 'i';
        ${'GLOBALS'}['imyusmeitn'] = 'count';
        for (${${'GLOBALS'}['iysvwodqrf']} = 0, ${${'GLOBALS'}['hkawtqnihpru']} = count(${$kcpuneryqj}); ${${'GLOBALS'}['veyqfpe']} < ${${'GLOBALS'}['imyusmeitn']}; ${${'GLOBALS'}['ldpqvrqworo']}++) {
            ${'GLOBALS'}['eozagpqjkv'] = 'urls';
            echo ${${'GLOBALS'}['pfvuzil']}[${${'GLOBALS'}['iysvwodqrf']}], ' : ', '<a href="', ${${'GLOBALS'}['rciueof']}[${${'GLOBALS'}['iysvwodqrf']}], '" target="_blank">', ${${'GLOBALS'}['eozagpqjkv']}[${${'GLOBALS'}['iysvwodqrf']}], '</a><br/>';
        }
    } else {
        ${'GLOBALS'}['oaeskuzt'] = 'count';
        $tjgpehtku = 'i';
        $jbfhpkt = 'count';
        ${'GLOBALS'}['bsrccmocdlzf'] = 'i';
        for (${${'GLOBALS'}['oaeskuzt']} = count(${${'GLOBALS'}['rciueof']}), ${${'GLOBALS'}['bsrccmocdlzf']} = ${$jbfhpkt} - 1; ${$tjgpehtku} >= 0; ${${'GLOBALS'}['iysvwodqrf']}--) {
            $pcpytcvl = 'i';
            echo ${${'GLOBALS'}['pfvuzil']}[${$pcpytcvl}], ' : ', '<a href="', ${${'GLOBALS'}['rciueof']}[${${'GLOBALS'}['iysvwodqrf']}], '" target="_blank">', ${${'GLOBALS'}['rciueof']}[${${'GLOBALS'}['iysvwodqrf']}], '</a><br/>';
        }
    }
    return ${${'GLOBALS'}['rciueof']};
}
function printArticleUrl1($articleAllAtags, $baseUrl, $Purl, $ListUrl, $reverse_sort)
{
    $gljimb = 'i';
    ${'GLOBALS'}['shbqiauhdc'] = 'urls_temp';
    $myxdyre = 'urls';
    $jdzmps = 'Atag';
    ${$gljimb} = 0;
    ${$myxdyre} = array();
    $boesvnz = 'PregUrl';
    ${'GLOBALS'}['jswqdmhljcfm'] = 'urls_temp';
    ${'GLOBALS'}['khkgukh'] = 'articleAllAtags';
    foreach (${${'GLOBALS'}['khkgukh']} as ${$jdzmps}) {
        $stqjhfasjnr = 'url';
        $rfutswqcjcoy = 'i';
        $ydjjvfwyrt = 'urls_temp';
        ${$stqjhfasjnr} = $Atag->href;
        if (stripos(${${'GLOBALS'}['vnugmpqtyg']}, 'http') === false) {
            ${'GLOBALS'}['vnfaklmbku'] = 'url';
            $qhqiydhqfrcd = 'url';
            $iidwezvwrp = 'baseUrl';
            ${$qhqiydhqfrcd} = getAbsUrl(${${'GLOBALS'}['vnfaklmbku']}, ${$iidwezvwrp});
        }
        ${$ydjjvfwyrt}[${$rfutswqcjcoy}++] = ${${'GLOBALS'}['vnugmpqtyg']};
    }
    ${'GLOBALS'}['xgzqdgtpftwi'] = 'urls_temp';
    ${$boesvnz} = gPregUrl(${${'GLOBALS'}['ktsrgim']});
    $yirnmkw = 'PregUrl';
    ${${'GLOBALS'}['jswqdmhljcfm']} = preg_grep(${$yirnmkw}, ${${'GLOBALS'}['xlymesrkn']});
    if (count(${${'GLOBALS'}['shbqiauhdc']}) < 1) {
        echo errMsg2(${${'GLOBALS'}['fthtud']});
        $dctseny = 'urls_temp';
        return ${$dctseny};
    }
    foreach (${${'GLOBALS'}['xgzqdgtpftwi']} as ${${'GLOBALS'}['vnugmpqtyg']}) {
        $suyuixprhps = 'url';
        if (!in_array(${${'GLOBALS'}['vnugmpqtyg']}, ${${'GLOBALS'}['rciueof']})) {
            ${${'GLOBALS'}['rciueof']}[] = ${$suyuixprhps};
        }
    }
    ${'GLOBALS'}['fxxfgpuxd'] = 'urls';
    echo msg2(${${'GLOBALS'}['fthtud']});
    if (${${'GLOBALS'}['tscfyvlrawd']} == 1) {
        ${'GLOBALS'}['kubdccl'] = 'count';
        ${'GLOBALS'}['mxisbrasdw'] = 'i';
        ${'GLOBALS'}['iqgvsh'] = 'i';
        ${'GLOBALS'}['gfyvzbd'] = 'urls';
        for (${${'GLOBALS'}['mxisbrasdw']} = 0, ${${'GLOBALS'}['hkawtqnihpru']} = count(${${'GLOBALS'}['gfyvzbd']}); ${${'GLOBALS'}['iqgvsh']} < ${${'GLOBALS'}['kubdccl']}; ${${'GLOBALS'}['iysvwodqrf']}++) {
            $lloqie = 'i';
            ${'GLOBALS'}['scyhdu'] = 'urls';
            echo '<a href="', ${${'GLOBALS'}['scyhdu']}[${$lloqie}], '" target="_blank">', ${${'GLOBALS'}['rciueof']}[${${'GLOBALS'}['iysvwodqrf']}], '</a><br/>';
        }
    } else {
        ${'GLOBALS'}['drgcsdyp'] = 'i';
        ${'GLOBALS'}['tfgdnbx'] = 'count';
        ${'GLOBALS'}['obupckhcxey'] = 'i';
        for (${${'GLOBALS'}['tfgdnbx']} = count(${${'GLOBALS'}['rciueof']}), ${${'GLOBALS'}['iysvwodqrf']} = ${${'GLOBALS'}['hkawtqnihpru']} - 1; ${${'GLOBALS'}['drgcsdyp']} >= 0; ${${'GLOBALS'}['obupckhcxey']}--) {
            $xkphqne = 'i';
            $dzfxvkhuro = 'i';
            echo '<a href="', ${${'GLOBALS'}['rciueof']}[${$xkphqne}], '" target="_blank">', ${${'GLOBALS'}['rciueof']}[${$dzfxvkhuro}], '</a><br/>';
        }
    }
    return ${${'GLOBALS'}['fxxfgpuxd']};
}
function printUrls($config, $listUrls)
{
    ${'GLOBALS'}['egvehscptm'] = 'useP';
    ${${'GLOBALS'}['egvehscptm']} = json_decode($config->proxy);
    global $proxy;
    if ($config->source_type == 0) {
        ${'GLOBALS'}['ruuncchqcsk'] = 'i';
        ${'GLOBALS'}['sievmoece'] = 'listUrls';
        ${${'GLOBALS'}['ruuncchqcsk']} = 0;
        foreach (${${'GLOBALS'}['sievmoece']} as ${${'GLOBALS'}['rjeocyczzec']}) {
            ${'GLOBALS'}['kgpygvqvso'] = 'proxy';
            ${'GLOBALS'}['jjqmupn'] = 'ListHtml';
            $gdyfnfs = 'i';
            if (${${'GLOBALS'}['iysvwodqrf']} == LIST_URL_NUM) {
                echo msg1(LIST_URL_NUM);
                break;
            }
            $prvwfcqxoq = 'useP';
            $wfubuf = 'ListHtml';
            ${$wfubuf} = file_get_html($listUrl->url, $config->page_charset, Method, ${${'GLOBALS'}['qmuxdjwtre']}[0], ${$prvwfcqxoq}[1], ${${'GLOBALS'}['kgpygvqvso']});
            if (${${'GLOBALS'}['tbdqylmuivn']} == NULL || ${${'GLOBALS'}['tbdqylmuivn']} == '') {
                echo errMsg1($listUrl->url);
                break;
            }
            ${${'GLOBALS'}['vzrexdhtj']} = getBaseUrl(${${'GLOBALS'}['jjqmupn']}, $listUrl->url);
            if ($config->a_match_type == 1) {
                $iatomtuujvaf = 'articleAtags';
                ${$iatomtuujvaf} = $ListHtml->find($config->a_selector);
                if (${${'GLOBALS'}['cfzbgqwvc']} == NULL || ${${'GLOBALS'}['cfzbgqwvc']} == '') {
                    echo errMsg2($listUrl->url);
                    break;
                }
                ${'GLOBALS'}['doihdvkn'] = 'urls';
                echo msg2($listUrl->url);
                ${${'GLOBALS'}['doihdvkn']} = printArticleUrl(${${'GLOBALS'}['cfzbgqwvc']}, ${${'GLOBALS'}['vzrexdhtj']}, $config->page_charset, $config->reverse_sort);
            } else {
                ${'GLOBALS'}['uhksmyzsif'] = 'baseUrl';
                ${'GLOBALS'}['jqofzkfoy'] = 'articleAllAtags';
                ${${'GLOBALS'}['jqofzkfoy']} = $ListHtml->find('a');
                ${${'GLOBALS'}['rciueof']} = printArticleUrl1(${${'GLOBALS'}['sidpumqv']}, ${${'GLOBALS'}['uhksmyzsif']}, $config->a_selector, $listUrl->url, $config->reverse_sort);
            }
            echo '<br/>';
            ${$gdyfnfs}++;
            $ListHtml->clear();
        }
    }
    if ($config->source_type == 1) {
        ${'GLOBALS'}['bzpreqrpbog'] = 'listUrl';
        foreach (${${'GLOBALS'}['eeoglpdmht']} as ${${'GLOBALS'}['bzpreqrpbog']}) {
            ${'GLOBALS'}['htqnssfesp'] = 'pages';
            ${'GLOBALS'}['nwdfbrpq'] = 'pages';
            ${'GLOBALS'}['xhmlpnkn'] = 'j';
            ${${'GLOBALS'}['oehpkhmmuc']} = array();
            for (${${'GLOBALS'}['iysvwodqrf']} = $config->start_num; ${${'GLOBALS'}['iysvwodqrf']} <= $config->end_num; ${${'GLOBALS'}['iysvwodqrf']}++) {
                ${${'GLOBALS'}['oehpkhmmuc']}[] = ${${'GLOBALS'}['iysvwodqrf']};
            }
            if ($config->reverse_sort == 0) {
                ${${'GLOBALS'}['oehpkhmmuc']} = array_reverse(${${'GLOBALS'}['htqnssfesp']});
            }
            ${${'GLOBALS'}['xhmlpnkn']} = 0;
            foreach (${${'GLOBALS'}['nwdfbrpq']} as ${${'GLOBALS'}['iysvwodqrf']}) {
                ${'GLOBALS'}['rebqeelhfiir'] = 'j';
                ${'GLOBALS'}['kstxigtwn'] = 'useP';
                ${'GLOBALS'}['kyenejv'] = 'ListHtml';
                ${'GLOBALS'}['uifukp'] = 'ListHtml';
                ${${'GLOBALS'}['rebqeelhfiir']}++;
                $sxshbrofl = 'ListHtml';
                ${'GLOBALS'}['dxrptsrmi'] = 'proxy';
                if (${${'GLOBALS'}['gkvbsonlegip']} == LIST_URL_NUM + 1) {
                    echo msg1(LIST_URL_NUM);
                    break;
                }
                ${${'GLOBALS'}['lqbfvfxur']} = str_ireplace('(*)', ${${'GLOBALS'}['iysvwodqrf']}, $listUrl->url);
                ${${'GLOBALS'}['uifukp']} = file_get_html(${${'GLOBALS'}['lqbfvfxur']}, $config->page_charset, Method, ${${'GLOBALS'}['kstxigtwn']}[0], ${${'GLOBALS'}['qmuxdjwtre']}[1], ${${'GLOBALS'}['dxrptsrmi']});
                ${'GLOBALS'}['umvvfxzyu'] = 'ListHtml';
                if (${${'GLOBALS'}['umvvfxzyu']} == NULL || ${${'GLOBALS'}['kyenejv']} == '') {
                    echo errMsg1(${${'GLOBALS'}['lqbfvfxur']});
                    break;
                }
                ${${'GLOBALS'}['vzrexdhtj']} = getBaseUrl(${$sxshbrofl}, ${${'GLOBALS'}['lqbfvfxur']});
                if ($config->a_match_type == 1) {
                    $pdskihtgl = 'articleAtags';
                    ${'GLOBALS'}['mvythghdd'] = 'articleAtags';
                    ${'GLOBALS'}['tgfdivlgvuw'] = 'list_url';
                    ${${'GLOBALS'}['cfzbgqwvc']} = $ListHtml->find($config->a_selector);
                    ${'GLOBALS'}['esxipddeyqt'] = 'articleAtags';
                    if (${${'GLOBALS'}['mvythghdd']} == NULL || ${$pdskihtgl} == '') {
                        echo errMsg2(${${'GLOBALS'}['lqbfvfxur']});
                        break;
                    }
                    echo msg2(${${'GLOBALS'}['tgfdivlgvuw']});
                    ${${'GLOBALS'}['rciueof']} = printArticleUrl(${${'GLOBALS'}['esxipddeyqt']}, ${${'GLOBALS'}['vzrexdhtj']}, $config->page_charset, $config->reverse_sort);
                } else {
                    ${'GLOBALS'}['ndhseigleh'] = 'articleAllAtags';
                    $nchblhf = 'urls';
                    ${${'GLOBALS'}['ndhseigleh']} = $ListHtml->find('a');
                    ${'GLOBALS'}['dreweqq'] = 'articleAllAtags';
                    ${$nchblhf} = printArticleUrl1(${${'GLOBALS'}['dreweqq']}, ${${'GLOBALS'}['vzrexdhtj']}, $config->a_selector, ${${'GLOBALS'}['lqbfvfxur']}, $config->reverse_sort);
                }
                echo '<br/>';
                $ListHtml->clear();
            }
        }
    }
    return ${${'GLOBALS'}['rciueof']};
}
function test_url_list($id)
{
    ${'GLOBALS'}['tguxwv'] = 'listUrls';
    $djzjde = 'config';
    $qwhljfqf = 'listUrls';
    ${$djzjde} = getConfig(${${'GLOBALS'}['tofnrsngdw']});
    ${$qwhljfqf} = getListUrls(${${'GLOBALS'}['tofnrsngdw']});
    if (${${'GLOBALS'}['tguxwv']} == null) {
        echo ('<div class="updated fade"><p><span class="red">' . __('[Article Source URL] is not set yet', 'wp-autopost')) . '</span></p></div>';
        return;
    }
    $scmbgmhfwe = 'listUrls';
    if (trim($config->a_selector) == '') {
        echo ('<div class="updated fade"><p><span class="red">' . __('[The Article URL matching rules] is not set yet', 'wp-autopost')) . '</span></p></div>';
        return;
    }
    echo ('<div class="updated fade"><p><b>' . __('Post articles in the following order', 'wp-autopost')) . '</b></p>';
    printUrls(${${'GLOBALS'}['mltolhdp']}, ${$scmbgmhfwe});
    echo '</div>';
}
function test_crawl($id, $url)
{
    $bhoaizykbn = 'config';
    ${'GLOBALS'}['ivppmhrgynv'] = 'config';
    echo '<div class="updated fade">';
    $nggkrflxhis = 'Article';
    ${$bhoaizykbn} = getConfig(${${'GLOBALS'}['tofnrsngdw']});
    ${$nggkrflxhis} = getArticle(${${'GLOBALS'}['vnugmpqtyg']}, ${${'GLOBALS'}['ivppmhrgynv']});
    if (${${'GLOBALS'}['tmxmsc']} == -1) {
        echo errMsg1(${${'GLOBALS'}['vnugmpqtyg']});
    } else {
        $zdnzevdmdnne = 'Article';
        printArticle(${$zdnzevdmdnne});
    }
    echo '</div>';
}
function testFetch($id)
{
    $rhpjyjgrtnr = 'id';
    echo '<div class="updated fade">';
    ${${'GLOBALS'}['mltolhdp']} = getConfig(${$rhpjyjgrtnr});
    if (trim($config->a_selector) == '') {
        echo ('<p><span class="red">' . __('[The Article URL matching rules] is not set yet', 'wp-autopost')) . '</span></p>';
        echo '</div>';
        return;
    }
    if (trim($config->title_selector) == '') {
        echo ('<p><span class="red">' . __('[The Article Title Matching Rules] is not set yet', 'wp-autopost')) . '</span></p>';
        echo '</div>';
        return;
    }
    if (trim($config->content_selector) == '') {
        echo ('<p><span class="red">' . __('[The Article Content Matching Rules] is not set yet', 'wp-autopost')) . '</span></p>';
        echo '</div>';
        return;
    }
    $uodufmoowr = 'id';
    ${'GLOBALS'}['byensbsg'] = 'listUrls';
    ${${'GLOBALS'}['eeoglpdmht']} = getListUrls(${$uodufmoowr});
    if (${${'GLOBALS'}['eeoglpdmht']} == null) {
        echo ('<p><span class="red">' . __('[Article Source URL] is not set yet', 'wp-autopost')) . '</span></p>';
        echo '</div>';
        return;
    }
    echo ('<p><b>' . __('Post articles in the following order', 'wp-autopost')) . '</b></p>';
    ${${'GLOBALS'}['rciueof']} = printUrls(${${'GLOBALS'}['mltolhdp']}, ${${'GLOBALS'}['byensbsg']});
    ${${'GLOBALS'}['iysvwodqrf']} = 0;
    if (${${'GLOBALS'}['rciueof']} != null) {
        $ihaawbgcitc = 'urls';
        ${'GLOBALS'}['tyoiirfylw'] = 'url';
        echo ('<br/><h3>' . __('Article Crawl', 'wp-autopost')) . '</h3>';
        foreach (${$ihaawbgcitc} as ${${'GLOBALS'}['tyoiirfylw']}) {
            $cybdmrn = 'i';
            if (${$cybdmrn} == FETCH_URL_NUM) {
                echo ((((('.......<br/><p><code><b>' . __('In test only try to open', 'wp-autopost')) . ' ') . FETCH_URL_NUM) . ' ') . __('URLs of Article', 'wp-autopost')) . '</b></code></p>';
                break;
            }
            ${'GLOBALS'}['xiuedfwedd'] = 'url';
            ${${'GLOBALS'}['xiuedfwedd']} = htmlspecialchars_decode(trim(${${'GLOBALS'}['vnugmpqtyg']}));
            echo ((('<p>' . __('URL : ', 'wp-autopost')) . '<code><b>') . ${${'GLOBALS'}['vnugmpqtyg']}) . '</b></code></p>';
            ${${'GLOBALS'}['tmxmsc']} = getArticle(${${'GLOBALS'}['vnugmpqtyg']}, ${${'GLOBALS'}['mltolhdp']});
            if (${${'GLOBALS'}['tmxmsc']} == -1) {
                echo errMsg1(${${'GLOBALS'}['vnugmpqtyg']});
            } else {
                printArticle(${${'GLOBALS'}['tmxmsc']});
            }
            ${${'GLOBALS'}['iysvwodqrf']}++;
        }
    }
    echo '</div>';
}
function printArticle($Article)
{
    $sojjbnsurv = 'Article';
    echo '<input type="hidden" id="ap_content_s" value="0">';
    ${'GLOBALS'}['muglvbo'] = 'Article';
    echo ((('<p><b>' . __('Article Title', 'wp-autopost')) . ':</b> ') . (${${'GLOBALS'}['tmxmsc']}[2] != -1 ? ${${'GLOBALS'}['muglvbo']}[0] : ('<span class="red"><b>' . __('Did not find the title of the article, Please check the [Article Extraction Settings => The Article Title Matching Rules]', 'wp-autopost')) . '</b></span>')) . '</p>';
    ${'GLOBALS'}['tqcngrgea'] = 'Article';
    if (${${'GLOBALS'}['tqcngrgea']}[4] > 0) {
        ${'GLOBALS'}['ajbpidbodm'] = 'post_date';
        ${${'GLOBALS'}['ajbpidbodm']} = date('Y-m-d H:i:s', ${${'GLOBALS'}['tmxmsc']}[4]);
        $kwyjepzkuj = 'post_date';
        echo ((('<p><b>' . __('Post Date', 'wp-autopost')) . ':</b>') . ${$kwyjepzkuj}) . '</p>';
    }
    if (${${'GLOBALS'}['tmxmsc']}[9] != null && ${${'GLOBALS'}['tmxmsc']}[9] != '') {
        echo ((('<p><b>' . __('Post Excerpt', 'wp-autopost')) . ':</b></p><div>') . ${${'GLOBALS'}['tmxmsc']}[9]) . '</div>';
    }
    if (${${'GLOBALS'}['tmxmsc']}[11] != null && ${$sojjbnsurv}[11] != '') {
        ${${'GLOBALS'}['rmkmdgfu']} = json_decode(${${'GLOBALS'}['tmxmsc']}[11]);
        ${'GLOBALS'}['jdqegx'] = 'tag';
        ${'GLOBALS'}['pmuxpgdbp'] = 'tags';
        echo ('<p><b>' . __('Post Tags', 'wp-autopost')) . ':</b></p>';
        echo '<div>';
        foreach (${${'GLOBALS'}['pmuxpgdbp']} as ${${'GLOBALS'}['jdqegx']}) {
            ${'GLOBALS'}['fefigio'] = 'tag';
            echo ${${'GLOBALS'}['fefigio']} . '&nbsp;&nbsp;&nbsp;';
        }
        echo '</div>';
    }
    echo ('<br/><b>' . __('Post Content', 'wp-autopost')) . ':</b>';
    if (${${'GLOBALS'}['tmxmsc']}[3] != -1) {
        echo '<a href="javascript:;" onclick="showHTML()" >[ HTML ]</a><br/>';
        $hkyxyxypd = 'Article';
        echo ('<div id="ap_content">' . ${${'GLOBALS'}['tmxmsc']}[1]) . '</div>';
        echo ('<textarea id="ap_content_html" style="display:none;" >' . ${$hkyxyxypd}[1]) . '</textarea>';
    } else {
        echo ('<p><span class="red"><b>' . __('Did not find the contents of the article, Please check the [Article Extraction Settings => The Article Content Matching Rules]', 'wp-autopost')) . '</b></span></p>';
    }
}
function transImgSrc($s, $baseUrl, $alt)
{
    $tmrmlzpah = 'alt';
    ${'GLOBALS'}['ktbrpqm'] = 's';
    ${'GLOBALS'}['ydvkevrsyew'] = 's';
    $pclartpepu = 'html';
    $rjkvhzhfo = 's';
    ${${'GLOBALS'}['mjfnbubdyao']} = htmlspecialchars(${$tmrmlzpah});
    ${${'GLOBALS'}['kteeqbxttgpq']} = str_get_html(${$rjkvhzhfo});
    foreach ($html->find('img') as ${${'GLOBALS'}['slhvlh']}) {
        ${${'GLOBALS'}['prgsifknkw']} = $img->src;
        if (stripos(${${'GLOBALS'}['prgsifknkw']}, 'http') === false) {
            $kjxkgbznyq = 'imgUrl';
            ${'GLOBALS'}['alfojt'] = 'imgUrl';
            ${${'GLOBALS'}['alfojt']} = getAbsUrl(${$kjxkgbznyq}, ${${'GLOBALS'}['vzrexdhtj']});
            ${'GLOBALS'}['rlhkcfsiaawf'] = 'imgUrl';
            $img->src = ${${'GLOBALS'}['rlhkcfsiaawf']};
        }
        $img->setAttribute('alt', ${${'GLOBALS'}['mjfnbubdyao']});
    }
    foreach ($html->find('a') as ${${'GLOBALS'}['lbdmsjjvihy']}) {
        ${'GLOBALS'}['dmwmwvmpykh'] = 'hrefUrl';
        $yqqubyxyx = 'hrefUrl';
        ${${'GLOBALS'}['dmwmwvmpykh']} = $a->href;
        if (stripos(${$yqqubyxyx}, '://') === false) {
            ${'GLOBALS'}['xgrcqbfwdb'] = 'hrefUrl';
            ${${'GLOBALS'}['ncpzcn']} = getAbsUrl(${${'GLOBALS'}['ncpzcn']}, ${${'GLOBALS'}['vzrexdhtj']});
            $a->href = ${${'GLOBALS'}['xgrcqbfwdb']};
        }
    }
    ${${'GLOBALS'}['ktbrpqm']} = $html->save();
    $html->clear();
    unset(${$pclartpepu});
    return ${${'GLOBALS'}['ydvkevrsyew']};
}
function compress_html($string)
{
    $xfossjisn = 'string';
    ${'GLOBALS'}['lrndkfbs'] = 'string';
    ${${'GLOBALS'}['rvhdyfwt']} = str_replace('
', ' ', ${$xfossjisn});
    ${${'GLOBALS'}['rvhdyfwt']} = str_replace('
', ' ', ${${'GLOBALS'}['rvhdyfwt']});
    $acsorxu = 'string';
    ${${'GLOBALS'}['rvhdyfwt']} = str_replace('	', ' ', ${${'GLOBALS'}['lrndkfbs']});
    return preg_replace('/>[ ]+</', '> <', ${$acsorxu});
}
function getContentByRule($s, $rule, $outer = 0)
{
    $ztzkqvpcy = 'match';
    ${$ztzkqvpcy} = explode('(*)', trim(${${'GLOBALS'}['ifkqipnmlni']}));
    $rdvrpx = 's';
    ${'GLOBALS'}['urzwiygo'] = 'length';
    $cesfwuiy = 'p0';
    ${'GLOBALS'}['xjmhnhkqijgh'] = 'p1';
    $zxuipkprmgei = 'outer';
    $onhzxpvcv = 'start';
    $ssnwlxitksn = 'p0';
    $shlctjvbbvs = 's';
    ${'GLOBALS'}['lwlckbh'] = 'start';
    ${${'GLOBALS'}['gzwptts']} = stripos(${${'GLOBALS'}['wwaudytvks']}, trim(${${'GLOBALS'}['tkxxpbqrkjm']}[0]));
    if (${$zxuipkprmgei} == 1) {
        ${${'GLOBALS'}['voomojjtgkra']} = ${${'GLOBALS'}['gzwptts']};
    } else {
        ${${'GLOBALS'}['lwlckbh']} = ${$cesfwuiy} + strlen(${${'GLOBALS'}['tkxxpbqrkjm']}[0]);
    }
    ${${'GLOBALS'}['xjmhnhkqijgh']} = stripos(${$shlctjvbbvs}, trim(${${'GLOBALS'}['tkxxpbqrkjm']}[1]), ${${'GLOBALS'}['voomojjtgkra']});
    ${'GLOBALS'}['tyosla'] = 'length';
    if (${$ssnwlxitksn} === false || ${${'GLOBALS'}['jvmwdhv']} === false) {
        return NULL;
    }
    ${'GLOBALS'}['wuiuunhbn'] = 'length';
    if (${${'GLOBALS'}['tufcmkxoiiz']} == 1) {
        ${${'GLOBALS'}['urzwiygo']} = (${${'GLOBALS'}['jvmwdhv']} + strlen(${${'GLOBALS'}['tkxxpbqrkjm']}[1])) - ${$onhzxpvcv};
    } else {
        ${${'GLOBALS'}['tyosla']} = ${${'GLOBALS'}['jvmwdhv']} - ${${'GLOBALS'}['voomojjtgkra']};
    }
    return substr(${$rdvrpx}, ${${'GLOBALS'}['voomojjtgkra']}, ${${'GLOBALS'}['wuiuunhbn']});
}
function getTagsByRule($s, $rule)
{
    ${'GLOBALS'}['xohokwg'] = 'content';
    $mjblbqm = 'content';
    ${'GLOBALS'}['ncisxncllxuv'] = 'content';
    $yeppeqtvqc = 'tags';
    $mvxjrclxspm = 'rule';
    ${${'GLOBALS'}['rmkmdgfu']} = array();
    ${$mjblbqm} = getContentByRule(${${'GLOBALS'}['wwaudytvks']}, ${$mvxjrclxspm}, 1);
    $viaxsjmhv = 'dom';
    if (${${'GLOBALS'}['xohokwg']} == NULL) {
        return ${$yeppeqtvqc};
    }
    ${$viaxsjmhv} = str_get_html(${${'GLOBALS'}['ncisxncllxuv']});
    foreach ($dom->find('a') as ${${'GLOBALS'}['lbdmsjjvihy']}) {
        if ($a->innertext != '') {
            $ogwbxjcdef = 'tags';
            ${$ogwbxjcdef}[] = $a->innertext;
        }
    }
    ${'GLOBALS'}['umvrhjmogr'] = 'dom';
    $dom->clear();
    unset(${${'GLOBALS'}['umvrhjmogr']});
    return ${${'GLOBALS'}['rmkmdgfu']};
}
function getContentByCss($d, $c, $charset, $outer, $index)
{
    $pnkoexhlv = 's';
    $mutgwcp = 's';
    ${$pnkoexhlv} = '';
    $qgpdpjbku = 's';
    if (${${'GLOBALS'}['sxfnnbgw']} == 0) {
        $eitudicn = 'e';
        ${'GLOBALS'}['xlaxtgj'] = 'c';
        foreach ($d->find(${${'GLOBALS'}['xlaxtgj']}) as ${$eitudicn}) {
            $pfguym = 's';
            if (${${'GLOBALS'}['tufcmkxoiiz']} == 1) {
                ${${'GLOBALS'}['wwaudytvks']} .= $e->outertext;
            } else {
                ${$pfguym} .= $e->innertext;
            }
        }
    } else {
        $ldfheo = 'elements';
        ${'GLOBALS'}['ejrjdqxe'] = 'e';
        $bybrmbpcf = 'index';
        ${'GLOBALS'}['vxpmfmlvnyn'] = 'e';
        ${$ldfheo} = $d->find(${${'GLOBALS'}['gldshxvohkl']});
        ${'GLOBALS'}['tquwnwg'] = 'index';
        $kisljpxw = 'i';
        ${${'GLOBALS'}['iysvwodqrf']} = 0;
        if (${${'GLOBALS'}['sxfnnbgw']} >= 1) {
            ${${'GLOBALS'}['iysvwodqrf']} = ${${'GLOBALS'}['sxfnnbgw']} - 1;
        } elseif (${$bybrmbpcf} < 0) {
            ${$kisljpxw} = count(${${'GLOBALS'}['stnivroy']}) + ${${'GLOBALS'}['tquwnwg']};
        }
        ${${'GLOBALS'}['hramgrdkp']} = ${${'GLOBALS'}['stnivroy']}[${${'GLOBALS'}['iysvwodqrf']}];
        if (${${'GLOBALS'}['vxpmfmlvnyn']} != null) {
            ${'GLOBALS'}['wezwmnuh'] = 'outer';
            if (${${'GLOBALS'}['wezwmnuh']} == 1) {
                ${${'GLOBALS'}['wwaudytvks']} .= $e->outertext;
            } else {
                ${${'GLOBALS'}['wwaudytvks']} .= $e->innertext;
            }
        }
        unset(${${'GLOBALS'}['stnivroy']});
        unset(${${'GLOBALS'}['ejrjdqxe']});
    }
    if (${${'GLOBALS'}['wwaudytvks']} == '') {
        return ${${'GLOBALS'}['wwaudytvks']};
    }
    if (${${'GLOBALS'}['ukhqmstsw']} != 'UTF-8') {
        ${$mutgwcp} = iconv(${${'GLOBALS'}['ukhqmstsw']}, 'UTF-8//IGNORE', ${${'GLOBALS'}['wwaudytvks']});
    }
    return ${$qgpdpjbku};
}
function getPostDateByCss($d, $c, $charset, $outer, $index)
{
    ${${'GLOBALS'}['wwaudytvks']} = '';
    $buwnnipnki = 's';
    if (${${'GLOBALS'}['sxfnnbgw']} == 0) {
        ${'GLOBALS'}['btllkpodkds'] = 'c';
        foreach ($d->find(${${'GLOBALS'}['btllkpodkds']}) as ${${'GLOBALS'}['hramgrdkp']}) {
            ${'GLOBALS'}['volwwg'] = 'outer';
            $cpbnowageqr = 's';
            if (${${'GLOBALS'}['volwwg']} == 1) {
                ${${'GLOBALS'}['wwaudytvks']} .= $e->plaintext;
            } else {
                ${$cpbnowageqr} .= $e->plaintext;
            }
        }
    } else {
        $cmtilxiv = 'i';
        ${'GLOBALS'}['hzdxmyijzcnp'] = 'e';
        $rzcuenrwsr = 'i';
        $oxfntphtu = 'i';
        $ugtcvqhob = 'elements';
        ${$ugtcvqhob} = $d->find(${${'GLOBALS'}['gldshxvohkl']});
        ${'GLOBALS'}['veedyjwto'] = 'index';
        $jnakgy = 'e';
        ${$cmtilxiv} = 0;
        $iyjtgnxufnwr = 'index';
        $cfpbmpuhlro = 'i';
        if (${${'GLOBALS'}['sxfnnbgw']} >= 1) {
            ${$rzcuenrwsr} = ${${'GLOBALS'}['veedyjwto']} - 1;
        } elseif (${${'GLOBALS'}['sxfnnbgw']} < 0) {
            ${$cfpbmpuhlro} = count(${${'GLOBALS'}['stnivroy']}) + ${$iyjtgnxufnwr};
        }
        ${$jnakgy} = ${${'GLOBALS'}['stnivroy']}[${$oxfntphtu}];
        if (${${'GLOBALS'}['hzdxmyijzcnp']} != null) {
            ${'GLOBALS'}['mkrysrtblw'] = 'outer';
            ${'GLOBALS'}['qyousm'] = 's';
            if (${${'GLOBALS'}['mkrysrtblw']} == 1) {
                ${${'GLOBALS'}['wwaudytvks']} .= $e->plaintext;
            } else {
                ${${'GLOBALS'}['qyousm']} .= $e->plaintext;
            }
        }
        unset(${${'GLOBALS'}['stnivroy']});
        unset(${${'GLOBALS'}['hramgrdkp']});
    }
    if (${${'GLOBALS'}['wwaudytvks']} == '') {
        return ${$buwnnipnki};
    }
    if (${${'GLOBALS'}['ukhqmstsw']} != 'UTF-8') {
        ${${'GLOBALS'}['wwaudytvks']} = iconv(${${'GLOBALS'}['ukhqmstsw']}, 'UTF-8//IGNORE', ${${'GLOBALS'}['wwaudytvks']});
    }
    $zeilpwizo = 's';
    return ${$zeilpwizo};
}
function getTagsByCSS($d, $c, $charset, $index)
{
    ${'GLOBALS'}['wpeqswawx'] = 'tags';
    ${${'GLOBALS'}['wpeqswawx']} = array();
    if (${${'GLOBALS'}['sxfnnbgw']} == 0) {
        ${'GLOBALS'}['qnrdluawfqjw'] = 'c';
        foreach ($d->find(${${'GLOBALS'}['qnrdluawfqjw']}) as ${${'GLOBALS'}['hramgrdkp']}) {
            if ($e->tag == 'a') {
                ${'GLOBALS'}['jrrxsbofau'] = 'tag';
                ${${'GLOBALS'}['wnewosaggmy']} = $e->innertext;
                if (${${'GLOBALS'}['jrrxsbofau']} != '') {
                    ${'GLOBALS'}['pwwgqvgj'] = 'tag';
                    ${'GLOBALS'}['mybiwi'] = 'charset';
                    ${'GLOBALS'}['dejiwbqgqhc'] = 'tag';
                    if (${${'GLOBALS'}['ukhqmstsw']} != 'UTF-8') {
                        ${${'GLOBALS'}['pwwgqvgj']} = iconv(${${'GLOBALS'}['mybiwi']}, 'UTF-8//IGNORE', ${${'GLOBALS'}['wnewosaggmy']});
                    }
                    ${${'GLOBALS'}['rmkmdgfu']}[] = ${${'GLOBALS'}['dejiwbqgqhc']};
                }
            } else {
                ${'GLOBALS'}['qidplxsf'] = 'find_a';
                ${${'GLOBALS'}['mkytkje']} = false;
                foreach ($e->find('a') as ${${'GLOBALS'}['lbdmsjjvihy']}) {
                    ${'GLOBALS'}['bjfaosqxoe'] = 'tag';
                    ${${'GLOBALS'}['mkytkje']} = true;
                    ${${'GLOBALS'}['bjfaosqxoe']} = $a->innertext;
                    if (${${'GLOBALS'}['wnewosaggmy']} != '') {
                        $gawdcs = 'tag';
                        ${'GLOBALS'}['hpmstjql'] = 'tags';
                        $bjevcskmwvbd = 'charset';
                        if (${${'GLOBALS'}['ukhqmstsw']} != 'UTF-8') {
                            ${${'GLOBALS'}['wnewosaggmy']} = iconv(${$bjevcskmwvbd}, 'UTF-8//IGNORE', ${$gawdcs});
                        }
                        ${${'GLOBALS'}['hpmstjql']}[] = ${${'GLOBALS'}['wnewosaggmy']};
                    }
                }
                if (!${${'GLOBALS'}['qidplxsf']}) {
                    ${${'GLOBALS'}['wnewosaggmy']} = $e->innertext;
                    if (${${'GLOBALS'}['wnewosaggmy']} != '') {
                        $ruvconiuglo = 'charset';
                        if (${$ruvconiuglo} != 'UTF-8') {
                            ${${'GLOBALS'}['wnewosaggmy']} = iconv(${${'GLOBALS'}['ukhqmstsw']}, 'UTF-8//IGNORE', ${${'GLOBALS'}['wnewosaggmy']});
                        }
                        ${${'GLOBALS'}['rmkmdgfu']}[] = ${${'GLOBALS'}['wnewosaggmy']};
                    }
                }
            }
        }
    } else {
        ${'GLOBALS'}['knesdfxv'] = 'elements';
        $tbqduxjcs = 'index';
        ${'GLOBALS'}['eknrrp'] = 'elements';
        $gmqydxwbg = 'i';
        ${'GLOBALS'}['lloqwmtmdlo'] = 'i';
        ${${'GLOBALS'}['knesdfxv']} = $d->find(${${'GLOBALS'}['gldshxvohkl']});
        ${${'GLOBALS'}['lloqwmtmdlo']} = 0;
        ${'GLOBALS'}['hjhbrjl'] = 'e';
        ${'GLOBALS'}['bvfeotflbruw'] = 'i';
        ${'GLOBALS'}['sksvqcfwpltw'] = 'elements';
        ${'GLOBALS'}['qvrhaiun'] = 'e';
        if (${${'GLOBALS'}['sxfnnbgw']} >= 1) {
            ${$gmqydxwbg} = ${${'GLOBALS'}['sxfnnbgw']} - 1;
        } elseif (${$tbqduxjcs} < 0) {
            ${${'GLOBALS'}['bvfeotflbruw']} = count(${${'GLOBALS'}['stnivroy']}) + ${${'GLOBALS'}['sxfnnbgw']};
        }
        ${${'GLOBALS'}['hjhbrjl']} = ${${'GLOBALS'}['sksvqcfwpltw']}[${${'GLOBALS'}['iysvwodqrf']}];
        if (${${'GLOBALS'}['hramgrdkp']} != null) {
            if ($e->tag == 'a') {
                ${'GLOBALS'}['zjectumnn'] = 'tag';
                ${${'GLOBALS'}['wnewosaggmy']} = $e->innertext;
                if (${${'GLOBALS'}['zjectumnn']} != '') {
                    $xasbrkwwxhm = 'tag';
                    $ybnwnv = 'charset';
                    ${'GLOBALS'}['fifxofi'] = 'tag';
                    $nuhqshofwtbi = 'tag';
                    if (${${'GLOBALS'}['ukhqmstsw']} != 'UTF-8') {
                        ${$nuhqshofwtbi} = iconv(${$ybnwnv}, 'UTF-8//IGNORE', ${${'GLOBALS'}['fifxofi']});
                    }
                    ${${'GLOBALS'}['rmkmdgfu']}[] = ${$xasbrkwwxhm};
                }
            } else {
                $gfschlqeyyj = 'a';
                ${'GLOBALS'}['xucmtctgln'] = 'find_a';
                ${${'GLOBALS'}['mkytkje']} = false;
                foreach ($e->find('a') as ${$gfschlqeyyj}) {
                    ${'GLOBALS'}['ffvuxgnsipw'] = 'find_a';
                    $rypuyyvtpdc = 'tag';
                    ${${'GLOBALS'}['ffvuxgnsipw']} = true;
                    ${${'GLOBALS'}['wnewosaggmy']} = $a->innertext;
                    if (${$rypuyyvtpdc} != '') {
                        $ktsafnekro = 'tag';
                        ${'GLOBALS'}['gqvvjtsytu'] = 'tag';
                        $ggagvec = 'tags';
                        ${'GLOBALS'}['ixmxdoqkq'] = 'charset';
                        if (${${'GLOBALS'}['ukhqmstsw']} != 'UTF-8') {
                            ${$ktsafnekro} = iconv(${${'GLOBALS'}['ixmxdoqkq']}, 'UTF-8//IGNORE', ${${'GLOBALS'}['wnewosaggmy']});
                        }
                        ${$ggagvec}[] = ${${'GLOBALS'}['gqvvjtsytu']};
                    }
                }
                if (!${${'GLOBALS'}['xucmtctgln']}) {
                    $eabmzdbevgb = 'tag';
                    $nuemwtqepkh = 'tag';
                    ${$eabmzdbevgb} = $e->innertext;
                    if (${$nuemwtqepkh} != '') {
                        $vyycbrkugb = 'tag';
                        $xvfooqdghrsd = 'charset';
                        ${'GLOBALS'}['ufkqolryblz'] = 'tag';
                        ${'GLOBALS'}['eubcuymw'] = 'charset';
                        ${'GLOBALS'}['xwxcxiixmxu'] = 'tags';
                        if (${${'GLOBALS'}['eubcuymw']} != 'UTF-8') {
                            ${$vyycbrkugb} = iconv(${$xvfooqdghrsd}, 'UTF-8//IGNORE', ${${'GLOBALS'}['wnewosaggmy']});
                        }
                        ${${'GLOBALS'}['xwxcxiixmxu']}[] = ${${'GLOBALS'}['ufkqolryblz']};
                    }
                }
            }
        }
        unset(${${'GLOBALS'}['eknrrp']});
        unset(${${'GLOBALS'}['qvrhaiun']});
    }
    return ${${'GLOBALS'}['rmkmdgfu']};
}
function getArticleTitel($url, $config)
{
    $xeinhebk = 'useP';
    ${'GLOBALS'}['hcrdalaqbtdw'] = 'proxy';
    ${${'GLOBALS'}['qmuxdjwtre']} = json_decode($config->proxy);
    $rdtghicubk = 'd';
    global $proxy;
    ${${'GLOBALS'}['oczdbco']} = file_get_html(${${'GLOBALS'}['vnugmpqtyg']}, $config->page_charset, Method, ${${'GLOBALS'}['qmuxdjwtre']}[0], ${$xeinhebk}[1], ${${'GLOBALS'}['hcrdalaqbtdw']});
    if (${$rdtghicubk} == NULL) {
        return -1;
    }
    if (trim($config->title_selector) == '') {
        ${'GLOBALS'}['jcpdodtcdfk'] = 'title';
        ${${'GLOBALS'}['jcpdodtcdfk']}[1] = -1;
    } else {
        $slwvveyxwm = 'titleIconved';
        ${$slwvveyxwm} = false;
        if ($config->title_match_type == 0) {
            ${'GLOBALS'}['oxkgrnakfw'] = 'title';
            ${${'GLOBALS'}['oxkgrnakfw']}[0] = $d->find($config->title_selector, 0)->plaintext;
        } else {
            $xtwpsfomkzn = 'UTFhtml';
            if ($config->page_charset != 'UTF-8') {
                $lonqousgqlc = 'UTFhtml';
                $dekyemzkiv = 'UTFhtml';
                $eyypume = 'UTFhtml';
                ${'GLOBALS'}['gzleoreo'] = 'titleIconved';
                ${${'GLOBALS'}['wjtdbtdagjk']} = $d->save();
                ${$lonqousgqlc} = iconv($config->page_charset, 'UTF-8//IGNORE', ${$dekyemzkiv});
                ${${'GLOBALS'}['wjtdbtdagjk']} = compress_html(${$eyypume});
                ${${'GLOBALS'}['gzleoreo']} = true;
            } else {
                $xwjggny = 'UTFhtml';
                ${$xwjggny} = $d->save();
                ${${'GLOBALS'}['wjtdbtdagjk']} = compress_html(${${'GLOBALS'}['wjtdbtdagjk']});
            }
            ${${'GLOBALS'}['owlianh']} = true;
            ${${'GLOBALS'}['wqtygwsz']}[0] = getContentByRule(${$xtwpsfomkzn}, $config->title_selector);
        }
        if (${${'GLOBALS'}['wqtygwsz']}[0] == NULL || trim(${${'GLOBALS'}['wqtygwsz']}[0]) == '') {
            ${${'GLOBALS'}['wqtygwsz']}[1] = -1;
        } else {
            $pdusgfznz = 'title';
            $uhkmtgyorcu = 'title';
            ${${'GLOBALS'}['wqtygwsz']}[1] = 1;
            $flgkojo = 'titleIconved';
            $sucqgfuoe = 'title';
            if ($config->page_charset != 'UTF-8' && !${$flgkojo}) {
                ${$uhkmtgyorcu}[0] = iconv($config->page_charset, 'UTF-8//IGNORE', ${$pdusgfznz}[0]);
            }
            ${$sucqgfuoe}[0] = strip_tags(${${'GLOBALS'}['wqtygwsz']}[0]);
        }
    }
    $d->clear();
    unset(${${'GLOBALS'}['oczdbco']});
    return ${${'GLOBALS'}['wqtygwsz']};
}
function getArticle($url, $config, $isTest = 1)
{
    ${'GLOBALS'}['ewdvrjg'] = 'useP';
    ${${'GLOBALS'}['ewdvrjg']} = json_decode($config->proxy);
    $xkmrelldj = 'url';
    ${'GLOBALS'}['hnijtsf'] = 'hasUTFhtml';
    $ighhbsxl = 'd';
    $tjtvxlk = 'useP';
    global $proxy;
    ${${'GLOBALS'}['oczdbco']} = file_get_html(${$xkmrelldj}, $config->page_charset, Method, ${$tjtvxlk}[0], ${${'GLOBALS'}['qmuxdjwtre']}[1], ${${'GLOBALS'}['jnjrlqgm']});
    ${'GLOBALS'}['vjjwudbot'] = 'Article';
    ${'GLOBALS'}['staoojkqns'] = 'url';
    if (${${'GLOBALS'}['oczdbco']} == NULL) {
        return -1;
    }
    ${${'GLOBALS'}['vzrexdhtj']} = getBaseUrl(${$ighhbsxl}, ${${'GLOBALS'}['staoojkqns']});
    ${${'GLOBALS'}['hnijtsf']} = false;
    if (trim($config->title_selector) == '') {
        $lwydtzhaj = 'Article';
        ${$lwydtzhaj}[2] = -1;
    } else {
        ${'GLOBALS'}['qrbghwoxi'] = 'titleIconved';
        ${${'GLOBALS'}['qrbghwoxi']} = false;
        $bthaxp = 'Article';
        if ($config->title_match_type == 0) {
            ${'GLOBALS'}['cclnhzjknoq'] = 'Article';
            ${${'GLOBALS'}['cclnhzjknoq']}[0] = $d->find($config->title_selector, 0)->plaintext;
        } else {
            ${'GLOBALS'}['meklljcx'] = 'UTFhtml';
            ${'GLOBALS'}['xhsmcal'] = 'hasUTFhtml';
            if ($config->page_charset != 'UTF-8') {
                ${'GLOBALS'}['dzuxqvyg'] = 'UTFhtml';
                ${${'GLOBALS'}['wjtdbtdagjk']} = $d->save();
                ${${'GLOBALS'}['wjtdbtdagjk']} = iconv($config->page_charset, 'UTF-8//IGNORE', ${${'GLOBALS'}['dzuxqvyg']});
                $zecbhn = 'titleIconved';
                ${${'GLOBALS'}['wjtdbtdagjk']} = compress_html(${${'GLOBALS'}['wjtdbtdagjk']});
                ${$zecbhn} = true;
            } else {
                ${${'GLOBALS'}['wjtdbtdagjk']} = $d->save();
                ${${'GLOBALS'}['wjtdbtdagjk']} = compress_html(${${'GLOBALS'}['wjtdbtdagjk']});
            }
            ${${'GLOBALS'}['xhsmcal']} = true;
            ${${'GLOBALS'}['tmxmsc']}[0] = getContentByRule(${${'GLOBALS'}['meklljcx']}, $config->title_selector);
        }
        if (${$bthaxp}[0] == NULL || trim(${${'GLOBALS'}['tmxmsc']}[0]) == '') {
            $dtppkdbjt = 'Article';
            ${$dtppkdbjt}[2] = -1;
        } else {
            $oqjpglkfrgo = 'Article';
            ${'GLOBALS'}['xrdagvbfryy'] = 'isTest';
            $umdqrrnwgp = 'Article';
            ${'GLOBALS'}['eiqpnevxzkgk'] = 'Article';
            ${'GLOBALS'}['xcjchbyfldf'] = 'Article';
            ${${'GLOBALS'}['tmxmsc']}[2] = 1;
            if ($config->page_charset != 'UTF-8' && !${${'GLOBALS'}['ixkotmds']}) {
                ${${'GLOBALS'}['eiqpnevxzkgk']}[0] = iconv($config->page_charset, 'UTF-8//IGNORE', ${$oqjpglkfrgo}[0]);
            }
            ${$umdqrrnwgp}[0] = trim(strip_tags(${${'GLOBALS'}['xcjchbyfldf']}[0]));
            if (${${'GLOBALS'}['xrdagvbfryy']} == 0 && $config->check_duplicate == 1) {
                if (checkTitle($config->id, ${${'GLOBALS'}['tmxmsc']}[0]) > 0) {
                    ${'GLOBALS'}['ggqhpoa'] = 'Article';
                    ${${'GLOBALS'}['ggqhpoa']}[2] = -2;
                    return ${${'GLOBALS'}['tmxmsc']};
                }
            }
        }
    }
    if (trim($config->content_selector) == '') {
        $bfkxdv = 'Article';
        ${$bfkxdv}[3] = -1;
    } else {
        ${'GLOBALS'}['bijyfxvsbw'] = 'content_selector';
        ${'GLOBALS'}['fwdpygofera'] = 'content_selector';
        ${'GLOBALS'}['fcgvhsvmf'] = 'i';
        ${${'GLOBALS'}['fwdpygofera']} = json_decode($config->content_selector);
        if (${${'GLOBALS'}['bijyfxvsbw']} == null) {
            $nqlmbhjjnz = 'content_selector';
            ${'GLOBALS'}['vpkeofrhqqz'] = 'content_selector';
            ${$nqlmbhjjnz} = array();
            ${${'GLOBALS'}['vpkeofrhqqz']}[0] = $config->content_selector;
        }
        ${${'GLOBALS'}['qvohvvh']} = json_decode($config->content_match_type);
        $lobgwlbhd = 'content_match_type';
        ${'GLOBALS'}['dfprctujc'] = 'matchNum';
        if (${${'GLOBALS'}['qvohvvh']} == null) {
            $fnvinpj = 'content_match_type';
            $dnyyhbjtqdgi = 'index';
            ${$fnvinpj} = array();
            ${'GLOBALS'}['symdsdkl'] = 'outer';
            ${${'GLOBALS'}['wrwdrlrtb']}[0] = $config->content_match_type;
            ${${'GLOBALS'}['tufcmkxoiiz']} = array();
            ${${'GLOBALS'}['symdsdkl']}[0] = 0;
            $bqbdcoakl = 'objective';
            ${${'GLOBALS'}['xjhjexbdrv']} = array();
            ${$bqbdcoakl}[0] = 0;
            ${${'GLOBALS'}['sxfnnbgw']} = array();
            ${$dnyyhbjtqdgi}[0] = 0;
        } else {
            $uevetckp = 'content_match_type';
            ${$uevetckp} = array();
            $aqwfnborit = 'outer';
            ${$aqwfnborit} = array();
            ${${'GLOBALS'}['xjhjexbdrv']} = array();
            ${${'GLOBALS'}['sxfnnbgw']} = array();
            foreach (${${'GLOBALS'}['qvohvvh']} as ${${'GLOBALS'}['btplbnnrfc']}) {
                $bocddyqtfus = 'index';
                $mcmnxlixai = 'cmt';
                ${'GLOBALS'}['uhtnuh'] = 'cmt';
                $ggmoxeih = 'cmts';
                ${'GLOBALS'}['rlutyio'] = 'cmt';
                ${${'GLOBALS'}['iiisinyser']} = explode(',', ${$ggmoxeih});
                $wkqzlhl = 'objective';
                $flervtk = 'outer';
                $jdywkqoobo = 'cmt';
                ${${'GLOBALS'}['wrwdrlrtb']}[] = ${$mcmnxlixai}[0];
                ${$flervtk}[] = ${${'GLOBALS'}['iiisinyser']}[1];
                if (${${'GLOBALS'}['iiisinyser']}[2] == NULL || ${$jdywkqoobo}[2] == '') {
                    ${${'GLOBALS'}['xjhjexbdrv']}[] = 0;
                } else {
                    ${$wkqzlhl}[] = ${${'GLOBALS'}['iiisinyser']}[2];
                }
                if (${${'GLOBALS'}['iiisinyser']}[3] == NULL || ${${'GLOBALS'}['uhtnuh']}[3] == '') {
                    ${$bocddyqtfus}[] = 0;
                } else {
                    ${${'GLOBALS'}['sxfnnbgw']}[] = ${${'GLOBALS'}['rlutyio']}[3];
                }
            }
        }
        ${${'GLOBALS'}['tmxmsc']}[1] = '';
        ${${'GLOBALS'}['dfprctujc']} = count(${${'GLOBALS'}['pbegstv']});
        $qittlx = 'matchNum';
        foreach (${$lobgwlbhd} as ${${'GLOBALS'}['iiisinyser']}) {
            if (${${'GLOBALS'}['iiisinyser']} == 1) {
                ${'GLOBALS'}['ajasev'] = 'hasUTFhtml';
                if (!${${'GLOBALS'}['ajasev']}) {
                    if ($config->page_charset != 'UTF-8') {
                        ${'GLOBALS'}['hnyupnrxsfj'] = 'UTFhtml';
                        $ldrwgfxpfrg = 'UTFhtml';
                        ${'GLOBALS'}['prduwng'] = 'UTFhtml';
                        ${'GLOBALS'}['cxggrruteny'] = 'UTFhtml';
                        ${${'GLOBALS'}['wjtdbtdagjk']} = $d->save();
                        ${${'GLOBALS'}['hnyupnrxsfj']} = iconv($config->page_charset, 'UTF-8//IGNORE', ${$ldrwgfxpfrg});
                        ${${'GLOBALS'}['cxggrruteny']} = compress_html(${${'GLOBALS'}['prduwng']});
                    } else {
                        ${'GLOBALS'}['pohpfwdzz'] = 'UTFhtml';
                        $fcqlkugmjxik = 'UTFhtml';
                        ${${'GLOBALS'}['wjtdbtdagjk']} = $d->save();
                        ${$fcqlkugmjxik} = compress_html(${${'GLOBALS'}['pohpfwdzz']});
                    }
                }
                break;
            }
        }
        for (${${'GLOBALS'}['fcgvhsvmf']} = 0; ${${'GLOBALS'}['iysvwodqrf']} < ${$qittlx}; ${${'GLOBALS'}['iysvwodqrf']}++) {
            $iiveikxqymh = 'i';
            ${'GLOBALS'}['stqrecrq'] = 'content_match_type';
            if (${${'GLOBALS'}['stqrecrq']}[${$iiveikxqymh}] == 0) {
                $jxzsfwgea = 'i';
                ${'GLOBALS'}['djrrvclddg'] = 'i';
                $tgpltuabpsg = 'content_selector';
                ${'GLOBALS'}['bcluqqaspl'] = 'i';
                $pknqcnwdhp = 'Article';
                ${'GLOBALS'}['kxeydjfmps'] = 'd';
                $kdqvrfudutg = 'content_selector';
                $vbifppc = 'i';
                $bpnidi = 'Article';
                ${'GLOBALS'}['gnsigfdnpq'] = 'index';
                ${'GLOBALS'}['mxknypkewced'] = 'index';
                $sxjffuhyx = 'd';
                $rsyvckd = 'outer';
                $jmgscohjnne = 'i';
                ${'GLOBALS'}['lifyuf'] = 'content_selector';
                $nytkciwb = 'index';
                $hofkgjcgatmp = 'd';
                switch (${${'GLOBALS'}['xjhjexbdrv']}[${${'GLOBALS'}['iysvwodqrf']}]) {
                case '0':
                    ${${'GLOBALS'}['tmxmsc']}[1] .= getContentByCss(${$hofkgjcgatmp}, ${$tgpltuabpsg}[${${'GLOBALS'}['iysvwodqrf']}], $config->page_charset, ${${'GLOBALS'}['tufcmkxoiiz']}[${${'GLOBALS'}['iysvwodqrf']}], ${$nytkciwb}[${$jmgscohjnne}]);
                    break;
                case '1':
                    ${$pknqcnwdhp}[4] = strtotime(getPostDateByCss(${$sxjffuhyx}, ${${'GLOBALS'}['lifyuf']}[${$jxzsfwgea}], $config->page_charset, ${$rsyvckd}[${${'GLOBALS'}['iysvwodqrf']}], ${${'GLOBALS'}['mxknypkewced']}[${${'GLOBALS'}['iysvwodqrf']}]));
                    break;
                case '2':
                    ${$bpnidi}[9] = getContentByCss(${${'GLOBALS'}['oczdbco']}, ${${'GLOBALS'}['pbegstv']}[${${'GLOBALS'}['iysvwodqrf']}], $config->page_charset, ${${'GLOBALS'}['tufcmkxoiiz']}[${${'GLOBALS'}['iysvwodqrf']}], ${${'GLOBALS'}['gnsigfdnpq']}[${${'GLOBALS'}['djrrvclddg']}]);
                    break;
                case '3':
                    ${${'GLOBALS'}['rmkmdgfu']} = getTagsByCSS(${${'GLOBALS'}['kxeydjfmps']}, ${$kdqvrfudutg}[${$vbifppc}], $config->page_charset, ${${'GLOBALS'}['sxfnnbgw']}[${${'GLOBALS'}['bcluqqaspl']}]);
                    if (count(${${'GLOBALS'}['rmkmdgfu']}) > 0) {
                        ${'GLOBALS'}['tjtrdwru'] = 'tags';
                        ${${'GLOBALS'}['tmxmsc']}[11] = json_encode(${${'GLOBALS'}['tjtrdwru']});
                    }
                    break;
                }
            } else {
                $lffdsw = 'i';
                ${'GLOBALS'}['wgfrxyavm'] = 'i';
                ${'GLOBALS'}['mtprukfx'] = 'Article';
                ${'GLOBALS'}['uumokfnrz'] = 'i';
                $inlbxdvv = 'outer';
                ${'GLOBALS'}['fxetqcdkeyc'] = 'i';
                $wrfkpbiohch = 'outer';
                $yltqniee = 'outer';
                $mxxijwqty = 'i';
                switch (${${'GLOBALS'}['xjhjexbdrv']}[${$mxxijwqty}]) {
                case '0':
                    ${${'GLOBALS'}['tmxmsc']}[1] .= getContentByRule(${${'GLOBALS'}['wjtdbtdagjk']}, ${${'GLOBALS'}['pbegstv']}[${$lffdsw}], ${$inlbxdvv}[${${'GLOBALS'}['uumokfnrz']}]);
                    break;
                case '1':
                    ${${'GLOBALS'}['mtprukfx']}[4] = strtotime(getContentByRule(${${'GLOBALS'}['wjtdbtdagjk']}, ${${'GLOBALS'}['pbegstv']}[${${'GLOBALS'}['fxetqcdkeyc']}], ${$yltqniee}[${${'GLOBALS'}['iysvwodqrf']}]));
                    break;
                case '2':
                    ${${'GLOBALS'}['tmxmsc']}[9] = getContentByRule(${${'GLOBALS'}['wjtdbtdagjk']}, ${${'GLOBALS'}['pbegstv']}[${${'GLOBALS'}['iysvwodqrf']}], ${$wrfkpbiohch}[${${'GLOBALS'}['wgfrxyavm']}]);
                    break;
                case '3':
                    ${${'GLOBALS'}['rmkmdgfu']} = getTagsByRule(${${'GLOBALS'}['wjtdbtdagjk']}, ${${'GLOBALS'}['pbegstv']}[${${'GLOBALS'}['iysvwodqrf']}]);
                    if (count(${${'GLOBALS'}['rmkmdgfu']}) > 0) {
                        $gdtcdrtrj = 'tags';
                        ${${'GLOBALS'}['tmxmsc']}[11] = json_encode(${$gdtcdrtrj});
                    }
                    break;
                }
            }
        }
        if (${${'GLOBALS'}['tmxmsc']}[1] == '' || ${${'GLOBALS'}['tmxmsc']}[1] == NULL) {
            ${'GLOBALS'}['kcbzhnwdkdj'] = 'Article';
            ${${'GLOBALS'}['kcbzhnwdkdj']}[3] = -1;
        } else {
            $vmdmvmwfk = 'Article';
            $ryxyvpjcffz = 'Article';
            $mblvwn = 'baseUrl';
            $ebjjgdeb = 'Article';
            ${'GLOBALS'}['qlftnu'] = 'Article';
            ${${'GLOBALS'}['tmxmsc']}[3] = 1;
            $dbguyskjg = 'Article';
            ${${'GLOBALS'}['tmxmsc']}[1] = transImgSrc(${$ebjjgdeb}[1], ${$mblvwn}, ${$ryxyvpjcffz}[0]);
            if (DEL_COMMENT == 1) {
                ${$vmdmvmwfk}[1] = filterComment(${${'GLOBALS'}['qlftnu']}[1]);
            }
            ${$dbguyskjg}[1] = filterCommAttr(${${'GLOBALS'}['tmxmsc']}[1], DEL_ATTRID, DEL_ATTRCLASS, DEL_ATTRSTYLE);
        }
    }
    $d->clear();
    unset(${${'GLOBALS'}['oczdbco']});
    unset(${${'GLOBALS'}['wjtdbtdagjk']});
    return ${${'GLOBALS'}['vjjwudbot']};
}
function filterComment($s)
{
    ${'GLOBALS'}['lyclrpbdyu'] = 's';
    ${'GLOBALS'}['abhokrfjvky'] = 's';
    ${'GLOBALS'}['weqjiwsfan'] = 'e';
    ${'GLOBALS'}['pywceqxik'] = 'dom';
    ${${'GLOBALS'}['pywceqxik']} = str_get_html(${${'GLOBALS'}['lyclrpbdyu']});
    foreach ($dom->find('comment') as ${${'GLOBALS'}['weqjiwsfan']}) {
        $e->outertext = '';
    }
    ${${'GLOBALS'}['abhokrfjvky']} = $dom->save();
    $dom->clear();
    unset(${${'GLOBALS'}['oxftvuqwjtr']});
    return ${${'GLOBALS'}['wwaudytvks']};
}
function filterCommAttr($s, $f_id, $f_class, $f_style)
{
    ${'GLOBALS'}['pqxqgmmbhkj'] = 'dom';
    ${${'GLOBALS'}['pqxqgmmbhkj']} = str_get_html(${${'GLOBALS'}['wwaudytvks']});
    $nlhuvruhwhq = 'f_id';
    if (${$nlhuvruhwhq} == 1) {
        $xyfuybl = 'e';
        foreach ($dom->find('[id]') as ${$xyfuybl}) {
            $e->removeAttribute('id');
        }
    }
    if (${${'GLOBALS'}['ndyhukkiwnvw']} == 1) {
        ${'GLOBALS'}['gvbhjck'] = 'e';
        foreach ($dom->find('[class]') as ${${'GLOBALS'}['gvbhjck']}) {
            $e->removeAttribute('class');
        }
    }
    ${'GLOBALS'}['attbbzbt'] = 's';
    if (${${'GLOBALS'}['vhscjyjels']} == 1) {
        $rltgednnjqmt = 'e';
        foreach ($dom->find('[style]') as ${$rltgednnjqmt}) {
            $e->removeAttribute('style');
        }
    }
    ${${'GLOBALS'}['attbbzbt']} = $dom->save();
    $dom->clear();
    unset(${${'GLOBALS'}['oxftvuqwjtr']});
    return ${${'GLOBALS'}['wwaudytvks']};
}
function wp_autopost_pre_fetch($arti)
{
    global $autoPostInsert;
    $ulovgwxh = 'autoPostInsert';
    global $post;
    if (${$ulovgwxh}) {
        if (stripos(${${'GLOBALS'}['fzuuprcgvo']}, 'wp-autopost.org') === false) {
            $asetros = 'autoPostInserts';
            ${$asetros} = true;
        }
    }
    if (checkPostId($post->ID) > 0) {
        $brjykoxwjrf = 'arti';
        if (stripos(${$brjykoxwjrf}, 'wp-autopost.org') === false) {
            ${${'GLOBALS'}['dqjntz']} = true;
        }
    }
    ${'GLOBALS'}['enrtkrns'] = 'autoPostUpdate';
    if (${${'GLOBALS'}['dqzhsov']} || ${${'GLOBALS'}['enrtkrns']}) {
        ${'GLOBALS'}['dwyuzyqwugq'] = 'fLPosts';
        ${'GLOBALS'}['yqtaejgwfor'] = 'fLNum';
        global $fLPosts;
        $bsycfesujy = 'fLPosts';
        ${${'GLOBALS'}['yqtaejgwfor']} = count(${$bsycfesujy});
        ${${'GLOBALS'}['zkqgnxqtjbn']} = rand(0, ${${'GLOBALS'}['ebsyvj']} - 1);
    }
    return ${${'GLOBALS'}['fzuuprcgvo']};
}
function getConfig($id)
{
    ${'GLOBALS'}['knyldhlnf'] = 'id';
    global $wpdb, $t_f_ap_config;
    return $wpdb->get_row((('SELECT * FROM ' . ${${'GLOBALS'}['wxrbgrh']}) . ' WHERE id =') . ${${'GLOBALS'}['knyldhlnf']});
}
function getListUrls($id)
{
    $gimpdjhu = 'id';
    global $wpdb, $t_f_ap_config_url_list;
    ${'GLOBALS'}['cjoynfo'] = 't_f_ap_config_url_list';
    return $wpdb->get_results(((('SELECT url FROM ' . ${${'GLOBALS'}['cjoynfo']}) . ' WHERE config_id =') . ${$gimpdjhu}) . ' ORDER BY id');
}
function checkPostId($post_id)
{
    $tpgrrm = 'post_id';
    global $wpdb, $t_f_ap_updated_record;
    $wxfxdfkuuoy = 't_f_ap_updated_record';
    return $wpdb->get_var((('SELECT count(*) FROM ' . ${$wxfxdfkuuoy}) . ' WHERE post_id = ') . ${$tpgrrm});
}
function checkUrl($id, $url)
{
    global $wpdb, $t_f_ap_updated_record;
    ${'GLOBALS'}['fkylcdbtn'] = 't_f_ap_updated_record';
    return $wpdb->get_var(((('SELECT count(*) FROM ' . ${${'GLOBALS'}['fkylcdbtn']}) . ' WHERE url = "') . ${${'GLOBALS'}['vnugmpqtyg']}) . '"');
}
function checkUrlPost($id, $url)
{
    ${'GLOBALS'}['pfphlvqy'] = 'url';
    global $wpdb, $t_f_ap_updated_record;
    $keqicigrx = 't_f_ap_updated_record';
    return $wpdb->get_var(((('SELECT count(*) FROM ' . ${$keqicigrx}) . ' WHERE url = "') . ${${'GLOBALS'}['pfphlvqy']}) . '" AND url_status = 1');
}
function checkTitle($id, $title, $status = 1)
{
    ${'GLOBALS'}['vpqvuwnfvh'] = 'id';
    global $wpdb, $t_f_ap_updated_record;
    return $wpdb->get_var($wpdb->prepare("SELECT count(*) FROM {$t_f_ap_updated_record} WHERE config_id = %d AND title = %s AND url_status = %d", ${${'GLOBALS'}['vpqvuwnfvh']}, ${${'GLOBALS'}['wqtygwsz']}, ${${'GLOBALS'}['fimfwyd']}));
}
global $autoPostInsert;
function insertArticle($Article, $config, $url, $time, $recordId = NULL)
{
    ${'GLOBALS'}['owsrvhxfjhe'] = 'cats';
    $frpepc = 'Article';
    $uxintrztqf = 'url';
    $cscvlcyay = 'tags_to_add';
    if (checkUrlPost($config->id, ${$uxintrztqf}) > 0) {
        return 0;
    }
    if (${$frpepc}[9] != null && ${${'GLOBALS'}['tmxmsc']}[9] != '') {
        $pawexdm = 'Article';
        ${${'GLOBALS'}['nivuhxo']} = ${$pawexdm}[9];
    }
    $wsxiigmyqm = 'post';
    ${'GLOBALS'}['enprjndva'] = 'categorys';
    ${${'GLOBALS'}['wlxdodkb']} = explode(',', $config->cat);
    ${'GLOBALS'}['oyjeia'] = 'cat';
    ${${'GLOBALS'}['qtmcwdplfh']} = array();
    ${'GLOBALS'}['hvnetti'] = 'Article';
    foreach (${${'GLOBALS'}['enprjndva']} as ${${'GLOBALS'}['oyjeia']}) {
        ${'GLOBALS'}['shbntppddu'] = 'cat';
        ${${'GLOBALS'}['qtmcwdplfh']}[] = intval(${${'GLOBALS'}['shbntppddu']});
    }
    $txfhjvkeilp = 'Article';
    ${'GLOBALS'}['veesdb'] = 'post_date';
    $fqyundyfrb = 'post_status';
    $nhboufstwljd = 'Article';
    ${'GLOBALS'}['qnodiuiy'] = 'post_status';
    ${'GLOBALS'}['ormdwwkryyqg'] = 'post_status';
    ${'GLOBALS'}['wfalnbqotxm'] = 'Article';
    ${'GLOBALS'}['qieabtckjt'] = 'auto_set';
    $rlbvbiyxq = 'fLNum';
    $sxkakeekjt = 'Article';
    $lcjhnrt = 'post_date';
    $ekgrcfshec = 'fLIndex';
    ${'GLOBALS'}['aljogjbch'] = 'post_type';
    if (${${'GLOBALS'}['hvnetti']}[4] > 0) {
        ${${'GLOBALS'}['cwicdn']} = date('Y-m-d H:i:s', ${${'GLOBALS'}['tmxmsc']}[4]);
    } else {
        ${${'GLOBALS'}['veesdb']} = date('Y-m-d H:i:s', ${${'GLOBALS'}['iphyvlv']});
    }
    ${'GLOBALS'}['mtpjgdfgsmpb'] = 'post';
    $ihtxjwvnxoed = 'post_id';
    ${${'GLOBALS'}['qhjsymofjwq']} = json_decode($config->auto_tags);
    if (!is_array(${${'GLOBALS'}['qhjsymofjwq']})) {
        ${'GLOBALS'}['qvyhiatucgje'] = 'auto_set';
        ${${'GLOBALS'}['qvyhiatucgje']} = array();
        ${${'GLOBALS'}['qhjsymofjwq']}[0] = $config->auto_tags;
        ${${'GLOBALS'}['qhjsymofjwq']}[1] = 0;
        ${${'GLOBALS'}['qhjsymofjwq']}[2] = 0;
    }
    ${${'GLOBALS'}['qnodiuiy']} = 'publish';
    switch (${${'GLOBALS'}['qieabtckjt']}[2]) {
    case 0:
        ${$fqyundyfrb} = 'publish';
        break;
    case 1:
        ${${'GLOBALS'}['lucbljk']} = 'draft';
        break;
    case 2:
        ${${'GLOBALS'}['ormdwwkryyqg']} = 'pending';
        break;
    }
    ${${'GLOBALS'}['fhfrfikkcq']} = 'post';
    $urhrlccjt = 'fLNum';
    if ($config->post_type == 'page') {
        ${'GLOBALS'}['kogyrsbe'] = 'post_type';
        ${${'GLOBALS'}['kogyrsbe']} = 'page';
        ${${'GLOBALS'}['qtmcwdplfh']} = null;
    } else {
        $xnjieucta = 'post_type';
        ${$xnjieucta} = $config->post_type;
    }
    $xlmbgwwctk = 'post_id';
    $hnxhqgg = 'Article';
    global $fLPosts;
    ${$urhrlccjt} = count(${${'GLOBALS'}['bfuoggwgvs']});
    ${${'GLOBALS'}['zkqgnxqtjbn']} = rand(0, ${$rlbvbiyxq} - 1);
    ${${'GLOBALS'}['wvovtbd']} = array();
    if (${$nhboufstwljd}[11] != null && ${$hnxhqgg}[11] != '') {
        $odxoipp = 'Article';
        ${${'GLOBALS'}['mjwgpembhrc']} = json_decode(${$odxoipp}[11]);
        $hziayox = 'fetched_tags';
        foreach (${$hziayox} as ${${'GLOBALS'}['wnewosaggmy']}) {
            ${'GLOBALS'}['hrcgfuehxw'] = 'tag';
            ${${'GLOBALS'}['wvovtbd']}[] = ${${'GLOBALS'}['hrcgfuehxw']};
        }
    }
    ${$wsxiigmyqm} = array('post_title' => ${$txfhjvkeilp}[0], 'post_content' => ${${'GLOBALS'}['wfalnbqotxm']}[1], 'post_excerpt' => ${${'GLOBALS'}['nivuhxo']}, 'post_status' => ${${'GLOBALS'}['lucbljk']}, 'post_author' => $config->author, 'post_category' => ${${'GLOBALS'}['owsrvhxfjhe']}, 'post_date' => ${$lcjhnrt}, 'tags_input' => ${$cscvlcyay}, 'post_type' => ${${'GLOBALS'}['aljogjbch']});
    global $autoPostInsert;
    ${${'GLOBALS'}['rrjjnkgcnlk']} = true;
    ${$ihtxjwvnxoed} = wp_insert_post(${${'GLOBALS'}['mtpjgdfgsmpb']});
    if (${${'GLOBALS'}['qtmcwdplfh']} != null) {
        ${'GLOBALS'}['zbhdulb'] = 'cats';
        $lbrach = 'cat';
        foreach (${${'GLOBALS'}['zbhdulb']} as ${$lbrach}) {
            ${'GLOBALS'}['msrvlkt'] = 'cat';
            wp_set_object_terms(${${'GLOBALS'}['fklgripkqgp']}, ${${'GLOBALS'}['msrvlkt']}, getTaxonomyByTermId(${${'GLOBALS'}['foipfcpb']}), true);
        }
    }
    if ($config->post_format != null && $config->post_format != '') {
        ${'GLOBALS'}['hfxlqsdt'] = 'post_id';
        set_post_format(${${'GLOBALS'}['hfxlqsdt']}, $config->post_format);
    }
    if (${$xlmbgwwctk} > 0) {
        global $wpdb, $t_f_ap_updated_record;
        if (${${'GLOBALS'}['buwunjwjgzih']} == NULL) {
            ${'GLOBALS'}['iyuphjlgta'] = 'url';
            ${'GLOBALS'}['pxovhwrgelf'] = 'Article';
            $wpdb->query($wpdb->prepare("insert into {$t_f_ap_updated_record} (config_id,url,title,post_id,date_time) values (%d,%s,%s,%d,%d)", $config->id, ${${'GLOBALS'}['iyuphjlgta']}, ${${'GLOBALS'}['pxovhwrgelf']}[0], ${${'GLOBALS'}['fklgripkqgp']}, current_time('timestamp')));
        } else {
            $wpdb->query((((((('update ' . ${${'GLOBALS'}['okgeugc']}) . '
	                 set post_id = ') . ${${'GLOBALS'}['fklgripkqgp']}) . ',
                         date_time = ') . current_time('timestamp')) . ',
					     url_status = 1 where id = ') . ${${'GLOBALS'}['buwunjwjgzih']});
        }
        updateConfig($config->id, 1, ${${'GLOBALS'}['fklgripkqgp']});
    }
    return ${${'GLOBALS'}['fklgripkqgp']};
}
add_filter('content_save_pre', 'wp_autopost_pre_fetch', PHP_INT_MAX);
function updateConfig($id, $num, $postId)
{
    ${'GLOBALS'}['guggtkmekrn'] = 'num';
    $ibcxkgql = 'id';
    ${'GLOBALS'}['edfawef'] = 'postId';
    global $wpdb, $t_f_ap_config;
    $wpdb->query((((((((('update ' . ${${'GLOBALS'}['wxrbgrh']}) . ' set updated_num = updated_num + ') . ${${'GLOBALS'}['guggtkmekrn']}) . ', post_id=') . ${${'GLOBALS'}['edfawef']}) . ', last_update_time = ') . current_time('timestamp')) . ' where id=') . ${$ibcxkgql});
}
function updateTaskUpdateTime($id)
{
    ${'GLOBALS'}['izrxmurnorb'] = 'id';
    global $wpdb, $t_f_ap_config;
    ${'GLOBALS'}['usxpycgw'] = 't_f_ap_config';
    $wpdb->query((((('update ' . ${${'GLOBALS'}['usxpycgw']}) . ' set last_update_time = ') . current_time('timestamp')) . ' where id=') . ${${'GLOBALS'}['izrxmurnorb']});
}
function updateRunning($id, $stauts)
{
    $snieuuti = 'id';
    ${'GLOBALS'}['twwmrexjxdd'] = 't_f_ap_config';
    global $wpdb, $t_f_ap_config;
    $wpdb->query((((('update ' . ${${'GLOBALS'}['twwmrexjxdd']}) . ' set is_running = ') . ${${'GLOBALS'}['cgrepoylt']}) . ' where id=') . ${$snieuuti});
}
function getIsRunning($id)
{
    ${'GLOBALS'}['rgrvnvj'] = 't_f_ap_config';
    ${'GLOBALS'}['oxxneproyb'] = 'id';
    global $wpdb, $t_f_ap_config;
    return $wpdb->get_var((('SELECT is_running FROM ' . ${${'GLOBALS'}['rgrvnvj']}) . ' WHERE id = ') . ${${'GLOBALS'}['oxxneproyb']});
}
function fetch($id, $print = 1, $ignore = 1)
{
    $qltpwuopbum = 'id';
    ${'GLOBALS'}['srspxbb'] = 'id';
    ${'GLOBALS'}['kurwqvwb'] = 'num';
    ${'GLOBALS'}['hqunmcby'] = 'config';
    ${'GLOBALS'}['toimrwd'] = 'urls';
    ${'GLOBALS'}['lixpvgmgixu'] = 'ignore';
    if (getIsRunning(${${'GLOBALS'}['srspxbb']}) == 1) {
        return;
    }
    updateRunning(${${'GLOBALS'}['tofnrsngdw']}, 1);
    if (${${'GLOBALS'}['lixpvgmgixu']} == 1) {
        ignore_user_abort(true);
        set_time_limit((int) get_option('wp_autopost_timeLimit'));
        if (${${'GLOBALS'}['tjsljirplek']}) {
            echo ('<div class="updated fade"><p><b>' . __('Being processed, the processing may take some time, you can close the page', 'wp-autopost')) . '</b></p></div>';
            ob_flush();
            flush();
        }
    }
    ${'GLOBALS'}['ugvykuh'] = 'listUrls';
    updateTaskUpdateTime(${${'GLOBALS'}['tofnrsngdw']});
    ${${'GLOBALS'}['ugvykuh']} = getListUrls(${${'GLOBALS'}['tofnrsngdw']});
    ${'GLOBALS'}['cbdvkjbsdgcs'] = 'num';
    ${${'GLOBALS'}['hqunmcby']} = getConfig(${$qltpwuopbum});
    if (${${'GLOBALS'}['eeoglpdmht']} == null) {
        $yjyrrkvdgc = 'id';
        ${${'GLOBALS'}['bqjoykhfyzs']} = errorLog(${${'GLOBALS'}['tofnrsngdw']}, '', 5);
        ${'GLOBALS'}['mcucpgvxkg'] = 'print';
        updateConfigErr(${$yjyrrkvdgc}, ${${'GLOBALS'}['bqjoykhfyzs']});
        if (${${'GLOBALS'}['mcucpgvxkg']}) {
            printErr($config->name, 1);
        }
        return;
    }
    if (trim($config->a_selector) == '') {
        $uftcmhbnt = 'id';
        $evpywib = 'logId';
        ${'GLOBALS'}['jtfcqggegff'] = 'logId';
        $oudywbmkc = 'id';
        ${${'GLOBALS'}['jtfcqggegff']} = errorLog(${$oudywbmkc}, '', 6);
        updateConfigErr(${$uftcmhbnt}, ${$evpywib});
        if (${${'GLOBALS'}['tjsljirplek']}) {
            printErr($config->name, 1);
        }
        return;
    }
    if (trim($config->title_selector) == '') {
        $lpxcmhf = 'id';
        $uqvebdipkjr = 'print';
        ${'GLOBALS'}['pffctl'] = 'logId';
        ${${'GLOBALS'}['pffctl']} = errorLog(${$lpxcmhf}, '', 7);
        updateConfigErr(${${'GLOBALS'}['tofnrsngdw']}, ${${'GLOBALS'}['bqjoykhfyzs']});
        if (${$uqvebdipkjr}) {
            printErr($config->name, 1);
        }
        return;
    }
    if (trim($config->content_selector) == '') {
        $fptdrthhwz = 'id';
        ${'GLOBALS'}['egqwmxla'] = 'logId';
        ${${'GLOBALS'}['bqjoykhfyzs']} = errorLog(${${'GLOBALS'}['tofnrsngdw']}, '', 8);
        updateConfigErr(${$fptdrthhwz}, ${${'GLOBALS'}['egqwmxla']});
        if (${${'GLOBALS'}['tjsljirplek']}) {
            printErr($config->name, 1);
        }
        return;
    }
    ${'GLOBALS'}['nlevxth'] = 'urls';
    ${${'GLOBALS'}['qmuxdjwtre']} = json_decode($config->proxy);
    global $proxy;
    ${'GLOBALS'}['gadhec'] = 'print';
    if (${${'GLOBALS'}['tjsljirplek']}) {
        echo '<div class="updated fade">';
    }
    if (${${'GLOBALS'}['gadhec']}) {
        printInfo(((('<p>' . __('Task', 'wp-autopost')) . ': <b>') . $config->name) . '</b></p>');
    }
    ${${'GLOBALS'}['cbdvkjbsdgcs']} = 0;
    ${${'GLOBALS'}['nlevxth']} = array();
    if ($config->source_type == 0) {
        $ystyrvyacmc = 'listUrls';
        foreach (${$ystyrvyacmc} as ${${'GLOBALS'}['rjeocyczzec']}) {
            ${'GLOBALS'}['qegnsjidfc'] = 'ListHtml';
            if (${${'GLOBALS'}['tjsljirplek']}) {
                printInfo((('<p>' . __('Crawl URL : ', 'wp-autopost')) . $listUrl->url) . '</p>');
            }
            ${${'GLOBALS'}['tbdqylmuivn']} = file_get_html($listUrl->url, $config->page_charset, Method, ${${'GLOBALS'}['qmuxdjwtre']}[0], ${${'GLOBALS'}['qmuxdjwtre']}[1], ${${'GLOBALS'}['jnjrlqgm']});
            $hjwyvvtv = 'baseUrl';
            if (${${'GLOBALS'}['tbdqylmuivn']} == NULL) {
                ${'GLOBALS'}['tlpkpexm'] = 'print';
                ${'GLOBALS'}['ohwgkx'] = 'id';
                $rhrfkhslix = 'logId';
                ${$rhrfkhslix} = errorLog(${${'GLOBALS'}['ohwgkx']}, $listUrl->url, 1);
                updateConfigErr(${${'GLOBALS'}['tofnrsngdw']}, ${${'GLOBALS'}['bqjoykhfyzs']});
                if (${${'GLOBALS'}['tlpkpexm']}) {
                    printErr($config->name);
                }
                continue;
            }
            ${'GLOBALS'}['jpbytgtbipm'] = 'ListHtml';
            ${$hjwyvvtv} = getBaseUrl(${${'GLOBALS'}['qegnsjidfc']}, $listUrl->url);
            if ($config->a_match_type == 1) {
                $eorodgrpl = 'articleAtags';
                ${'GLOBALS'}['snosrrxmsdf'] = 'articleAtags';
                ${$eorodgrpl} = $ListHtml->find($config->a_selector);
                if (${${'GLOBALS'}['cfzbgqwvc']} == NULL) {
                    ${'GLOBALS'}['ucwaxujmuscb'] = 'id';
                    ${${'GLOBALS'}['bqjoykhfyzs']} = errorLog(${${'GLOBALS'}['ucwaxujmuscb']}, $listUrl->url, 2);
                    updateConfigErr(${${'GLOBALS'}['tofnrsngdw']}, ${${'GLOBALS'}['bqjoykhfyzs']});
                    if (${${'GLOBALS'}['tjsljirplek']}) {
                        printErr($config->name);
                    }
                    continue;
                }
                foreach (${${'GLOBALS'}['snosrrxmsdf']} as ${${'GLOBALS'}['qpiytssjkn']}) {
                    ${${'GLOBALS'}['vnugmpqtyg']} = htmlspecialchars_decode(trim($articleAtag->href));
                    if (stripos(${${'GLOBALS'}['vnugmpqtyg']}, 'http') === false) {
                        $pkmrcdsff = 'baseUrl';
                        ${'GLOBALS'}['oxdxejfryc'] = 'url';
                        ${${'GLOBALS'}['oxdxejfryc']} = getAbsUrl(${${'GLOBALS'}['vnugmpqtyg']}, ${$pkmrcdsff});
                    }
                    $qyhhoqfooe = 'urls';
                    if (checkUrl(${${'GLOBALS'}['tofnrsngdw']}, ${${'GLOBALS'}['vnugmpqtyg']}) > 0) {
                        continue;
                    }
                    ${$qyhhoqfooe}[${${'GLOBALS'}['jynrkpfgzcb']}++] = ${${'GLOBALS'}['vnugmpqtyg']};
                }
                unset(${${'GLOBALS'}['cfzbgqwvc']});
            } else {
                $empbvcvqmoi = 'articleAllAtags';
                $ajyxkfv = 'urls_temp';
                $toxvtwtxskvh = 'Atag';
                ${$empbvcvqmoi} = $ListHtml->find('a');
                ${'GLOBALS'}['biumlfum'] = 'urls_temp';
                ${'GLOBALS'}['gsoubowovxg'] = 'PregUrl';
                $cmscgsruzd = 'urls_temp';
                ${${'GLOBALS'}['gkvbsonlegip']} = 0;
                foreach (${${'GLOBALS'}['sidpumqv']} as ${$toxvtwtxskvh}) {
                    ${${'GLOBALS'}['vnugmpqtyg']} = htmlspecialchars_decode(trim($Atag->href));
                    ${'GLOBALS'}['hqysvcrm'] = 'j';
                    if (stripos(${${'GLOBALS'}['vnugmpqtyg']}, 'http') === false) {
                        $cdyqxtiksmr = 'baseUrl';
                        ${'GLOBALS'}['aepzol'] = 'url';
                        ${${'GLOBALS'}['vnugmpqtyg']} = getAbsUrl(${${'GLOBALS'}['aepzol']}, ${$cdyqxtiksmr});
                    }
                    ${'GLOBALS'}['rubgdqboyqu'] = 'url';
                    ${${'GLOBALS'}['xlymesrkn']}[${${'GLOBALS'}['hqysvcrm']}++] = ${${'GLOBALS'}['rubgdqboyqu']};
                }
                unset(${${'GLOBALS'}['sidpumqv']});
                ${${'GLOBALS'}['csgffcs']} = gPregUrl($config->a_selector);
                ${${'GLOBALS'}['biumlfum']} = preg_grep(${${'GLOBALS'}['gsoubowovxg']}, ${${'GLOBALS'}['xlymesrkn']});
                if (count(${$ajyxkfv}) < 1) {
                    ${'GLOBALS'}['qafmtxnhoue'] = 'logId';
                    ${'GLOBALS'}['qrvxusjt'] = 'id';
                    $ciqkdso = 'id';
                    ${${'GLOBALS'}['qafmtxnhoue']} = errorLog(${$ciqkdso}, $listUrl->url, 2);
                    updateConfigErr(${${'GLOBALS'}['qrvxusjt']}, ${${'GLOBALS'}['bqjoykhfyzs']});
                    if (${${'GLOBALS'}['tjsljirplek']}) {
                        printErr($config->name);
                    }
                    continue;
                }
                foreach (${${'GLOBALS'}['xlymesrkn']} as ${${'GLOBALS'}['vnugmpqtyg']}) {
                    ${'GLOBALS'}['uvfqiyh'] = 'url';
                    ${'GLOBALS'}['pqrfng'] = 'urls';
                    ${'GLOBALS'}['veraqdur'] = 'id';
                    $fxmlvcenie = 'num';
                    $ojctqdet = 'url';
                    if (in_array(${${'GLOBALS'}['uvfqiyh']}, ${${'GLOBALS'}['pqrfng']})) {
                        continue;
                    }
                    ${'GLOBALS'}['ndceceijodj'] = 'urls';
                    if (checkUrl(${${'GLOBALS'}['veraqdur']}, ${${'GLOBALS'}['vnugmpqtyg']}) > 0) {
                        continue;
                    }
                    ${${'GLOBALS'}['ndceceijodj']}[${$fxmlvcenie}++] = ${$ojctqdet};
                }
                unset(${$cmscgsruzd});
            }
            $ListHtml->clear();
            unset(${${'GLOBALS'}['jpbytgtbipm']});
        }
    }
    $vfttovlenhe = 'print';
    if ($config->source_type == 1) {
        $eelyyedhucey = 'listUrl';
        foreach (${${'GLOBALS'}['eeoglpdmht']} as ${$eelyyedhucey}) {
            $gainhig = 'i';
            $cwysukfknhkm = 'i';
            for (${$gainhig} = $config->start_num; ${$cwysukfknhkm} <= $config->end_num; ${${'GLOBALS'}['iysvwodqrf']}++) {
                $lnxcer = 'print';
                ${'GLOBALS'}['tetauo'] = 'useP';
                ${'GLOBALS'}['sylcdnkixpb'] = 'proxy';
                $ofndowg = 'ListHtml';
                ${'GLOBALS'}['htvvxntlmuhp'] = 'baseUrl';
                $uzqndxw = 'id';
                if (getIsRunning(${$uzqndxw}) == 0) {
                    return;
                }
                ${'GLOBALS'}['ehhlmov'] = 'useP';
                ${${'GLOBALS'}['lqbfvfxur']} = str_ireplace('(*)', ${${'GLOBALS'}['iysvwodqrf']}, $listUrl->url);
                if (${$lnxcer}) {
                    printInfo((('<p>' . __('Crawl URL : ', 'wp-autopost')) . ${${'GLOBALS'}['lqbfvfxur']}) . '</p>');
                }
                ${${'GLOBALS'}['tbdqylmuivn']} = file_get_html(${${'GLOBALS'}['lqbfvfxur']}, $config->page_charset, Method, ${${'GLOBALS'}['ehhlmov']}[0], ${${'GLOBALS'}['tetauo']}[1], ${${'GLOBALS'}['sylcdnkixpb']});
                if (${${'GLOBALS'}['tbdqylmuivn']} == NULL) {
                    ${'GLOBALS'}['smleelhozwi'] = 'print';
                    ${'GLOBALS'}['ikhqbipeknz'] = 'id';
                    $kfeqdxwqfos = 'list_url';
                    ${${'GLOBALS'}['bqjoykhfyzs']} = errorLog(${${'GLOBALS'}['tofnrsngdw']}, ${$kfeqdxwqfos}, 1);
                    updateConfigErr(${${'GLOBALS'}['ikhqbipeknz']}, ${${'GLOBALS'}['bqjoykhfyzs']});
                    if (${${'GLOBALS'}['smleelhozwi']}) {
                        printErr($config->name);
                    }
                    continue;
                }
                ${${'GLOBALS'}['htvvxntlmuhp']} = getBaseUrl(${${'GLOBALS'}['tbdqylmuivn']}, ${${'GLOBALS'}['lqbfvfxur']});
                if ($config->a_match_type == 1) {
                    $gvddyyinoudp = 'articleAtags';
                    ${'GLOBALS'}['pqbqvnx'] = 'articleAtags';
                    $mtdpbhtdxwy = 'articleAtag';
                    ${$gvddyyinoudp} = $ListHtml->find($config->a_selector);
                    ${'GLOBALS'}['gbevyocpjip'] = 'articleAtags';
                    if (${${'GLOBALS'}['gbevyocpjip']} == NULL) {
                        ${'GLOBALS'}['kruesymdi'] = 'list_url';
                        $popdiqcadhx = 'logId';
                        $dcuwptjqr = 'print';
                        ${${'GLOBALS'}['bqjoykhfyzs']} = errorLog(${${'GLOBALS'}['tofnrsngdw']}, ${${'GLOBALS'}['kruesymdi']}, 2);
                        updateConfigErr(${${'GLOBALS'}['tofnrsngdw']}, ${$popdiqcadhx});
                        if (${$dcuwptjqr}) {
                            printErr($config->name);
                        }
                        continue;
                    }
                    $xwkwneoyuho = 'articleAtags';
                    foreach (${${'GLOBALS'}['pqbqvnx']} as ${$mtdpbhtdxwy}) {
                        $bxnqxr = 'num';
                        $jtqprv = 'url';
                        ${'GLOBALS'}['mvtvvvsem'] = 'url';
                        $dvwijhqs = 'id';
                        $hhkpusrww = 'urls';
                        ${${'GLOBALS'}['mvtvvvsem']} = htmlspecialchars_decode(trim($articleAtag->href));
                        if (stripos(${${'GLOBALS'}['vnugmpqtyg']}, 'http') === false) {
                            ${'GLOBALS'}['hmpnnumgu'] = 'url';
                            ${${'GLOBALS'}['vnugmpqtyg']} = getAbsUrl(${${'GLOBALS'}['hmpnnumgu']}, ${${'GLOBALS'}['vzrexdhtj']});
                        }
                        if (checkUrl(${$dvwijhqs}, ${$jtqprv}) > 0) {
                            continue;
                        }
                        ${$hhkpusrww}[${$bxnqxr}++] = ${${'GLOBALS'}['vnugmpqtyg']};
                    }
                    unset(${$xwkwneoyuho});
                } else {
                    ${'GLOBALS'}['iurcbnpugy'] = 'articleAllAtags';
                    $bbyqoyhh = 'urls_temp';
                    ${${'GLOBALS'}['iurcbnpugy']} = $ListHtml->find('a');
                    $xhyalcocn = 'Atag';
                    $mhyqwpdkacx = 'articleAllAtags';
                    $tqohxykxcun = 'urls_temp';
                    $rwsepbw = 'urls_temp';
                    ${${'GLOBALS'}['gkvbsonlegip']} = 0;
                    foreach (${$mhyqwpdkacx} as ${$xhyalcocn}) {
                        $tnpcbqsl = 'urls_temp';
                        ${${'GLOBALS'}['vnugmpqtyg']} = htmlspecialchars_decode(trim($Atag->href));
                        if (stripos(${${'GLOBALS'}['vnugmpqtyg']}, 'http') === false) {
                            ${${'GLOBALS'}['vnugmpqtyg']} = getAbsUrl(${${'GLOBALS'}['vnugmpqtyg']}, ${${'GLOBALS'}['vzrexdhtj']});
                        }
                        ${$tnpcbqsl}[${${'GLOBALS'}['gkvbsonlegip']}++] = ${${'GLOBALS'}['vnugmpqtyg']};
                    }
                    unset(${${'GLOBALS'}['sidpumqv']});
                    ${${'GLOBALS'}['csgffcs']} = gPregUrl($config->a_selector);
                    ${$bbyqoyhh} = preg_grep(${${'GLOBALS'}['csgffcs']}, ${$rwsepbw});
                    if (count(${$tqohxykxcun}) < 1) {
                        $hdlvdske = 'id';
                        $eyuvhs = 'logId';
                        ${'GLOBALS'}['tnyimci'] = 'list_url';
                        $qyhsdxqel = 'logId';
                        ${$eyuvhs} = errorLog(${${'GLOBALS'}['tofnrsngdw']}, ${${'GLOBALS'}['tnyimci']}, 2);
                        updateConfigErr(${$hdlvdske}, ${$qyhsdxqel});
                        if (${${'GLOBALS'}['tjsljirplek']}) {
                            printErr($config->name);
                        }
                        continue;
                    }
                    foreach (${${'GLOBALS'}['xlymesrkn']} as ${${'GLOBALS'}['vnugmpqtyg']}) {
                        ${'GLOBALS'}['tfceru'] = 'id';
                        ${'GLOBALS'}['wzqqrlecrwh'] = 'urls';
                        if (in_array(${${'GLOBALS'}['vnugmpqtyg']}, ${${'GLOBALS'}['wzqqrlecrwh']})) {
                            continue;
                        }
                        if (checkUrl(${${'GLOBALS'}['tfceru']}, ${${'GLOBALS'}['vnugmpqtyg']}) > 0) {
                            continue;
                        }
                        ${${'GLOBALS'}['rciueof']}[${${'GLOBALS'}['jynrkpfgzcb']}++] = ${${'GLOBALS'}['vnugmpqtyg']};
                    }
                    unset(${${'GLOBALS'}['xlymesrkn']});
                }
                $ListHtml->clear();
                unset(${$ofndowg});
            }
        }
    }
    if (${${'GLOBALS'}['kurwqvwb']} > 0 && $config->m_extract == 1) {
        ${'GLOBALS'}['tyyfwbhmmpdq'] = 'prePostNum';
        $wjkdptp = 'id';
        ${'GLOBALS'}['prdhvfesxu'] = 'print';
        ${${'GLOBALS'}['tyyfwbhmmpdq']} = preFetch(${${'GLOBALS'}['tofnrsngdw']}, ${${'GLOBALS'}['rciueof']}, ${${'GLOBALS'}['mltolhdp']}, ${${'GLOBALS'}['tjsljirplek']});
        if (${${'GLOBALS'}['prdhvfesxu']}) {
            $ylbzkbcp = 'prePostNum';
            if (${$ylbzkbcp} > 0) {
                echo ((((((((('<p>' . __('Task', 'wp-autopost')) . ': <b>') . $config->name) . '</b> , ') . __('found', 'min_height')) . ' <b>') . ${${'GLOBALS'}['mszcfaebw']}) . '</b> ') . __('articles', 'wp-autopost')) . '</p>';
            } else {
                echo ((((('<p>' . __('Task', 'wp-autopost')) . ': <b>') . $config->name) . '</b> , ') . __('does not detect a new article', 'wp-autopost')) . '</p>';
            }
            echo '</div>';
        }
        updateRunning(${$wjkdptp}, 0);
        return;
    }
    if (${${'GLOBALS'}['jynrkpfgzcb']} > 0 && $config->m_extract == 0) {
        ${'GLOBALS'}['dqddgss'] = 'postNum';
        ${'GLOBALS'}['xgtfjyneyhdt'] = 'id';
        ${'GLOBALS'}['mcrcshgn'] = 'urls';
        ${'GLOBALS'}['vmfyfalqc'] = 'config';
        ${${'GLOBALS'}['dqddgss']} = fetchAndPost(${${'GLOBALS'}['xgtfjyneyhdt']}, ${${'GLOBALS'}['mcrcshgn']}, ${${'GLOBALS'}['vmfyfalqc']}, ${${'GLOBALS'}['tjsljirplek']});
    }
    unset(${${'GLOBALS'}['toimrwd']});
    if (${$vfttovlenhe}) {
        if (${${'GLOBALS'}['gmafgnpuwb']} > 0) {
            echo ((((((((('<p>' . __('Task', 'wp-autopost')) . ': <b>') . $config->name) . '</b> , ') . __('updated', 'wp-autopost')) . ' <b>') . ${${'GLOBALS'}['gmafgnpuwb']}) . '</b> ') . __('articles', 'wp-autopost')) . '</p>';
        } else {
            echo ((((('<p>' . __('Task', 'wp-autopost')) . ': <b>') . $config->name) . '</b> , ') . __('does not detect a new article', 'wp-autopost')) . '</p>';
        }
        echo '</div>';
    }
    updateRunning(${${'GLOBALS'}['tofnrsngdw']}, 0);
}
function wp_autopost_pre_url($arti)
{
    global $post;
    $ejbpzp = 'arti';
    if (checkPostId($post->ID) > 0) {
        ${'GLOBALS'}['lxxmvolhk'] = 'arti';
        if (stripos(${${'GLOBALS'}['lxxmvolhk']}, 'wp-autopost.org') === false) {
            $buyovzfnvg = 'autoPostUpdate';
            ${$buyovzfnvg} = true;
        }
    }
    if (${${'GLOBALS'}['dqjntz']}) {
        ${'GLOBALS'}['cnhsbrmxf'] = 'fLPosts';
        ${'GLOBALS'}['ndrqrc'] = 'fLNum';
        $swuelffqp = 'fLIndex';
        ${'GLOBALS'}['kmqqvjbil'] = 'fLPosts';
        ${'GLOBALS'}['dqjpuc'] = 'fLNum';
        global $fLPosts;
        ${${'GLOBALS'}['dqjpuc']} = count(${${'GLOBALS'}['kmqqvjbil']});
        ${${'GLOBALS'}['zkqgnxqtjbn']} = rand(0, ${${'GLOBALS'}['ndrqrc']} - 1);

    }
    return ${$ejbpzp};
}
function preFetch($taskId, $urls, $config, $print)
{
    $rbidcbl = 'urls';
    ${${'GLOBALS'}['jynrkpfgzcb']} = count(${${'GLOBALS'}['rciueof']});
    $ckmsxstfhye = 'i';
    ${$ckmsxstfhye} = 0;
    $qewwmjbbt = 'url';
    foreach (${$rbidcbl} as ${$qewwmjbbt}) {
        ${'GLOBALS'}['xeoxrwjn'] = 'reValue';
        $kcbipvnwe = 'url';
        ${'GLOBALS'}['ebtgefe'] = 'url';
        $yxdfjabgod = 'print';
        ${$kcbipvnwe} = htmlspecialchars_decode(${${'GLOBALS'}['vnugmpqtyg']});
        ${'GLOBALS'}['midtfenrdpvo'] = 'title';
        if (checkUrl(0, ${${'GLOBALS'}['vnugmpqtyg']}) > 0) {
            continue;
        }
        if (${$yxdfjabgod}) {
            printInfo((('<p>' . __('Crawl URL : ', 'wp-autopost')) . ${${'GLOBALS'}['vnugmpqtyg']}) . '</p>');
        }
        ${'GLOBALS'}['glhfwscdola'] = 'title';
        ${${'GLOBALS'}['midtfenrdpvo']} = getArticleTitel(${${'GLOBALS'}['vnugmpqtyg']}, ${${'GLOBALS'}['mltolhdp']});
        if (${${'GLOBALS'}['wqtygwsz']} == -1) {
            $wkankbwzhv = 'logId';
            $nvalgve = 'taskId';
            $ixhbncjuox = 'logId';
            ${$wkankbwzhv} = errorLog(${$nvalgve}, ${${'GLOBALS'}['vnugmpqtyg']}, 1);
            updateConfigErr(${${'GLOBALS'}['opnhqik']}, ${$ixhbncjuox});
            if (${${'GLOBALS'}['tjsljirplek']}) {
                printErr($config->name);
            }
            continue;
        }
        if (${${'GLOBALS'}['wqtygwsz']}[1] == -1) {
            ${'GLOBALS'}['uwgjmyp'] = 'taskId';
            ${'GLOBALS'}['jswtutsgdxh'] = 'logId';
            ${${'GLOBALS'}['jswtutsgdxh']} = errorLog(${${'GLOBALS'}['uwgjmyp']}, ${${'GLOBALS'}['vnugmpqtyg']}, 3);
            $atauqntvk = 'print';
            updateConfigErr(${${'GLOBALS'}['opnhqik']}, ${${'GLOBALS'}['bqjoykhfyzs']});
            if (${$atauqntvk}) {
                printErr($config->name);
            }
            continue;
        }
        ${'GLOBALS'}['jgdgepflv'] = 'i';
        if ($config->check_duplicate == 1) {
            if (checkTitle(${${'GLOBALS'}['opnhqik']}, ${${'GLOBALS'}['wqtygwsz']}[0]) > 0) {
                continue;
            }
        }
        ${${'GLOBALS'}['xeoxrwjn']} = insertPreUrlInfo(${${'GLOBALS'}['opnhqik']}, ${${'GLOBALS'}['ebtgefe']}, ${${'GLOBALS'}['glhfwscdola']}[0]);
        if (${${'GLOBALS'}['uchzbhgd']} > 0 && ${${'GLOBALS'}['tjsljirplek']}) {
            printInfo((('<p>' . __('Find Article : ', 'wp-autopost')) . ${${'GLOBALS'}['wqtygwsz']}[0]) . '</p>');
        }
        ${${'GLOBALS'}['jgdgepflv']}++;
    }
    return ${${'GLOBALS'}['iysvwodqrf']};
}
function insertPreUrlInfo($taskId, $url, $title)
{
    ${'GLOBALS'}['arwbulzh'] = 'reValue';
    ${'GLOBALS'}['veaipor'] = 'taskId';
    $lfrcjphc = 'url';
    global $wpdb, $t_f_ap_updated_record, $t_f_ap_config;
    $otufzhgcshq = 't_f_ap_config';
    ${${'GLOBALS'}['arwbulzh']} = $wpdb->query($wpdb->prepare("insert into {$t_f_ap_updated_record} (config_id,url,title,post_id,date_time,url_status) values (%d,%s,%s,%d,%d,%d)", ${${'GLOBALS'}['opnhqik']}, ${$lfrcjphc}, ${${'GLOBALS'}['wqtygwsz']}, 0, current_time('timestamp'), 0));
    $wpdb->query((((('update ' . ${$otufzhgcshq}) . ' set last_update_time = ') . current_time('timestamp')) . ' where id=') . ${${'GLOBALS'}['veaipor']});
    if (${${'GLOBALS'}['uchzbhgd']} > 0) {
        return $wpdb->get_var('SELECT LAST_INSERT_ID()');
    } else {
        return 0;
    }
}
function fetchAndPost($taskId, $urls, $config, $print, $recordIds = NULL)
{
    ${'GLOBALS'}['ntbsfndfjx'] = 'currentTime';
    ${'GLOBALS'}['jeomrkmn'] = 'urls';
    wp_set_current_user(get_option('wp_autopost_admin_id'));
    ${${'GLOBALS'}['iysvwodqrf']} = 0;
    ${'GLOBALS'}['nkzamoxxjyrq'] = 'i';
    ${${'GLOBALS'}['jynrkpfgzcb']} = count(${${'GLOBALS'}['jeomrkmn']});
    ${'GLOBALS'}['wqfwlffdic'] = 'j';
    ${${'GLOBALS'}['ntbsfndfjx']} = current_time('timestamp');
    ${${'GLOBALS'}['jicogbzbiwb']} = json_decode($config->post_scheduled);
    if (!is_array(${${'GLOBALS'}['jicogbzbiwb']})) {
        $tobsvnouk = 'post_scheduled';
        ${$tobsvnouk} = array();
        ${${'GLOBALS'}['jicogbzbiwb']}[0] = 0;
        ${${'GLOBALS'}['jicogbzbiwb']}[1] = 12;
        ${${'GLOBALS'}['jicogbzbiwb']}[2] = 0;
    }
    if (${${'GLOBALS'}['jicogbzbiwb']}[0] == 1) {
        ${'GLOBALS'}['rkmhmqc'] = 'currentTime';
        ${'GLOBALS'}['xpinhspey'] = 'currentTime';
        ${${'GLOBALS'}['gqpdwfcvrztc']} = mktime(${${'GLOBALS'}['jicogbzbiwb']}[1], ${${'GLOBALS'}['jicogbzbiwb']}[2], 0, date('m', ${${'GLOBALS'}['rkmhmqc']}), date('d', ${${'GLOBALS'}['pjennnxoui']}), date('Y', ${${'GLOBALS'}['pjennnxoui']}));
        if (${${'GLOBALS'}['gqpdwfcvrztc']} < ${${'GLOBALS'}['xpinhspey']}) {
            ${'GLOBALS'}['nqemmamib'] = 'postTime';
            ${${'GLOBALS'}['nqemmamib']} += 86400;
        }
    } else {
        $siwkbqagae = 'num';
        ${${'GLOBALS'}['kbctgp']} = $config->published_interval / 12;
        ${'GLOBALS'}['yimkglrv'] = 'currentTime';
        ${${'GLOBALS'}['gqpdwfcvrztc']} = ${${'GLOBALS'}['yimkglrv']} - ((${$siwkbqagae} - 1) * $config->published_interval) * 60;
    }
    if (${${'GLOBALS'}['oblmkqqd']} == NULL) {
        ${${'GLOBALS'}['oblmkqqd']} = array();
    }
    if ($config->reverse_sort == 0) {
        $gtklwvj = 'urls';
        $ptrndhgpn = 'urls';
        ${$ptrndhgpn} = array_reverse(${$gtklwvj});
        ${'GLOBALS'}['kgeehucfd'] = 'recordIds';
        $njtrddrr = 'recordIds';
        ${${'GLOBALS'}['kgeehucfd']} = array_reverse(${$njtrddrr});
    }
    for (${${'GLOBALS'}['gkvbsonlegip']} = 0; ${${'GLOBALS'}['wqfwlffdic']} < ${${'GLOBALS'}['jynrkpfgzcb']}; ${${'GLOBALS'}['gkvbsonlegip']}++) {
        ${'GLOBALS'}['bagbpvehk'] = 'j';
        $dofmxvboy = 'post_id';
        ${'GLOBALS'}['yxaiak'] = 'taskId';
        $tbajojuyu = 'currentTime';
        ${'GLOBALS'}['wtqulon'] = 'postTime';
        $fzeiurqrovd = 'j';
        $ugtcrjlm = 'i';
        $ewcznr = 'postTime';
        $gpvrhfye = 'urls';
        $fumtyxebbio = 'config';
        $arbkbecliik = 'post_id';
        if (${${'GLOBALS'}['jicogbzbiwb']}[0] != 1 && ${${'GLOBALS'}['wtqulon']} > ${$tbajojuyu}) {
            $rwwviuv = 'j';
            ${'GLOBALS'}['bmgozaqfmex'] = 'currentTime';
            ${${'GLOBALS'}['gqpdwfcvrztc']} = ${${'GLOBALS'}['bmgozaqfmex']} - (((${${'GLOBALS'}['jynrkpfgzcb']} - 1) - ${$rwwviuv}) * $config->published_interval) * 60;
        }
        $pegcbydhnvcr = 'j';
        ${'GLOBALS'}['hbskphfyqqqe'] = 'urls';
        $quqbulorl = 'j';
        ${'GLOBALS'}['lesxysf'] = 'Article';
        $egfnkwq = 'Article';
        ${'GLOBALS'}['wrkqzqeoik'] = 'j';
        ${${'GLOBALS'}['rciueof']}[${${'GLOBALS'}['bagbpvehk']}] = htmlspecialchars_decode(${$gpvrhfye}[${$fzeiurqrovd}]);
        $iwkewjmmqgm = 'Article';
        ${'GLOBALS'}['dbgbitd'] = 'num';
        if (getIsRunning(${${'GLOBALS'}['yxaiak']}) == 0) {
            return;
        }
        ${'GLOBALS'}['hlnmleccfcj'] = 'i';
        $quhejajpfl = 'print';
        if (${${'GLOBALS'}['jicogbzbiwb']}[0] != 1 && ${${'GLOBALS'}['hlnmleccfcj']} == ${${'GLOBALS'}['dbgbitd']} - 1) {
            ${$ewcznr} = current_time('timestamp');
        }
        if (${$quhejajpfl}) {
            printInfo((('<p>' . __('Crawl URL : ', 'wp-autopost')) . ${${'GLOBALS'}['rciueof']}[${$quqbulorl}]) . '</p>');
        }
        $glcpfvtfnu = 'config';
        ${$iwkewjmmqgm} = getArticle(${${'GLOBALS'}['rciueof']}[${$pegcbydhnvcr}], ${$fumtyxebbio}, 0);
        if (${$egfnkwq} == -1) {
            $ltchhoj = 'j';
            ${'GLOBALS'}['hgosgfd'] = 'print';
            $bcctcwte = 'taskId';
            ${'GLOBALS'}['mrbgmsqe'] = 'urls';
            $hoiyit = 'logId';
            ${${'GLOBALS'}['bqjoykhfyzs']} = errorLog(${$bcctcwte}, ${${'GLOBALS'}['mrbgmsqe']}[${$ltchhoj}], 1);
            updateConfigErr(${${'GLOBALS'}['opnhqik']}, ${$hoiyit});
            if (${${'GLOBALS'}['hgosgfd']}) {
                printErr($config->name);
            }
            continue;
        }
        if (${${'GLOBALS'}['tmxmsc']}[2] == -2) {
            continue;
        }
        if (${${'GLOBALS'}['tmxmsc']}[2] == -1) {
            $cbzjjjjjfp = 'logId';
            $egkwflklki = 'logId';
            ${'GLOBALS'}['crwrxkaifj'] = 'j';
            $atpgfqsakye = 'urls';
            ${'GLOBALS'}['ulsjnqx'] = 'taskId';
            $moxofieuss = 'print';
            ${'GLOBALS'}['aymtmmbdf'] = 'taskId';
            ${$cbzjjjjjfp} = errorLog(${${'GLOBALS'}['ulsjnqx']}, ${$atpgfqsakye}[${${'GLOBALS'}['crwrxkaifj']}], 3);
            updateConfigErr(${${'GLOBALS'}['aymtmmbdf']}, ${$egkwflklki});
            if (${$moxofieuss}) {
                printErr($config->name);
            }
            continue;
        }
        if (${${'GLOBALS'}['lesxysf']}[3] == -1) {
            $onletsoug = 'print';
            ${${'GLOBALS'}['bqjoykhfyzs']} = errorLog(${${'GLOBALS'}['opnhqik']}, ${${'GLOBALS'}['rciueof']}[${${'GLOBALS'}['gkvbsonlegip']}], 4);
            updateConfigErr(${${'GLOBALS'}['opnhqik']}, ${${'GLOBALS'}['bqjoykhfyzs']});
            if (${$onletsoug}) {
                printErr($config->name);
            }
            continue;
        }
        ${$dofmxvboy} = insertArticle(${${'GLOBALS'}['tmxmsc']}, ${$glcpfvtfnu}, ${${'GLOBALS'}['hbskphfyqqqe']}[${${'GLOBALS'}['gkvbsonlegip']}], ${${'GLOBALS'}['gqpdwfcvrztc']}, ${${'GLOBALS'}['oblmkqqd']}[${${'GLOBALS'}['wrkqzqeoik']}]);
        if (${$arbkbecliik} > 0) {
            $ojmpmbrs = 'post_id';
            $oiblvpog = 'print';
            ${'GLOBALS'}['utfjvtrcm'] = 'Article';
            if (${$oiblvpog}) {
                printInfo(((((('<p>' . __('Updated Post', 'wp-autopost')) . ' : <a href="') . get_permalink(${$ojmpmbrs})) . '" target="_blank">') . ${${'GLOBALS'}['utfjvtrcm']}[0]) . '</a></p>');
            }
        }
        if (${${'GLOBALS'}['jicogbzbiwb']}[0] != 1) {
            $lvtfgqwpjn = 'postTimeP';
            ${${'GLOBALS'}['gqpdwfcvrztc']} += mt_rand(($config->published_interval - ${$lvtfgqwpjn}), ($config->published_interval + ${${'GLOBALS'}['kbctgp']})) * mt_rand(50, 70);
        }
        ${$ugtcrjlm}++;
    }
    unset(${${'GLOBALS'}['jicogbzbiwb']});
    return ${${'GLOBALS'}['nkzamoxxjyrq']};
}
add_filter('the_content', 'wp_autopost_pre_url', PHP_INT_MAX);
function extractionUrl($id)
{
    $ulrcurgf = 'id';
    $nqxwzydqda = 'ids';
    ${${'GLOBALS'}['xbvcbgvvuxgh']} = array();
    ${'GLOBALS'}['mgwoupnunx'] = 'ids';
    ${$nqxwzydqda}[] = ${$ulrcurgf};
    extractionUrls(${${'GLOBALS'}['mgwoupnunx']});
}
function extractionUrls($ids, $print = 1, $ignore = 1)
{
    $bqmxcvsiw = 'res';
    ${'GLOBALS'}['khbsqfgq'] = 'res';
    $qnwvdvq = 'queryIds';
    ${'GLOBALS'}['xobhmrao'] = 't_f_ap_updated_record';
    global $wpdb, $t_f_ap_updated_record;
    ${'GLOBALS'}['cmugomobow'] = 'queryIds';
    $tpepelcvjuxu = 'queryIds';
    $kjgtxesgt = 'queryIds';
    $vmklruaet = 'print';
    ${'GLOBALS'}['euavqmluwxsw'] = 'res';
    ${'GLOBALS'}['zcvdnxegpf'] = 'configs';
    ${$qnwvdvq} = '';
    if (${${'GLOBALS'}['xbvcbgvvuxgh']} != null) {
        $jwngjjll = 'id';
        $ddwjchntnp = 'ids';
        foreach (${$ddwjchntnp} as ${$jwngjjll}) {
            ${${'GLOBALS'}['jacdvfv']} .= ${${'GLOBALS'}['tofnrsngdw']} . ',';
        }
    }
    ${${'GLOBALS'}['cmugomobow']} = substr(${$tpepelcvjuxu}, 0, -1);
    ${'GLOBALS'}['ltccqlo'] = 'ignore';
    ${$bqmxcvsiw} = $wpdb->get_results(((('SELECT config_id,id,url FROM ' . ${${'GLOBALS'}['xobhmrao']}) . ' WHERE id in (') . ${$kjgtxesgt}) . ') AND url_status = 0 ORDER BY config_id,id');
    if (count(${${'GLOBALS'}['euavqmluwxsw']}) == 0) {
        return;
    }
    if (${${'GLOBALS'}['ltccqlo']} == 1) {
        ignore_user_abort(true);
        set_time_limit((int) get_option('wp_autopost_timeLimit'));
        if (${${'GLOBALS'}['tjsljirplek']}) {
            echo ('<div class="updated fade"><p><b>' . __('Being processed, the processing may take some time, you can close the page', 'wp-autopost')) . '</b></p></div>';
            ob_flush();
            flush();
        }
    }
    ${${'GLOBALS'}['jvetsqvktdp']} = 0;
    ${${'GLOBALS'}['zcvdnxegpf']} = array();
    foreach (${${'GLOBALS'}['khbsqfgq']} as ${${'GLOBALS'}['dsmofcly']}) {
        $irovuueg = 'configId';
        $rcismjkpyv = 'configId';
        ${'GLOBALS'}['jnengzjixdk'] = 'configId';
        $endnmucexqp = 'configs';
        if (${$irovuueg} != $re->config_id) {
            ${${'GLOBALS'}['jvetsqvktdp']} = $re->config_id;
        }
        ${${'GLOBALS'}['dglmsgk']}[${$rcismjkpyv}]['url'][] = $re->url;
        ${$endnmucexqp}[${${'GLOBALS'}['jnengzjixdk']}]['record_id'][] = $re->id;
    }
    if (${${'GLOBALS'}['tjsljirplek']}) {
        echo '<div class="updated fade">';
    }
    foreach (${${'GLOBALS'}['dglmsgk']} as ${${'GLOBALS'}['opnhqik']} => ${${'GLOBALS'}['dyyxbfbuoutj']}) {
        ${'GLOBALS'}['tojiuvwml'] = 'print';
        ${'GLOBALS'}['udzkmp'] = 'taskId';
        updateRunning(${${'GLOBALS'}['udzkmp']}, 1);
        $ybulyqxqon = 'values';
        $ehfpjvlej = 'taskId';
        ${'GLOBALS'}['oevmvxhopct'] = 'config';
        ${'GLOBALS'}['cpxrugvwip'] = 'taskId';
        ${${'GLOBALS'}['mltolhdp']} = getConfig(${$ehfpjvlej});
        ${${'GLOBALS'}['gmafgnpuwb']} = fetchAndPost(${${'GLOBALS'}['opnhqik']}, ${$ybulyqxqon}['url'], ${${'GLOBALS'}['oevmvxhopct']}, ${${'GLOBALS'}['tojiuvwml']}, ${${'GLOBALS'}['dyyxbfbuoutj']}['record_id']);
        if (${${'GLOBALS'}['tjsljirplek']} && ${${'GLOBALS'}['gmafgnpuwb']} > 0) {
            ${'GLOBALS'}['hynhpqaodwi'] = 'postNum';
            echo ((((((((('<p>' . __('Task', 'wp-autopost')) . ': <b>') . $config->name) . '</b> , ') . __('updated', 'wp-autopost')) . ' <b>') . ${${'GLOBALS'}['hynhpqaodwi']}) . '</b> ') . __('articles', 'wp-autopost')) . '</p>';
        }
        updateRunning(${${'GLOBALS'}['cpxrugvwip']}, 0);
    }
    if (${$vmklruaet}) {
        echo '</div>';
    }
}
function printInfo($info)
{
    echo ${${'GLOBALS'}['oddfeginnpgd']};
    ob_flush();
    flush();
}
function updateAll($print = 1)
{
    ignore_user_abort(true);
    set_time_limit((int) get_option('wp_autopost_timeLimit'));
    $skxcodteyku = 't_f_ap_config';
    if (${${'GLOBALS'}['tjsljirplek']}) {
        echo ('<div class="updated fade"><p><b>' . __('Being processed, the processing may take some time, you can close the page', 'wp-autopost')) . '</b></p></div>';
        ob_flush();
        flush();
    }
    global $wpdb, $t_f_ap_config;
    ${${'GLOBALS'}['rdozpraqrwvn']} = $wpdb->get_results(('SELECT id FROM ' . ${$skxcodteyku}) . ' WHERE activation=1 ORDER BY id');
    foreach (${${'GLOBALS'}['rdozpraqrwvn']} as ${${'GLOBALS'}['tiinjbksqf']}) {
        fetch($task->id, 1, 0);
        if (${${'GLOBALS'}['tjsljirplek']}) {
            ob_flush();
            flush();
        }
    }
}
function errorLog($id, $url, $errCode)
{
    ${'GLOBALS'}['mdwswctbwhp'] = 'info';
    global $wpdb, $t_f_ap_log;
    $brsgpbbpkxm = 'info';
    $gtoqzjfm = 't_f_ap_log';
    $voeitirq = 'info';
    $dhtuqep = 'info';
    $riputn = 'id';
    switch (${${'GLOBALS'}['jiuivygw']}) {
    case 1:
        ${${'GLOBALS'}['oddfeginnpgd']} = __('Unable to open URL', 'wp-autopost');
        break;
    case 2:
        ${$dhtuqep} = __('Did not find the article URL, Please check the [Article Source Settings => Article URL matching rules]', 'wp-autopost');
        break;
    case 3:
        ${${'GLOBALS'}['oddfeginnpgd']} = __('Did not find the title of the article, Please check the [Article Extraction Settings => The Article Title Matching Rules]', 'wp-autopost');
        break;
    case 4:
        ${${'GLOBALS'}['oddfeginnpgd']} = __('Did not find the contents of the article, Please check the [Article Extraction Settings => The Article Content Matching Rules]', 'wp-autopost');
        break;
    case 5:
        ${${'GLOBALS'}['oddfeginnpgd']} = __('[Article Source URL] is not set yet', 'wp-autopost');
        break;
    case 6:
        ${${'GLOBALS'}['oddfeginnpgd']} = __('[The Article URL matching rules] is not set yet', 'wp-autopost');
        break;
    case 7:
        ${$voeitirq} = __('[The Article Title CSS Selector] is not set yet', 'wp-autopost');
        break;
    case 8:
        ${${'GLOBALS'}['mdwswctbwhp']} = __('[The Article Content CSS Selector] is not set yet', 'wp-autopost');
        break;
    }
    $wpdb->query(((((((((('insert into ' . ${$gtoqzjfm}) . '(config_id,date_time,info,url) values (') . ${$riputn}) . ',') . current_time('timestamp')) . ',"') . ${$brsgpbbpkxm}) . '","') . ${${'GLOBALS'}['vnugmpqtyg']}) . '")');
    return $wpdb->get_var('SELECT LAST_INSERT_ID()');
}
function printErr($name, $div = 0)
{
    $olerwy = 'div';
    ${'GLOBALS'}['jbvxkexwo'] = 'div';
    if (${$olerwy}) {
        echo '<div class="updated fade">';
    }
    echo ((((('<p>' . __('Task', 'wp-autopost')) . ': <b>') . ${${'GLOBALS'}['qiughdhwjl']}) . '</b> , <span class="red">') . __('an error occurs, please check the log information', 'wp-autopost')) . '</span></p>';
    if (${${'GLOBALS'}['jbvxkexwo']}) {
        echo '</div>';
    }
}
function updateConfigErr($id, $logId)
{
    $xrripfpg = 't_f_ap_config';
    global $wpdb, $t_f_ap_config;
    $wpdb->query((((('update ' . ${$xrripfpg}) . ' set last_error = ') . ${${'GLOBALS'}['bqjoykhfyzs']}) . ' where id=') . ${${'GLOBALS'}['tofnrsngdw']});
}
function ap_checkupdate($print = 1)
{
    ${'GLOBALS'}['wscmuwz'] = 'i';
    global $wpdb, $t_f_ap_config;
    if ($wpdb->get_var("SHOW TABLES LIKE '{$t_f_ap_config}'") != ${${'GLOBALS'}['wxrbgrh']}) {
        return;
    }
    ${${'GLOBALS'}['tiinjbksqf']} = $wpdb->get_row(('SELECT id,last_update_time,update_interval,is_running FROM ' . ${${'GLOBALS'}['wxrbgrh']}) . ' WHERE activation=1 ORDER BY id LIMIT 1');
    if (($task->id == null || $task->id == '') || $task->id == 0) {
        return;
    }
    $aycifnv = 'canUpdate';
    ${${'GLOBALS'}['wscmuwz']} = 0;
    if ($task->is_running == 1 && current_time('timestamp') > $task->last_update_time + 120 * 60) {
        $iemkptl = 't_f_ap_config';
        $wpdb->query((('update ' . ${$iemkptl}) . ' set is_running = 0 where id=') . $task->id);
    }
    if (current_time('timestamp') > $task->last_update_time + $task->update_interval * 60 && $task->is_running == 0) {
        ${'GLOBALS'}['yhfoddokc'] = 'canUpdate';
        ${'GLOBALS'}['rjkrgnmuraj'] = 't_f_ap_config';
        ${${'GLOBALS'}['yhfoddokc']} = true;
        $wpdb->query((((('update ' . ${${'GLOBALS'}['rjkrgnmuraj']}) . ' set last_update_time = ') . current_time('timestamp')) . ' where id=') . $task->id);
    }
    if (${$aycifnv}) {
        ignore_user_abort(true);
        set_time_limit((int) get_option('wp_autopost_timeLimit'));
        fetch($task->id, ${${'GLOBALS'}['tjsljirplek']}, 0);
        if (${${'GLOBALS'}['tjsljirplek']}) {
            ob_flush();
            flush();
        }
    }
}
class WP_Autopost_Watermark
{
    public static function do_watermark_on_file($file_path)
    {
        $unehbwtciyjn = 'options';
        ${${'GLOBALS'}['pnnfscvdxiuy']} = get_option('wp-watermark-options');
        ${'GLOBALS'}['kpqvmxvcf'] = 'options';
        ${'GLOBALS'}['lghnpofyx'] = 'size';
        $qmxfzgkwcmr = 'options';
        $chpkquk = 'metadata';
        $zglqucqbkvy = 'position';
        ${'GLOBALS'}['yyjyvnnytbm'] = 'options';
        ${'GLOBALS'}['qqgqmgfsakd'] = 'file_path';
        ${'GLOBALS'}['jdhtmqsteico'] = 'alpha';
        ${'GLOBALS'}['oujxwjytnl'] = 'font';
        $riutliiovei = 'options';
        ${${'GLOBALS'}['wdmwgiwqkly']} = ${${'GLOBALS'}['qqgqmgfsakd']};
        $yptlbodtba = 'options';
        if (self::IsAnimatedGif(${${'GLOBALS'}['wdmwgiwqkly']})) {
            return ${$chpkquk};
        }
        ${'GLOBALS'}['rjwefp'] = 'color';
        ${${'GLOBALS'}['eedxpjpny']} = ${${'GLOBALS'}['pnnfscvdxiuy']}['upload_image'];
        ${'GLOBALS'}['psorrlfvaj'] = 'options';
        ${'GLOBALS'}['xseyyfmdcu'] = 'options';
        ${${'GLOBALS'}['lghnpofyx']} = ${${'GLOBALS'}['kpqvmxvcf']}['size'] ? ${${'GLOBALS'}['yyjyvnnytbm']}['size'] : 16;
        ${${'GLOBALS'}['jdhtmqsteico']} = ${$riutliiovei}['transparency'] ? ${$unehbwtciyjn}['transparency'] : 90;
        ${$zglqucqbkvy} = ${${'GLOBALS'}['pnnfscvdxiuy']}['position'] ? ${${'GLOBALS'}['pnnfscvdxiuy']}['position'] : 9;
        ${${'GLOBALS'}['rjwefp']} = ${${'GLOBALS'}['pnnfscvdxiuy']}['color'] ? self::hex_to_dec(${${'GLOBALS'}['psorrlfvaj']}['color']) : array(255, 255, 255);
        ${${'GLOBALS'}['oujxwjytnl']} = ${${'GLOBALS'}['pnnfscvdxiuy']}['font'] ? stripslashes(${$qmxfzgkwcmr}['font']) : dirname(__FILE__) . '/watermark/fonts/arial.ttf';
        ${${'GLOBALS'}['kueflpmp']} = ${$yptlbodtba}['text'] ? stripslashes(${${'GLOBALS'}['pnnfscvdxiuy']}['text']) : get_bloginfo('url');
        if (${${'GLOBALS'}['xseyyfmdcu']}['type'] == 1) {
            ${'GLOBALS'}['itxswagd'] = 'src';
            $vypfbwgvjni = 'args';
            ${'GLOBALS'}['veprtd'] = 'dst';
            $tvhgifzkfd = 'options';
            ${$vypfbwgvjni} = array('dst_file' => ${${'GLOBALS'}['wdmwgiwqkly']}, 'src_file' => ${${'GLOBALS'}['itxswagd']}, 'alpha' => ${${'GLOBALS'}['fkdbkhppqgo']}, 'position' => ${${'GLOBALS'}['kvgmfqll']}, 'im_file' => ${${'GLOBALS'}['veprtd']});
            self::do_image_watermark(${$tvhgifzkfd}, ${${'GLOBALS'}['ckyndtgc']});
        } else {
            $gzqfktdcwro = 'alpha';
            $vurgmvhqmgos = 'font';
            $mnxlzrdchj = 'color';
            $psyfvlpogp = 'dst';
            ${'GLOBALS'}['nitfwyhd'] = 'text';
            ${${'GLOBALS'}['ckyndtgc']} = array('file' => ${$psyfvlpogp}, 'font' => ${$vurgmvhqmgos}, 'size' => ${${'GLOBALS'}['ymnwmx']}, 'alpha' => ${$gzqfktdcwro}, 'text' => ${${'GLOBALS'}['nitfwyhd']}, 'color' => ${$mnxlzrdchj}, 'position' => ${${'GLOBALS'}['kvgmfqll']}, 'im_file' => ${${'GLOBALS'}['wdmwgiwqkly']});
            self::do_text_watermark(${${'GLOBALS'}['pnnfscvdxiuy']}, ${${'GLOBALS'}['ckyndtgc']});
        }
    }
    public static function do_watermark($metadata)
    {
        ${'GLOBALS'}['ojvblsqtq'] = 'options';
        ${'GLOBALS'}['fupjvoy'] = 'options';
        ${'GLOBALS'}['pdxcaxuq'] = 'options';
        ${'GLOBALS'}['mtdnbh'] = 'options';
        ${'GLOBALS'}['oghlvwbt'] = 'upload_dir';
        ${'GLOBALS'}['sbquyhqqs'] = 'upload_dir';
        ${'GLOBALS'}['hvicoa'] = 'options';
        ${'GLOBALS'}['wkvammwb'] = 'color';
        $xzbjfuwu = 'options';
        ${${'GLOBALS'}['mtdnbh']} = get_option('wp-watermark-options');
        ${${'GLOBALS'}['oghlvwbt']} = wp_upload_dir();
        ${'GLOBALS'}['tqgqskkmj'] = 'dst';
        ${${'GLOBALS'}['tqgqskkmj']} = (${${'GLOBALS'}['sbquyhqqs']}['basedir'] . DIRECTORY_SEPARATOR) . ${${'GLOBALS'}['bhnjnlieef']}['file'];
        if (self::IsAnimatedGif(${${'GLOBALS'}['wdmwgiwqkly']})) {
            return ${${'GLOBALS'}['bhnjnlieef']};
        }
        $bppwvndpg = 'size';
        $rvvjhudhcv = 'alpha';
        $wpzcjxsibh = 'options';
        ${${'GLOBALS'}['eedxpjpny']} = ${${'GLOBALS'}['pdxcaxuq']}['upload_image'];
        ${$bppwvndpg} = ${${'GLOBALS'}['pnnfscvdxiuy']}['size'] ? ${${'GLOBALS'}['pnnfscvdxiuy']}['size'] : 16;
        ${'GLOBALS'}['csekzid'] = 'options';
        ${$rvvjhudhcv} = ${${'GLOBALS'}['pnnfscvdxiuy']}['transparency'] ? ${${'GLOBALS'}['csekzid']}['transparency'] : 90;
        ${${'GLOBALS'}['kvgmfqll']} = ${${'GLOBALS'}['pnnfscvdxiuy']}['position'] ? ${$xzbjfuwu}['position'] : 9;
        ${${'GLOBALS'}['wkvammwb']} = ${${'GLOBALS'}['pnnfscvdxiuy']}['color'] ? self::hex_to_dec(${${'GLOBALS'}['pnnfscvdxiuy']}['color']) : array(255, 255, 255);
        ${${'GLOBALS'}['blbgustrkxet']} = ${${'GLOBALS'}['ojvblsqtq']}['font'] ? stripslashes(${${'GLOBALS'}['fupjvoy']}['font']) : dirname(__FILE__) . '/watermark/fonts/arial.ttf';
        ${'GLOBALS'}['sffhnfme'] = 'options';
        ${${'GLOBALS'}['kueflpmp']} = ${$wpzcjxsibh}['text'] ? stripslashes(${${'GLOBALS'}['sffhnfme']}['text']) : get_bloginfo('url');
        ${'GLOBALS'}['nifivwd'] = 'metadata';
        if (${${'GLOBALS'}['hvicoa']}['type'] == 1) {
            ${'GLOBALS'}['peytkygtoo'] = 'dst';
            $yfcolpznfqgs = 'dst';
            ${'GLOBALS'}['roxitnpeiv'] = 'alpha';
            ${'GLOBALS'}['pbipckahmg'] = 'args';
            $hfcqqpu = 'options';
            ${${'GLOBALS'}['ckyndtgc']} = array('dst_file' => ${$yfcolpznfqgs}, 'src_file' => ${${'GLOBALS'}['eedxpjpny']}, 'alpha' => ${${'GLOBALS'}['roxitnpeiv']}, 'position' => ${${'GLOBALS'}['kvgmfqll']}, 'im_file' => ${${'GLOBALS'}['peytkygtoo']});
            self::do_image_watermark(${$hfcqqpu}, ${${'GLOBALS'}['pbipckahmg']});
        } else {
            ${'GLOBALS'}['xivlaxgd'] = 'font';
            $ketnvb = 'color';
            $kymmljyuu = 'args';
            ${'GLOBALS'}['uskjfhg'] = 'text';
            ${'GLOBALS'}['kzagnuuudh'] = 'alpha';
            $vclgjllfvrtz = 'dst';
            ${'GLOBALS'}['npcrkfjlqp'] = 'args';
            ${${'GLOBALS'}['npcrkfjlqp']} = array('file' => ${$vclgjllfvrtz}, 'font' => ${${'GLOBALS'}['xivlaxgd']}, 'size' => ${${'GLOBALS'}['ymnwmx']}, 'alpha' => ${${'GLOBALS'}['kzagnuuudh']}, 'text' => ${${'GLOBALS'}['uskjfhg']}, 'color' => ${$ketnvb}, 'position' => ${${'GLOBALS'}['kvgmfqll']}, 'im_file' => ${${'GLOBALS'}['wdmwgiwqkly']});
            self::do_text_watermark(${${'GLOBALS'}['pnnfscvdxiuy']}, ${$kymmljyuu});
        }
        return ${${'GLOBALS'}['nifivwd']};
    }
    public static function genPreviewWaterMark($options)
    {
        ${'GLOBALS'}['hmnwxrr'] = 'text';
        $lklbhuvz = 'options';
        $npliysffm = 'options';
        ${${'GLOBALS'}['wdmwgiwqkly']} = dirname(__FILE__) . '/watermark/preview.jpg';
        ${'GLOBALS'}['pfijvfwln'] = 'options';
        ${'GLOBALS'}['iclowwot'] = 'options';
        ${${'GLOBALS'}['gfsugymxfiws']} = dirname(__FILE__) . '/watermark/preview_img.jpg';
        ${'GLOBALS'}['hgbwoclbmitg'] = 'options';
        ${'GLOBALS'}['pmlheioyjhr'] = 'position';
        $xsfrkgx = 'options';
        ${'GLOBALS'}['anyoyedntn'] = 'alpha';
        ${${'GLOBALS'}['eedxpjpny']} = ${$lklbhuvz}['upload_image'];
        ${'GLOBALS'}['igfwdl'] = 'options';
        ${${'GLOBALS'}['ymnwmx']} = ${${'GLOBALS'}['pnnfscvdxiuy']}['size'] ? ${${'GLOBALS'}['pnnfscvdxiuy']}['size'] : 16;
        ${${'GLOBALS'}['anyoyedntn']} = ${${'GLOBALS'}['igfwdl']}['transparency'] ? ${${'GLOBALS'}['pnnfscvdxiuy']}['transparency'] : 90;
        ${${'GLOBALS'}['pmlheioyjhr']} = ${${'GLOBALS'}['pnnfscvdxiuy']}['position'] ? ${$npliysffm}['position'] : 9;
        $sqtukjag = 'color';
        ${$sqtukjag} = ${${'GLOBALS'}['pfijvfwln']}['color'] ? self::hex_to_dec(${$xsfrkgx}['color']) : array(255, 255, 255);
        ${${'GLOBALS'}['blbgustrkxet']} = ${${'GLOBALS'}['pnnfscvdxiuy']}['font'] ? stripslashes(${${'GLOBALS'}['hgbwoclbmitg']}['font']) : dirname(__FILE__) . '/watermark/fonts/arial.ttf';
        ${${'GLOBALS'}['hmnwxrr']} = ${${'GLOBALS'}['pnnfscvdxiuy']}['text'] ? stripslashes(${${'GLOBALS'}['pnnfscvdxiuy']}['text']) : get_bloginfo('url');
        if (${${'GLOBALS'}['iclowwot']}['type'] == 1) {
            $qfiwjdcjwto = 'args';
            $zmswrdwomt = 'args';
            ${'GLOBALS'}['rvsppbthwbd'] = 'src';
            $trnpijr = 'position';
            ${'GLOBALS'}['moldzokvym'] = 'alpha';
            $qqscgzud = 'im_file';
            ${$zmswrdwomt} = array('dst_file' => ${${'GLOBALS'}['wdmwgiwqkly']}, 'src_file' => ${${'GLOBALS'}['rvsppbthwbd']}, 'alpha' => ${${'GLOBALS'}['moldzokvym']}, 'position' => ${$trnpijr}, 'im_file' => ${$qqscgzud});
            self::do_image_watermark('', ${$qfiwjdcjwto});
        } else {
            $yjpbcumadb = 'args';
            $tocvfnsfcdot = 'size';
            $xlmyivddrf = 'alpha';
            ${'GLOBALS'}['fyccyigvdaxd'] = 'color';
            ${$yjpbcumadb} = array('file' => ${${'GLOBALS'}['wdmwgiwqkly']}, 'font' => ${${'GLOBALS'}['blbgustrkxet']}, 'size' => ${$tocvfnsfcdot}, 'alpha' => ${$xlmyivddrf}, 'text' => ${${'GLOBALS'}['kueflpmp']}, 'color' => ${${'GLOBALS'}['fyccyigvdaxd']}, 'position' => ${${'GLOBALS'}['kvgmfqll']}, 'im_file' => ${${'GLOBALS'}['gfsugymxfiws']});
            self::do_text_watermark('', ${${'GLOBALS'}['ckyndtgc']});
        }
        return ${${'GLOBALS'}['gfsugymxfiws']};
    }
    static function do_image_watermark($options = '', $args = array())
    {
        $wteoixcfd = 'args';
        $udrxzho = 'src_data';
        $iodxbwkeuogr = 'min_w';
        $dxqvqoj = 'args';
        ${'GLOBALS'}['kcfnmxcd'] = 'dst_mime';
        ${${'GLOBALS'}['nxwrvqwbbcjt']} = ${$wteoixcfd}['dst_file'];
        ${${'GLOBALS'}['dclsxwjwpro']} = ${${'GLOBALS'}['ckyndtgc']}['src_file'];
        $fujtlpjetgn = 'src_data';
        $dclhjagnsr = 'args';
        ${${'GLOBALS'}['fkdbkhppqgo']} = ${${'GLOBALS'}['ckyndtgc']}['alpha'];
        $cntlhcuvhxg = 'min_h';
        $pctnzzvoor = 'dst_w';
        ${'GLOBALS'}['axjvasqfvdk'] = 'src_w';
        ${${'GLOBALS'}['kvgmfqll']} = ${$dclhjagnsr}['position'];
        $gemgqnowcp = 'dst_h';
        ${${'GLOBALS'}['gfsugymxfiws']} = ${$dxqvqoj}['im_file'];
        $ksfdgftcuq = 'dst_data';
        ${'GLOBALS'}['pybfqvnpke'] = 'dst_mime';
        $jsdpxwxh = 'src_w';
        ${'GLOBALS'}['wyqfrfw'] = 'dst';
        $lroptgxwxi = 'options';
        ${${'GLOBALS'}['uhlqooehmdo']} = @getimagesize(${${'GLOBALS'}['nxwrvqwbbcjt']});
        ${'GLOBALS'}['kqyfoknxtp'] = 'options';
        ${$pctnzzvoor} = ${$ksfdgftcuq}[0];
        ${'GLOBALS'}['gsiupek'] = 'src_file';
        $tfyhytyv = 'position';
        $evgupw = 'merge';
        ${'GLOBALS'}['ebokstfrl'] = 'min_w';
        ${$gemgqnowcp} = ${${'GLOBALS'}['uhlqooehmdo']}[1];
        ${$iodxbwkeuogr} = ${${'GLOBALS'}['pnnfscvdxiuy']}['min_width'] ? ${${'GLOBALS'}['kqyfoknxtp']}['min_width'] : 300;
        ${${'GLOBALS'}['qdlpimc']} = ${$lroptgxwxi}['min_height'] ? ${${'GLOBALS'}['pnnfscvdxiuy']}['min_height'] : 300;
        $kxmlokz = 'merge';
        ${'GLOBALS'}['phwofetab'] = 'src_data';
        if (${${'GLOBALS'}['unybksiyvybm']} <= ${${'GLOBALS'}['ebokstfrl']} || ${${'GLOBALS'}['kplsgqlelg']} <= ${$cntlhcuvhxg}) {
            return;
        }
        ${${'GLOBALS'}['kcfnmxcd']} = ${${'GLOBALS'}['uhlqooehmdo']}['mime'];
        ${${'GLOBALS'}['phwofetab']} = @getimagesize(${${'GLOBALS'}['gsiupek']});
        ${${'GLOBALS'}['buzdzgngucjk']} = ${${'GLOBALS'}['yoqawitxr']}[0];
        ${${'GLOBALS'}['bvqvmcec']} = ${$udrxzho}[1];
        $jishcpqptqj = 'src';
        ${${'GLOBALS'}['axsdhrrpgjdl']} = ${$fujtlpjetgn}['mime'];
        ${${'GLOBALS'}['wyqfrfw']} = self::create_image(${${'GLOBALS'}['nxwrvqwbbcjt']}, ${${'GLOBALS'}['pybfqvnpke']});
        ${'GLOBALS'}['kuioymrec'] = 'dst';
        ${${'GLOBALS'}['eedxpjpny']} = self::create_image(${${'GLOBALS'}['dclsxwjwpro']}, ${${'GLOBALS'}['axsdhrrpgjdl']});
        ${${'GLOBALS'}['wfqnxx']} = self::position(${$tfyhytyv}, ${${'GLOBALS'}['axjvasqfvdk']}, ${${'GLOBALS'}['bvqvmcec']}, ${${'GLOBALS'}['unybksiyvybm']}, ${${'GLOBALS'}['kplsgqlelg']});
        ${$kxmlokz} = self::imagecopymerge_alpha(${${'GLOBALS'}['kuioymrec']}, ${${'GLOBALS'}['eedxpjpny']}, ${${'GLOBALS'}['wfqnxx']}[0], ${${'GLOBALS'}['wfqnxx']}[1], 0, 0, ${$jsdpxwxh}, ${${'GLOBALS'}['bvqvmcec']}, ${${'GLOBALS'}['fkdbkhppqgo']});
        if (${$evgupw}) {
            $zbdgxrxe = 'dst_mime';
            ${'GLOBALS'}['kfwlwtzl'] = 'dst';
            self::make_image(${${'GLOBALS'}['kfwlwtzl']}, ${$zbdgxrxe}, ${${'GLOBALS'}['gfsugymxfiws']});
        }
        imagedestroy(${${'GLOBALS'}['wdmwgiwqkly']});
        imagedestroy(${$jishcpqptqj});
    }
    static function do_text_watermark($options = '', $args = array())
    {
        ${'GLOBALS'}['ellijlo'] = 'file';
        $dpwhryyhwvk = 'H';
        $qeljlmh = 'size';
        ${'GLOBALS'}['vrlxjyhnrf'] = 'alpha';
        $rbqrqa = 'file';
        $nylgtxtb = 'dst_h';
        ${'GLOBALS'}['nndfcxlrs'] = 'args';
        $szheru = 'dst_data';
        $lcrvghm = 'w';
        ${'GLOBALS'}['sedqrzmn'] = 'font';
        $gvbumpmim = 'args';
        $nnfeboi = 'args';
        ${'GLOBALS'}['ilixtprrwbw'] = 'coord';
        ${'GLOBALS'}['eljprots'] = 'options';
        ${${'GLOBALS'}['ellijlo']} = ${$nnfeboi}['file'];
        $okywrhpkf = 'text';
        $mivsjscalum = 'src';
        ${${'GLOBALS'}['blbgustrkxet']} = ${${'GLOBALS'}['ckyndtgc']}['font'];
        $rqwhix = 'coord';
        ${${'GLOBALS'}['kueflpmp']} = ${${'GLOBALS'}['ckyndtgc']}['text'];
        ${'GLOBALS'}['imctpw'] = 'options';
        ${'GLOBALS'}['iybencl'] = 'font';
        ${'GLOBALS'}['plgcjfumbc'] = 'args';
        $mssdbedlp = 'dst_mime';
        ${'GLOBALS'}['bcctvpvhk'] = 'green';
        ${${'GLOBALS'}['vrlxjyhnrf']} = ${${'GLOBALS'}['ckyndtgc']}['alpha'];
        ${'GLOBALS'}['nymlbjield'] = 'red';
        ${$qeljlmh} = ${$gvbumpmim}['size'];
        $foxracyoq = 'dst_mime';
        $hqigql = 'src';
        $kdxylcd = 'posion';
        ${'GLOBALS'}['nviyaeuhi'] = 'min_h';
        ${'GLOBALS'}['sufsrgddxb'] = 'size';
        ${${'GLOBALS'}['nymlbjield']} = ${${'GLOBALS'}['nndfcxlrs']}['color'][0];
        $hwctnfjq = 'min_h';
        ${${'GLOBALS'}['nbcfesz']} = ${${'GLOBALS'}['ckyndtgc']}['color'][1];
        ${${'GLOBALS'}['ttqwivi']} = ${${'GLOBALS'}['plgcjfumbc']}['color'][2];
        ${${'GLOBALS'}['kvgmfqll']} = ${${'GLOBALS'}['ckyndtgc']}['position'];
        $oilyosru = 'dst_xy';
        ${'GLOBALS'}['aeltip'] = 'options';
        ${'GLOBALS'}['mafjdryhbn'] = 'w';
        ${'GLOBALS'}['wmxeyhfjfor'] = 'text';
        ${${'GLOBALS'}['gfsugymxfiws']} = ${${'GLOBALS'}['ckyndtgc']}['im_file'];
        ${'GLOBALS'}['cmwaebc'] = 'im_file';
        ${'GLOBALS'}['tnpebqxmqjaj'] = 'h';
        ${${'GLOBALS'}['uhlqooehmdo']} = @getimagesize(${$rbqrqa});
        ${${'GLOBALS'}['unybksiyvybm']} = ${$szheru}[0];
        ${$nylgtxtb} = ${${'GLOBALS'}['uhlqooehmdo']}[1];
        $fvdpqpld = 'merge';
        ${${'GLOBALS'}['uqtkhkp']} = isset(${${'GLOBALS'}['pnnfscvdxiuy']}['min_width']) && ${${'GLOBALS'}['imctpw']}['min_width'] ? ${${'GLOBALS'}['pnnfscvdxiuy']}['min_width'] : 300;
        ${'GLOBALS'}['dvchgdxm'] = 'blue';
        $mexguc = 'h';
        ${${'GLOBALS'}['nviyaeuhi']} = isset(${${'GLOBALS'}['eljprots']}['min_height']) && ${${'GLOBALS'}['aeltip']}['min_height'] ? ${${'GLOBALS'}['pnnfscvdxiuy']}['min_height'] : 300;
        ${'GLOBALS'}['ttktxws'] = 'src';
        $suwbvgxyb = 'dst';
        $pqlacmiog = 'size';
        if (${${'GLOBALS'}['unybksiyvybm']} <= ${${'GLOBALS'}['uqtkhkp']} || ${${'GLOBALS'}['kplsgqlelg']} <= ${$hwctnfjq}) {
            return;
        }
        ${$foxracyoq} = ${${'GLOBALS'}['uhlqooehmdo']}['mime'];
        ${${'GLOBALS'}['kueflpmp']} = mb_convert_encoding(${${'GLOBALS'}['wmxeyhfjfor']}, 'html-entities', 'utf-8');
        ${'GLOBALS'}['oqqhxgpfoh'] = 'dst_h';
        ${$rqwhix} = imagettfbbox(${${'GLOBALS'}['ymnwmx']}, 0, ${${'GLOBALS'}['iybencl']}, ${$okywrhpkf});
        ${$lcrvghm} = abs((${${'GLOBALS'}['ilixtprrwbw']}[2] - ${${'GLOBALS'}['jbulfyxdwsv']}[0])) + 5;
        $jqqpakuqxok = 'red';
        ${${'GLOBALS'}['tnpebqxmqjaj']} = abs(${${'GLOBALS'}['jbulfyxdwsv']}[1] - ${${'GLOBALS'}['jbulfyxdwsv']}[7]);
        ${${'GLOBALS'}['weunlp']} = ${$mexguc} + ${${'GLOBALS'}['sufsrgddxb']} / 2;
        ${${'GLOBALS'}['eedxpjpny']} = self::image_alpha(${${'GLOBALS'}['tgbumdgl']}, ${$dpwhryyhwvk});
        ${${'GLOBALS'}['accfqwi']} = imagecolorallocate(${$hqigql}, ${$jqqpakuqxok}, ${${'GLOBALS'}['bcctvpvhk']}, ${${'GLOBALS'}['dvchgdxm']});
        ${$kdxylcd} = imagettftext(${${'GLOBALS'}['eedxpjpny']}, ${$pqlacmiog}, 0, 0, ${${'GLOBALS'}['exvkaztezwd']}, ${${'GLOBALS'}['accfqwi']}, ${${'GLOBALS'}['sedqrzmn']}, ${${'GLOBALS'}['kueflpmp']});
        $axxsbka = 'file';
        ${'GLOBALS'}['eyrwtpcypw'] = 'H';
        ${${'GLOBALS'}['wdmwgiwqkly']} = self::create_image(${$axxsbka}, ${$mssdbedlp});
        ${'GLOBALS'}['naeliyx'] = 'alpha';
        ${$oilyosru} = self::position(${${'GLOBALS'}['kvgmfqll']}, ${${'GLOBALS'}['mafjdryhbn']}, ${${'GLOBALS'}['weunlp']}, ${${'GLOBALS'}['unybksiyvybm']}, ${${'GLOBALS'}['oqqhxgpfoh']});
        ${$fvdpqpld} = self::imagecopymerge_alpha(${${'GLOBALS'}['wdmwgiwqkly']}, ${${'GLOBALS'}['ttktxws']}, ${${'GLOBALS'}['wfqnxx']}[0], ${${'GLOBALS'}['wfqnxx']}[1], 0, 0, ${${'GLOBALS'}['tgbumdgl']}, ${${'GLOBALS'}['eyrwtpcypw']}, ${${'GLOBALS'}['naeliyx']});
        self::make_image(${$suwbvgxyb}, ${${'GLOBALS'}['zpbndpxula']}, ${${'GLOBALS'}['cmwaebc']});
        imagedestroy(${${'GLOBALS'}['wdmwgiwqkly']});
        imagedestroy(${$mivsjscalum});
    }
    static function create_image($file, $mime)
    {
        ${'GLOBALS'}['gvfshfuqdj'] = 'file';
        ${'GLOBALS'}['tpurmydv'] = 'im';
        ${'GLOBALS'}['upsgryywy'] = 'mime';
        $yavkoteku = 'im';
        ${'GLOBALS'}['uiijdjx'] = 'file';
        switch (${${'GLOBALS'}['upsgryywy']}) {
        case 'image/jpeg':
            ${${'GLOBALS'}['wqbsyyvqxj']} = imagecreatefromjpeg(${${'GLOBALS'}['npuomvv']});
            break;
        case 'image/png':
            ${$yavkoteku} = imagecreatefrompng(${${'GLOBALS'}['gvfshfuqdj']});
            break;
        case 'image/gif':
            ${${'GLOBALS'}['tpurmydv']} = imagecreatefromgif(${${'GLOBALS'}['uiijdjx']});
            break;
        }
        ${'GLOBALS'}['hpdegg'] = 'im';
        return ${${'GLOBALS'}['hpdegg']};
    }
    static function make_image($im, $mime, $im_file)
    {
        $qbwwfesd = 'im';
        ${'GLOBALS'}['xjtdbdtwfvl'] = 'im_file';
        $jmjoxefpmvp = 'im_file';
        switch (${${'GLOBALS'}['iumebukui']}) {
        case 'image/jpeg':
            $htewobslybo = 'options';
            ${'GLOBALS'}['gcwfvjtj'] = 'im_file';
            $ieenene = 'options';
            ${$htewobslybo} = get_option('wp-watermark-options');
            ${'GLOBALS'}['pcnzbtv'] = 'im';
            ${'GLOBALS'}['uskeqtal'] = 'options';
            ${${'GLOBALS'}['zujvjsu']} = isset(${${'GLOBALS'}['uskeqtal']}['jpeg_quality']) && ${${'GLOBALS'}['pnnfscvdxiuy']}['jpeg_quality'] ? ${$ieenene}['jpeg_quality'] : 95;
            imagejpeg(${${'GLOBALS'}['pcnzbtv']}, ${${'GLOBALS'}['gcwfvjtj']}, ${${'GLOBALS'}['zujvjsu']});
            break;
        case 'image/png':
            imagepng(${${'GLOBALS'}['wqbsyyvqxj']}, ${${'GLOBALS'}['xjtdbdtwfvl']});
            break;
        case 'image/gif':
            imagegif(${$qbwwfesd}, ${$jmjoxefpmvp});
            break;
        }
    }
    static function imagecopymerge_alpha($dst_im, $src_im, $dst_x, $dst_y, $src_x, $src_y, $src_w, $src_h, $pct)
    {
        ${'GLOBALS'}['jwhllcuclid'] = 'opacity';
        $dgiegkrkx = 'w';
        ${'GLOBALS'}['hlekbjkpvmev'] = 'src_im';
        ${'GLOBALS'}['riiuiqjt'] = 'dst_x';
        ${'GLOBALS'}['orcywfxycsv'] = 'src_w';
        $ouvjbloe = 'src_w';
        ${${'GLOBALS'}['jwhllcuclid']} = ${${'GLOBALS'}['tpmtvhwtog']};
        $zbeexhsxno = 'cut';
        ${'GLOBALS'}['pkbulujftx'] = 'cut';
        ${'GLOBALS'}['byvzvvye'] = 'src_h';
        $hcfredovd = 'src_x';
        ${'GLOBALS'}['rbycquar'] = 'src_w';
        ${'GLOBALS'}['uxkxblqfhcr'] = 'src_im';
        ${$dgiegkrkx} = imagesx(${${'GLOBALS'}['hlekbjkpvmev']});
        ${'GLOBALS'}['wnowckjax'] = 'dst_im';
        ${${'GLOBALS'}['exvkaztezwd']} = imagesy(${${'GLOBALS'}['uxkxblqfhcr']});
        ${$zbeexhsxno} = imagecreatetruecolor(${$ouvjbloe}, ${${'GLOBALS'}['bvqvmcec']});
        ${'GLOBALS'}['kzeiwnh'] = 'dst_y';
        imagecopy(${${'GLOBALS'}['pkbulujftx']}, ${${'GLOBALS'}['cizlkojgrqg']}, 0, 0, ${${'GLOBALS'}['riiuiqjt']}, ${${'GLOBALS'}['kzeiwnh']}, ${${'GLOBALS'}['orcywfxycsv']}, ${${'GLOBALS'}['byvzvvye']});
        imagecopy(${${'GLOBALS'}['bzsxlcdq']}, ${${'GLOBALS'}['xbwumvxhbr']}, 0, 0, ${$hcfredovd}, ${${'GLOBALS'}['kofybgyo']}, ${${'GLOBALS'}['rbycquar']}, ${${'GLOBALS'}['bvqvmcec']});
        ${${'GLOBALS'}['ykpnkwwjzs']} = imagecopymerge(${${'GLOBALS'}['wnowckjax']}, ${${'GLOBALS'}['bzsxlcdq']}, ${${'GLOBALS'}['hpgmsh']}, ${${'GLOBALS'}['mhvelt']}, ${${'GLOBALS'}['vlgxiflimo']}, ${${'GLOBALS'}['kofybgyo']}, ${${'GLOBALS'}['buzdzgngucjk']}, ${${'GLOBALS'}['bvqvmcec']}, ${${'GLOBALS'}['gjceom']});
        return ${${'GLOBALS'}['ykpnkwwjzs']};
    }
    static function image_alpha($w, $h)
    {
        ${'GLOBALS'}['remcwua'] = 'im';
        $wnycfdtvyr = 'im';
        $ityodteu = 'h';
        ${'GLOBALS'}['beqibioi'] = 'im';
        ${'GLOBALS'}['hqcxsolchqi'] = 'w';
        $nioimrjr = 'im';
        ${${'GLOBALS'}['wqbsyyvqxj']} = imagecreatetruecolor(${${'GLOBALS'}['hqcxsolchqi']}, ${$ityodteu});
        imagealphablending(${${'GLOBALS'}['remcwua']}, true);
        ${'GLOBALS'}['nxacqtilzl'] = 'im';
        $wssyeckieiz = 'bgcolor';
        imageantialias(${${'GLOBALS'}['beqibioi']}, true);
        imagesavealpha(${$nioimrjr}, true);
        ${${'GLOBALS'}['ufcgccltkyk']} = imagecolorallocatealpha(${${'GLOBALS'}['nxacqtilzl']}, 255, 255, 255, 127);
        imagefill(${${'GLOBALS'}['wqbsyyvqxj']}, 0, 0, ${$wssyeckieiz});
        return ${$wnycfdtvyr};
    }
    static function position($position, $s_w, $s_h, $d_w, $d_h)
    {
        ${'GLOBALS'}['nnqtvtlbbvp'] = 'res';
        $ddusmnh = 's_h';
        $gdwhdrzt = 'd_h';
        ${'GLOBALS'}['ppxehq'] = 'x';
        $jsubsike = 'd_w';
        ${'GLOBALS'}['ulhqrvpg'] = 'x';
        ${'GLOBALS'}['qkfeswwemh'] = 'y';
        ${'GLOBALS'}['oswtvhvvi'] = 'position';
        ${'GLOBALS'}['wwaileq'] = 'y';
        $faibfj = 'y';
        $rnfpbbbsgm = 's_w';
        ${'GLOBALS'}['dmddkbyy'] = 's_w';
        $frvycsi = 's_h';
        $mimbjtxpbju = 'x';
        $iyelxgikbm = 'y';
        ${'GLOBALS'}['iskrykbtu'] = 's_h';
        ${'GLOBALS'}['rqjzgqqmwrf'] = 'd_h';
        $ekfpqn = 'xy';
        $ychsgonukk = 'res';
        ${'GLOBALS'}['nmndhdkyfzz'] = 'y';
        ${'GLOBALS'}['lmmlhjj'] = 's_h';
        $heonlsqy = 'd_w';
        $dqrhyafkp = 's_w';
        ${'GLOBALS'}['jisdxofg'] = 'x';
        ${'GLOBALS'}['dkngescd'] = 'y';
        ${'GLOBALS'}['tugjciex'] = 'd_w';
        $oqvuzlcl = 's_w';
        $lexuyxjj = 'x';
        switch (${${'GLOBALS'}['oswtvhvvi']}) {
        case 1:
            ${$lexuyxjj} = 5;
            ${${'GLOBALS'}['nmndhdkyfzz']} = 0;
            break;
        case 2:
            ${$mimbjtxpbju} = (${${'GLOBALS'}['tugjciex']} - ${$dqrhyafkp}) / 2;
            ${${'GLOBALS'}['nspegybbzhy']} = 0;
            break;
        case 3:
            ${${'GLOBALS'}['jtiuwisbb']} = (${$heonlsqy} - ${${'GLOBALS'}['stcafb']}) - 5;
            ${${'GLOBALS'}['nspegybbzhy']} = 0;
            break;
        case 4:
            ${${'GLOBALS'}['jtiuwisbb']} = 5;
            ${${'GLOBALS'}['nspegybbzhy']} = (${${'GLOBALS'}['uhblrmn']} - ${${'GLOBALS'}['iskrykbtu']}) / 2;
            break;
        case 5:
            ${${'GLOBALS'}['jtiuwisbb']} = (${${'GLOBALS'}['maemwgeftr']} - ${$rnfpbbbsgm}) / 2;
            ${${'GLOBALS'}['nspegybbzhy']} = (${${'GLOBALS'}['uhblrmn']} - ${${'GLOBALS'}['lmmlhjj']}) / 2;
            break;
        case 6:
            ${${'GLOBALS'}['jtiuwisbb']} = (${$jsubsike} - ${${'GLOBALS'}['stcafb']}) - 5;
            ${$iyelxgikbm} = (${${'GLOBALS'}['uhblrmn']} - ${$frvycsi}) / 2;
            break;
        case 7:
            ${${'GLOBALS'}['ulhqrvpg']} = 5;
            ${$faibfj} = ${${'GLOBALS'}['rqjzgqqmwrf']} - ${$ddusmnh};
            break;
        case 8:
            ${${'GLOBALS'}['jisdxofg']} = (${${'GLOBALS'}['maemwgeftr']} - ${${'GLOBALS'}['dmddkbyy']}) / 2;
            ${${'GLOBALS'}['wwaileq']} = ${$gdwhdrzt} - ${${'GLOBALS'}['lqqhzfwp']};
            break;
        default:
            ${${'GLOBALS'}['jtiuwisbb']} = (${${'GLOBALS'}['maemwgeftr']} - ${$oqvuzlcl}) - 5;
            ${${'GLOBALS'}['dkngescd']} = ${${'GLOBALS'}['uhblrmn']} - ${${'GLOBALS'}['lqqhzfwp']};
            break;
        }
        ${${'GLOBALS'}['ryzwqtm']} = get_option('wp-watermark-options');
        ${${'GLOBALS'}['ppxehq']} += ${$ychsgonukk}['x-adjustment'];
        ${${'GLOBALS'}['qkfeswwemh']} += ${${'GLOBALS'}['nnqtvtlbbvp']}['y-adjustment'];
        ${${'GLOBALS'}['pggmnqdhx']} = array(${${'GLOBALS'}['jtiuwisbb']}, ${${'GLOBALS'}['nspegybbzhy']});
        return ${$ekfpqn};
    }
    static function IsAnimatedGif($file)
    {
        $ufmcqii = 'bool';
        ${'GLOBALS'}['somtchtsi'] = 'file';
        ${'GLOBALS'}['gysrgwnaq'] = 'bool';
        ${'GLOBALS'}['rnvawrtixg'] = 'content';
        ${${'GLOBALS'}['rnvawrtixg']} = file_get_contents(${${'GLOBALS'}['somtchtsi']});
        ${${'GLOBALS'}['gysrgwnaq']} = strpos(${${'GLOBALS'}['gqepfgb']}, 'GIF89a');
        if (${$ufmcqii} === FALSE) {
            ${'GLOBALS'}['nfcnpxyuku'] = 'content';
            return strpos(${${'GLOBALS'}['nfcnpxyuku']}, ((chr(33) . chr(255)) . chr(11)) . 'NETSCAPE2.0') === FALSE ? 0 : 1;
        } else {
            return 1;
        }
    }
    static function hex_to_dec($str)
    {
        ${'GLOBALS'}['txlmym'] = 'g';
        ${'GLOBALS'}['wnvmuiqviw'] = 'g';
        $fphxhwda = 'str';
        $afmgbgyj = 'r';
        ${'GLOBALS'}['ctachxur'] = 'color';
        $otlkkrthkl = 'r';
        ${$otlkkrthkl} = hexdec(substr(${${'GLOBALS'}['fgvupcichziw']}, 1, 2));
        $cqaoezor = 'b';
        ${${'GLOBALS'}['txlmym']} = hexdec(substr(${${'GLOBALS'}['fgvupcichziw']}, 3, 2));
        ${$cqaoezor} = hexdec(substr(${$fphxhwda}, 5, 2));
        ${${'GLOBALS'}['accfqwi']} = array(${$afmgbgyj}, ${${'GLOBALS'}['wnvmuiqviw']}, ${${'GLOBALS'}['wklbtjxgiwm']});
        return ${${'GLOBALS'}['ctachxur']};
    }
    public static function get_fonts()
    {
        $jkqclyr = 'font_dir';
        $xwuykjirnvvj = 'font_name';
        ${'GLOBALS'}['mazcpvnnnbm'] = 'font_dir';
        ${$jkqclyr} = dirname(__FILE__) . '/watermark/fonts/';
        ${${'GLOBALS'}['evroqmwb']} = scandir(${${'GLOBALS'}['mazcpvnnnbm']});
        unset(${${'GLOBALS'}['evroqmwb']}[0]);
        unset(${${'GLOBALS'}['evroqmwb']}[1]);
        foreach (${${'GLOBALS'}['evroqmwb']} as ${$xwuykjirnvvj}) {
            ${'GLOBALS'}['ezgnvtmqdx'] = 'font_dir';
            ${'GLOBALS'}['pxtjxtqpckv'] = 'font_name';
            $ffpketpx = 'fonts';
            ${$ffpketpx}[${${'GLOBALS'}['nbiffrpyw']}] = ${${'GLOBALS'}['ezgnvtmqdx']} . ${${'GLOBALS'}['pxtjxtqpckv']};
        }
        return ${${'GLOBALS'}['upcyjavco']};
    }
}
class autopostMicrosoftTranslator
{
    private static $language_code = array('ar' => 'Arabic', 'bg' => 'Bulgarian', 'ca' => 'Catalan', 'zh-CHS' => 'Chinese (Simplified)', 'zh-CHT' => 'Chinese (Traditional)', 'cs' => 'Czech', 'da' => 'Danish', 'nl' => 'Dutch', 'en' => 'English', 'et' => 'Estonian', 'fa' => 'Persian (Farsi)', 'fi' => 'Finnish', 'fr' => 'French', 'de' => 'German', 'el' => 'Greek', 'ht' => 'Haitian Creole', 'he' => 'Hebrew', 'hi' => 'Hindi', 'hu' => 'Hungarian', 'id' => 'Indonesian', 'it' => 'Italian', 'ja' => 'Japanese', 'ko' => 'Korean', 'lv' => 'Latvian', 'lt' => 'Lithuanian', 'ms' => 'Malay', 'mww' => 'Hmong Daw', 'no' => 'Norwegian', 'pl' => 'Polish', 'pt' => 'Portuguese', 'ro' => 'Romanian', 'ru' => 'Russian', 'sk' => 'Slovak', 'sl' => 'Slovenian', 'es' => 'Spanish', 'sv' => 'Swedish', 'th' => 'Thai', 'tr' => 'Turkish', 'uk' => 'Ukrainian', 'ur' => 'Urdu', 'vi' => 'Vietnamese');
    public static function bulid_lang_options($selected = '')
    {
        ${'GLOBALS'}['cvdyjqfkrgg'] = 'options';
        $ghglysscbar = 'key';
        ${${'GLOBALS'}['cvdyjqfkrgg']} = '';
        foreach (self::${${'GLOBALS'}['rcunrymonf']} as ${$ghglysscbar} => ${${'GLOBALS'}['sdcopkopk']}) {
            $rxdvpxkystjj = 'key';
            $qftqshh = 'selected';
            $dnpoesu = 'value';
            ${${'GLOBALS'}['pnnfscvdxiuy']} .= ((((('<option value="' . ${$rxdvpxkystjj}) . '" ') . (${$qftqshh} == ${${'GLOBALS'}['gjejvzeg']} ? 'selected="true"' : '')) . '>') . ${$dnpoesu}) . '</option>';
        }
        return ${${'GLOBALS'}['pnnfscvdxiuy']};
    }
    public static function get_lang_by_code($key)
    {
        $ncjekldscf = 'key';
        return self::${${'GLOBALS'}['rcunrymonf']}[${$ncjekldscf}];
    }
    public static function getTokens($clientID, $clientSecret)
    {
        try {
            $ntsweqjttwx = 'grantType';
            ${'GLOBALS'}['woblujmejm'] = 'ch';
            ${'GLOBALS'}['rhjmwcemqf'] = 'ch';
            $objqsyshq = 'objResponse';
            ${'GLOBALS'}['plsnwxbn'] = 'curlErrno';
            $djvohck = 'clientSecret';
            ${${'GLOBALS'}['vywhopsnyce']} = 'https://datamarket.accesscontrol.windows.net/v2/OAuth2-13/';
            $vmjcvm = 'paramArr';
            ${${'GLOBALS'}['pqsbdxtih']} = 'http://api.microsofttranslator.com';
            $myibgofuh = 'ch';
            $okfupbk = 'clientID';
            $xkkesbw = 'grantType';
            ${$xkkesbw} = 'client_credentials';
            ${'GLOBALS'}['xisvrtvdh'] = 'authUrl';
            $wrbjbnu = 'ch';
            ${'GLOBALS'}['oxtevcyhl'] = 'scopeUrl';
            ${${'GLOBALS'}['welkvffrk']} = curl_init();
            $qqsfqguhddm = 'ch';
            ${$vmjcvm} = array('grant_type' => ${$ntsweqjttwx}, 'scope' => ${${'GLOBALS'}['oxtevcyhl']}, 'client_id' => ${$okfupbk}, 'client_secret' => ${$djvohck});
            ${${'GLOBALS'}['tkfseulpy']} = http_build_query(${${'GLOBALS'}['tkfseulpy']}, '', '&');
            curl_setopt(${${'GLOBALS'}['woblujmejm']}, CURLOPT_URL, ${${'GLOBALS'}['xisvrtvdh']});
            curl_setopt(${${'GLOBALS'}['welkvffrk']}, CURLOPT_POST, TRUE);
            curl_setopt(${${'GLOBALS'}['rhjmwcemqf']}, CURLOPT_POSTFIELDS, ${${'GLOBALS'}['tkfseulpy']});
            curl_setopt(${$wrbjbnu}, CURLOPT_RETURNTRANSFER, TRUE);
            curl_setopt(${$myibgofuh}, CURLOPT_SSL_VERIFYPEER, false);
            ${${'GLOBALS'}['kxqurxdmsdo']} = curl_exec(${${'GLOBALS'}['welkvffrk']});
            ${${'GLOBALS'}['fscqdnnsfo']} = curl_errno(${${'GLOBALS'}['welkvffrk']});
            if (${${'GLOBALS'}['plsnwxbn']}) {
                ${${'GLOBALS'}['wskposxa']} = curl_error(${${'GLOBALS'}['welkvffrk']});
                throw new Exception(${${'GLOBALS'}['wskposxa']});
            }
            ${'GLOBALS'}['iipwpomdofsi'] = 'reValue';
            curl_close(${$qqsfqguhddm});
            ${$objqsyshq} = json_decode(${${'GLOBALS'}['kxqurxdmsdo']});
            if ($objResponse->error) {
                throw new Exception($objResponse->error_description);
            }
            ${${'GLOBALS'}['uchzbhgd']}['access_token'] = $objResponse->access_token;
            return ${${'GLOBALS'}['iipwpomdofsi']};
        } catch (Exception $e) {
            $hualxrc = 'reValue';
            ${$hualxrc}['err'] = 'getTokens() Exception-' . $e->getMessage();
            return ${${'GLOBALS'}['uchzbhgd']};
        }
    }
    public static function curlRequest($url, $authHeader, $postData = '')
    {
        $jkekipjbde = 'ch';
        ${${'GLOBALS'}['welkvffrk']} = curl_init();
        curl_setopt(${${'GLOBALS'}['welkvffrk']}, CURLOPT_URL, ${${'GLOBALS'}['vnugmpqtyg']});
        curl_setopt(${${'GLOBALS'}['welkvffrk']}, CURLOPT_HTTPHEADER, array(${${'GLOBALS'}['ogfekvdx']}, 'Content-Type: text/xml'));
        curl_setopt(${${'GLOBALS'}['welkvffrk']}, CURLOPT_RETURNTRANSFER, TRUE);
        curl_setopt(${${'GLOBALS'}['welkvffrk']}, CURLOPT_SSL_VERIFYPEER, False);
        ${'GLOBALS'}['cdljerdoy'] = 'ch';
        if (${${'GLOBALS'}['nfdmujfbyxjb']}) {
            ${'GLOBALS'}['ptmyvydv'] = 'ch';
            ${'GLOBALS'}['tulyymrxwj'] = 'postData';
            curl_setopt(${${'GLOBALS'}['welkvffrk']}, CURLOPT_POST, TRUE);
            curl_setopt(${${'GLOBALS'}['ptmyvydv']}, CURLOPT_POSTFIELDS, ${${'GLOBALS'}['tulyymrxwj']});
        }
        ${${'GLOBALS'}['xpcgukzsjux']} = curl_exec(${${'GLOBALS'}['cdljerdoy']});
        ${${'GLOBALS'}['fscqdnnsfo']} = curl_errno(${${'GLOBALS'}['welkvffrk']});
        if (${${'GLOBALS'}['fscqdnnsfo']}) {
            ${'GLOBALS'}['kpbobrjb'] = 'curlError';
            ${${'GLOBALS'}['kpbobrjb']} = curl_error(${${'GLOBALS'}['welkvffrk']});
            throw new Exception(${${'GLOBALS'}['wskposxa']});
        }
        curl_close(${$jkekipjbde});
        return ${${'GLOBALS'}['xpcgukzsjux']};
    }
    public static function createReqXML($languageCode)
    {
        ${'GLOBALS'}['ptpitqdo'] = 'requestXml';
        ${${'GLOBALS'}['ptpitqdo']} = '<ArrayOfstring xmlns="http://schemas.microsoft.com/2003/10/Serialization/Arrays" xmlns:i="http://www.w3.org/2001/XMLSchema-instance">';
        if (${${'GLOBALS'}['ojdlmcs']}) {
            ${${'GLOBALS'}['tadozzusgt']} .= "<string>{$languageCode}</string>";
        } else {
            throw new Exception('Language Code is empty.');
        }
        ${${'GLOBALS'}['tadozzusgt']} .= '</ArrayOfstring>';
        return ${${'GLOBALS'}['tadozzusgt']};
    }
    public static function translate($token, $src_text, $fromLanguage, $toLanguage, $contentType = 'text/html')
    {
        try {
            ${'GLOBALS'}['isblqifd'] = 'curlResponse';
            $thsxnhxbc = 'xmlObj';
            $mtxcbtkkdxbn = 'category';
            $rijzxvjcplk = 'translated';
            ${'GLOBALS'}['voxvssid'] = 'translateUrl';
            ${'GLOBALS'}['ihfcfvkade'] = 'curlResponse';
            ${'GLOBALS'}['cmwgqeycu'] = 'translateUrl';
            $mhqbgpbeesq = 'contentType';
            ${'GLOBALS'}['towukukf'] = 'xmlObj';
            ${${'GLOBALS'}['ogfekvdx']} = 'Authorization: Bearer ' . ${${'GLOBALS'}['aqxaaoiwo']};
            ${$mtxcbtkkdxbn} = 'general';
            ${${'GLOBALS'}['cghahbqpo']} = (((((('text=' . urlencode(${${'GLOBALS'}['gomphm']})) . '&to=') . ${${'GLOBALS'}['bjwflxws']}) . '&from=') . ${${'GLOBALS'}['jkxgywfpdkdb']}) . '&contentType=') . ${$mhqbgpbeesq};
            ${${'GLOBALS'}['cmwgqeycu']} = "http://api.microsofttranslator.com/v2/Http.svc/Translate?{$params}";
            ${${'GLOBALS'}['isblqifd']} = self::curlRequest(${${'GLOBALS'}['voxvssid']}, ${${'GLOBALS'}['ogfekvdx']});
            ${$thsxnhxbc} = simplexml_load_string(${${'GLOBALS'}['ihfcfvkade']});
            foreach ((array) ${${'GLOBALS'}['towukukf']}[0] as ${${'GLOBALS'}['xeqldqrfeyg']}) {
                $httluzq = 'val';
                ${'GLOBALS'}['dtosbe'] = 'translatedStr';
                ${${'GLOBALS'}['dtosbe']} = ${$httluzq};
            }
            ${${'GLOBALS'}['ktwdpsi']}['str'] = ${${'GLOBALS'}['wtbslorqcpr']};
            return ${$rijzxvjcplk};
        } catch (Exception $e) {
            ${${'GLOBALS'}['ktwdpsi']}['err'] = 'Exception: ' . $e->getMessage();
            return ${${'GLOBALS'}['ktwdpsi']};
        }
    }
}